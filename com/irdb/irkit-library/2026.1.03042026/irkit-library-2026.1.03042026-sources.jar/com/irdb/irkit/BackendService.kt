package com.irdb.irkit


import android.util.Log
import com.google.gson.GsonBuilder
import com.google.gson.JsonParser
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.config.IRKitConfigManager
import com.irdb.irkit.dto.BooleanTypeAdapter
import com.irdb.irkit.dto.EnvironmentInformationDto
import com.irdb.irkit.dto.GsonErrorHandler
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.MetaContentTypeAdapter
import com.irdb.irkit.dto.ProductInCampaignDto
import com.irdb.irkit.response.EnvironmentInformationResponse
import com.irdb.irkit.response.ImageHistoryAddResponse
import com.irdb.irkit.response.ProductsContainer
import java.lang.reflect.Type
import java.net.HttpURLConnection
import java.net.URL
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Service for handling backend API requests and environment configuration. Manages communication
 * with the backend server and handles environment-specific settings.
 */
object BackendService {
    internal const val TAG = "BackendService"

    // how many characters to print out in the logs.
    internal val PRETTY_PRINT_LEN = if (BuildConfig.DEBUG) 500 else 100

    // Configuration provider - will be injected by the consuming application
    private var configuration: IRKitConfiguration? = null

    /**
     * Sets the configuration provider for the backend service.
     * This must be called before making any API requests.
     */
    fun setConfiguration(config: IRKitConfiguration) {
        this.configuration = config
    }

    /**
     * Gets the subscription key from configuration
     */
    internal fun getSubscriptionKey(): String {
        return configuration?.getSubscriptionKey() ?: throw IllegalStateException("IRKitConfiguration not set. Call BackendService.setConfiguration() first.")
    }

    /**
     * Gets the debug mode from configuration
     */
    internal fun isDebugMode(): Boolean {
        return configuration?.isDebugMode() ?: false
    }

    /**
     * Optional override URL for testing purposes.
     * When set (by instrumented tests), this URL will be used instead of the configured backend URL.
     * This allows test URL override for instrumented tests without affecting production code.
     *
     * IMPORTANT: This is only set by instrumented tests and has zero impact on
     * production, staging, or development builds.
     */
    internal var testOverrideUrl: String? = null

    /**
     * Expose getBaseUrl for other BackendService extension files.
     *
     * In test mode (when testOverrideUrl is set), returns the test URL.
     * Otherwise, returns the configured backend URL.
     */
    internal fun getBaseUrl(): String {
        // If test override URL is set (by instrumented tests), use it
        testOverrideUrl?.let { return it }

        // Otherwise, use the configured backend URL
        return configuration?.getBackendUrl() ?: throw IllegalStateException("IRKitConfiguration not set. Call BackendService.setConfiguration() first.")
    }

    // I need to do some better validation here, I think.
    // When if figure it out!
    var firebaseToken: String? = null
        set(value) {
            field = value
        }

    internal val gson =
            GsonErrorHandler.createGsonBuilder()
                    .registerTypeAdapter(MetaContent::class.java, MetaContentTypeAdapter())
                    .registerTypeAdapter(Boolean::class.java, BooleanTypeAdapter())
                    .create()

    fun updateApplicationWithNewEnvironmentData(env: EnvironmentInformationDto) {
        val config = IRKitConfigManager.getConfiguration()
        config.putEnvironment(env.environment)
        config.putUrlToIREngine(env.urlToIREngine)
        config.putAPIKeyForIREngine(env.apiKeyForIREngine)
    }

    suspend fun getEnvironmentInformationAndStoreInPrefs() {
        val endpoint = "/IREngine/environment"

        val response =
                request<BaseResponse<EnvironmentInformationResponse>>(
                        endpoint = endpoint,
                        method = HttpMethod.GET,
                        responseType =
                                object :
                                                TypeToken<
                                                        BaseResponse<
                                                                EnvironmentInformationResponse>>() {}
                                        .type
                )

        if (!response.succeeded || response.payload == null) {
            logMaskedApiKeyForDiagnostics("EnvInfoFailed")
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        val env =
                payload
                        .results
                        .environmentInformation
        updateApplicationWithNewEnvironmentData(env)
    }

    suspend fun getProducts(campaignId: Int): List<ProductInCampaignDto> {
        val endpoint = "/Campaign/products/$campaignId"

        val response =
                request<BaseResponse<ProductsContainer>>(
                        endpoint = endpoint,
                        method = HttpMethod.GET,
                        responseType = object : TypeToken<BaseResponse<ProductsContainer>>() {}.type
                )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        return payload.results.products
    }

    suspend fun addImageToUsersHistory(imageId: String, fbToken: String): Boolean {
        val endpoint = "/images/historyAdd/$imageId"

        if (BackendService.isDebugMode()) {
            Log.i(TAG, "Adding this image to history $imageId")
        }

        val response =
                request<BaseResponse<ImageHistoryAddResponse>>(
                        endpoint = endpoint,
                        method = HttpMethod.POST,
                        responseType =
                                object : TypeToken<BaseResponse<ImageHistoryAddResponse>>() {}.type,
                        headerParameters = mapOf("auth" to fbToken)
                )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        return payload.results.history
    }

    internal suspend fun <T : BEDecodable> request(
            endpoint: String,
            method: HttpMethod,
            requestParameters: Map<String, Any>? = null,
            headerParameters: Map<String, String>? = null,
            bodyParameters: Any? = null,
            responseType: Type
    ): ApiCallResult<T> {
        val url = "${getBaseUrl()}$endpoint"

        // Log endpoint for development debugging only
        if (isDebugMode()) {
            Log.d("EndPoint", "url: $url")
        }

        if (isDebugMode()) {
            Log.d(TAG, "Making request to: $url")
            Log.d(TAG, "Method: ${method.value}")
            Log.d(TAG, "Firebase token present: ${firebaseToken != null}")
        }

        try {
            val headers = createHeaders(headerParameters)
            if (isDebugMode()) {
                headers.forEach { (key, value) -> Log.d(TAG, "Header: $key = $value") }
            }

            // Create connection and set properties
            val connection = createTrustAllConnection(URL(url))
            connection.requestMethod = method.value
            connection.doInput = true
            connection.doOutput = bodyParameters != null

            // Set headers before any connection is made
            headers.forEach { (key, value) -> connection.setRequestProperty(key, value) }

            // Capture request properties before making connection
            val requestProps =
                    if (isDebugMode()) {
                        connection.requestProperties.toString()
                    } else {
                        null
                    }

            // Make the connection
            connection.connect()

            // Write body if present
            if (bodyParameters != null) {
                connection.outputStream.use { it.write(gson.toJson(bodyParameters).toByteArray()) }
            }

            val result = processResponse<T>(responseType, connection, url, requestProps)

            // Log endpoint and GCRLog for easy filtering (all API calls)
            Log.d("endpointLog", "Endpoint: $endpoint | GCRLog: ${result.gcrLog ?: "null"}")

            return result
        } catch (e: Exception) {
            Log.e(TAG, "Request failed: ${e.message}", e)
            Log.e(TAG, "Request URL: $url")
            Log.e(TAG, "Request method: ${method.value}")
            try {
                val key = getSubscriptionKey()
                Log.e(TAG, "sdkapikey: $key")
            } catch (_: Exception) {
                Log.e(TAG, "sdkapikey: unable to retrieve")
            }
            throw BackendServiceError.InvalidResponse
        }
    }

    private fun createHeaders(headerParameters: Map<String, String>?): Map<String, String> {
        val subscriptionKey = getSubscriptionKey()
        val headers =
                mutableMapOf(
                        "Content-Type" to "application/json",
                        "Accept" to "application/json",
                        "sdkapikey" to subscriptionKey
                )

        firebaseToken?.let { token -> headers["auth"] = token }

        // Add auth token
        //        if (UserData.instance.isSignedIn) {
        //            headers["auth"] = UserData.instance.fbToken
        //        } else {
        //            headers["auth"] = UserData.instance.anonymousFbToken
        //        }

        // Add custom headers
        headerParameters?.forEach { (key, value) -> headers[key] = value }

        if (isDebugMode()) {
            Log.d(TAG, "Using sdkapikey: ${maskSensitiveValue(subscriptionKey)}")
        }

        return headers
    }

    private fun maskSensitiveValue(value: String, visiblePrefix: Int = 4, visibleSuffix: Int = 4): String {
        if (value.length <= visiblePrefix + visibleSuffix) {
            return "*".repeat(value.length)
        }
        val prefix = value.take(visiblePrefix)
        val suffix = value.takeLast(visibleSuffix)
        val mask = "*".repeat(value.length - visiblePrefix - visibleSuffix)
        return "$prefix$mask$suffix"
    }

    private fun logMaskedApiKeyForDiagnostics(reason: String) {
        val subscriptionKey = try {
            getSubscriptionKey()
        } catch (_: Exception) {
            null
        }
        val maskedKey = subscriptionKey?.let { maskSensitiveValue(it) } ?: "unknown"
        Log.e(TAG, "Diagnostic($reason): sdkapikey=$maskedKey baseUrl=${getBaseUrl()}")
    }

    private fun <T : BEDecodable> processResponse(
            responseType: Type,
            connection: HttpURLConnection,
            url: String,
            requestProps: String? = null
    ): ApiCallResult<T> {
        val result = ApiCallResult<T>()
        result.url = url

        // Log request properties if available
        if (BackendService.isDebugMode() && requestProps != null) {
            Log.d(TAG, "Request ($url): $requestProps")
        }

        // Now get response code and continue with response processing
        result.httpStatusCode = connection.responseCode

        try {
            val responseData =
                    when {
                                connection.responseCode in 200..299 -> connection.inputStream
                                else -> connection.errorStream
                            }
                            .bufferedReader()
                            .use { it.readText() }

            // Try to extract GCRLog from the raw response
            try {
                val rootElement = JsonParser.parseString(responseData)
                if (rootElement.isJsonObject) {
                    val rootObj = rootElement.asJsonObject
                    rootObj.get("GCRLog")?.let {
                        if (it.isJsonPrimitive) {
                            result.gcrLog = it.asString
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore if parsing fails, GCRLog might not be present
                if (isDebugMode()) {
                    Log.w(TAG, "Could not parse GCRLog from response: ${e.message}")
                }
            }

            // DO NOT LOG THIS IN STAGING OR PROD!!! EVER!!!
            if (BackendService.isDebugMode()) {
                // Log raw response data immediately
                Log.d("RAW RESPONSE", "Raw response data: $responseData")

                // DO NOT LOG THIS IN STAGING OR PROD!!! EVER!!!

                // Pretty print JSON response (limited to 1000 chars)
                try {
                    val jsonElement = JsonParser.parseString(responseData)
                    val prettyJson = GsonBuilder().setPrettyPrinting().create().toJson(jsonElement)
                    if (BuildConfig.DEBUG) {
                        Log.d(TAG, "Response ($url):\n${prettyJson.take(PRETTY_PRINT_LEN)}")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "JSON pretty print failed: ${e.message}")
                    Log.e(TAG, "JSON parsing error details:", e)
                    Log.e(TAG, "Problematic JSON string: $responseData")
                }
            }

            // Process response
            when (connection.responseCode) {
                in 200..202 -> {
                    try {
                        // Inspect known error flags even on 2xx responses
                        try {
                            val rootElement = JsonParser.parseString(responseData)
                            if (rootElement.isJsonObject) {
                                val rootObj = rootElement.asJsonObject
                                val errorMsgEl = rootObj.get("ErrorMessage")
                                val resultsEl = rootObj.get("Results")
                                val imageNotFoundFlag =
                                        ((errorMsgEl != null && errorMsgEl.isJsonObject &&
                                                (errorMsgEl.asJsonObject.get("ImageNotFound")?.asBoolean
                                                        == true)) ||
                                                (resultsEl != null && resultsEl.isJsonObject &&
                                                        (resultsEl.asJsonObject.get("ImageNotFound")?.asBoolean
                                                                == true)))
                                if (imageNotFoundFlag) {
                                    result.errorMessage = "ImageNotFound"
                                }
                            }
                        } catch (_: Exception) {
                            // Ignore JSON inspection issues; proceed with normal parsing
                        }
                        val payload =
                                gson.fromJson<T>(responseData, responseType) // Changed to use Type
                        result.payload = payload
                        result.succeeded = true
                        Log.d(TAG, "Success with status code ${connection.responseCode}")
                    } catch (e: Exception) {
                        Log.e(TAG, "Parsing failed: ${e.message}")
                        // Try to extract well-known error flags from raw body
                        try {
                            val rootElement = JsonParser.parseString(responseData)
                            if (rootElement.isJsonObject) {
                                val rootObj = rootElement.asJsonObject
                                val errorMsgEl = rootObj.get("ErrorMessage")
                                val resultsEl = rootObj.get("Results")
                                val imageNotFoundFlag =
                                        ((errorMsgEl != null && errorMsgEl.isJsonObject &&
                                                (errorMsgEl.asJsonObject.get("ImageNotFound")?.asBoolean
                                                        == true)) ||
                                                (resultsEl != null && resultsEl.isJsonObject &&
                                                        (resultsEl.asJsonObject.get("ImageNotFound")?.asBoolean
                                                                == true)))
                                if (imageNotFoundFlag) {
                                    result.errorMessage = "ImageNotFound"
                                } else {
                                    result.errorMessage = BackendServiceError.ParseError.message
                                }
                            } else {
                                result.errorMessage = BackendServiceError.ParseError.message
                            }
                        } catch (_: Exception) {
                            result.errorMessage = BackendServiceError.ParseError.message
                        }
                        result.succeeded = false
                    }
                }
                401, 403 -> {
                    Log.d(TAG, "Unauthorized access with status code ${connection.responseCode}")
                    result.isUnauthorizedAccess = true
                    result.errorMessage =
                            extractErrorMessage(responseData) ?: BackendServiceError.AccessDenied.message
                    result.succeeded = false
                }
                else -> {
                    Log.d(TAG, "Failed with status code ${connection.responseCode}")
                    // Inspect body for well-known error flags
                    try {
                        val rootElement = JsonParser.parseString(responseData)
                        if (rootElement.isJsonObject) {
                            val rootObj = rootElement.asJsonObject
                            val errorMsgEl = rootObj.get("ErrorMessage")
                            val resultsEl = rootObj.get("Results")
                            val imageNotFoundFlag =
                                    ((errorMsgEl != null && errorMsgEl.isJsonObject &&
                                            (errorMsgEl.asJsonObject.get("ImageNotFound")?.asBoolean
                                                    == true)) ||
                                            (resultsEl != null && resultsEl.isJsonObject &&
                                                    (resultsEl.asJsonObject.get("ImageNotFound")?.asBoolean
                                                            == true)))
                            if (imageNotFoundFlag) {
                                result.errorMessage = "ImageNotFound"
                            }
                        }
                    } catch (_: Exception) {
                        // ignore
                    }
                    if (result.errorMessage.isNullOrBlank()) {
                        result.errorMessage =
                                extractErrorMessage(responseData)
                                        ?: BackendServiceError.InvalidResponse.message
                    }
                    result.succeeded = false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Response processing failed: ${e.message}")
            result.errorMessage = BackendServiceError.ParseError.message
            result.succeeded = false
        }
        return result
    }

    private fun extractErrorMessage(responseData: String): String? {
        return try {
            val rootElement = JsonParser.parseString(responseData)
            if (!rootElement.isJsonObject) {
                return null
            }

            val rootObj = rootElement.asJsonObject
            val errorMessageElement = rootObj.get("ErrorMessage")
            if (errorMessageElement != null) {
                if (errorMessageElement.isJsonObject) {
                    val errorMessage =
                            gson.fromJson(errorMessageElement, ErrorMessage::class.java)
                                    .getErrorMessage()
                    return errorMessage.takeIf { it.isNotBlank() }
                }
                if (errorMessageElement.isJsonPrimitive) {
                    val errorMessage = errorMessageElement.asString
                    return errorMessage.takeIf { it.isNotBlank() }
                }
            }

            val msg = rootObj.get("msg")?.takeIf { it.isJsonPrimitive }?.asString
            val code = rootObj.get("code")?.takeIf { it.isJsonPrimitive }?.asString
            val error = rootObj.get("error")?.takeIf { it.isJsonPrimitive }?.asString
            val fallback = ErrorMessage(error = error, msg = msg, code = code).getErrorMessage()
            fallback.takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    private fun createTrustAllConnection(url: URL): HttpURLConnection {
        val connection =
                if (url.protocol == "https") {
                    // Create a trust manager that does not validate certificate chains
                    val trustAllCerts =
                            arrayOf<TrustManager>(
                                    object : X509TrustManager {
                                        override fun checkClientTrusted(
                                                chain: Array<out X509Certificate>?,
                                                authType: String?
                                        ) {}
                                        override fun checkServerTrusted(
                                                chain: Array<out X509Certificate>?,
                                                authType: String?
                                        ) {}
                                        override fun getAcceptedIssuers(): Array<X509Certificate> =
                                                arrayOf()
                                    }
                            )

                    // Install the all-trusting trust manager
                    val sslContext = SSLContext.getInstance("SSL")
                    sslContext.init(null, trustAllCerts, java.security.SecureRandom())

                    // Create an ssl socket factory with our all-trusting manager
                    url.openConnection().apply {
                        (this as HttpsURLConnection).sslSocketFactory = sslContext.socketFactory
                        (this as HttpsURLConnection).hostnameVerifier = HostnameVerifier { _, _ ->
                            true
                        }
                    }
                } else {
                    url.openConnection()
                }

        return connection as HttpURLConnection
    }
}
