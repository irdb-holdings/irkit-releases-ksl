package com.irdb.irkit.segmentation

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Log
import com.irdb.irkit.utils.DeviceCapabilityDetector
import com.irdb.irkit.utils.DeviceCapabilityDetector.DeviceTier

/**
 * Manages the ONNX segmentation lifecycle: initialization, self-tuning warmup,
 * per-frame bounding box inference, stale bbox reuse, and cleanup.
 *
 * This is the single integration point that [com.irdb.irkit.IREngine] calls.
 * It wraps [SegmentationProcessor] and adds throttling, stale-bbox caching,
 * and device self-tuning.
 */
class SegmentationManager(private val context: Context) {

    companion object {
        private const val TAG = "SegmentationManager"

        // Self-tuning thresholds (milliseconds for warmup inference)
        private const val FAST_DEVICE_THRESHOLD_MS = 150L
        private const val MID_DEVICE_THRESHOLD_MS = 400L

        // Self-tuning inference intervals
        private const val FAST_DEVICE_INTERVAL_MS = 200L
        private const val MID_DEVICE_INTERVAL_MS = 400L
    }

    private var processor: SegmentationProcessor? = null

    // Stale bbox tracking
    private val bboxLock = Object()
    private var lastBbox: RectF? = null
    private var lastBboxTimestamp: Long = 0L
    private var lastInferenceTime: Long = 0L

    // Last mask data for debug overlay
    private var lastMaskBitmap: Bitmap? = null

    /**
     * Initialize the segmentation pipeline. Runs a warmup inference to benchmark
     * device speed, auto-tunes the inference interval, and validates NNAPI output.
     *
     * Call this once during camera initialization on a background thread.
     * After this returns, [SegmentationConfig.segmentationEnabled] reflects
     * whether the device can handle real-time segmentation.
     */
    fun initialize(deviceTier: DeviceTier? = null) {
        if (!SegmentationConfig.segmentationEnabled) {
            Log.d(TAG, "Segmentation disabled by configuration, skipping init")
            return
        }

        // Pre-check: skip ONNX entirely on very low-end devices
        if (deviceTier == DeviceTier.VERY_LOW_END) {
            Log.d(TAG, "Very low-end device — disabling segmentation")
            SegmentationConfig.segmentationEnabled = false
            return
        }

        try {
            tuneSegmentation(useNnapi = true)
        } catch (e: Exception) {
            Log.e(TAG, "Segmentation initialization failed: ${e.message}", e)
            SegmentationConfig.segmentationEnabled = false
        }
    }

    /**
     * Run segmentation on a bitmap and return the bounding box.
     *
     * Handles inference throttling (only runs ONNX if enough time has passed)
     * and stale bbox reuse (returns the previous bbox if it's fresh enough).
     *
     * @param bitmap The rotated camera frame (already orientation-corrected)
     * @return Normalized bounding box [0,1] or null if no object detected
     */
    fun getSegmentationBbox(bitmap: Bitmap): RectF? {
        val proc = processor ?: return null
        if (!SegmentationConfig.segmentationEnabled) return null

        val now = System.currentTimeMillis()

        // Throttle: reuse last bbox if inference ran recently
        if (now - lastInferenceTime < SegmentationConfig.inferenceIntervalMs) {
            return getStaleBboxIfValid(now)
        }

        lastInferenceTime = now

        return try {
            // Run the full pipeline: preprocess → inference → postprocess
            val imageData = proc.preprocessImage(bitmap)
            val (mask, shape) = proc.runInference(imageData)
            val (maskW, maskH) = proc.parseMaskDimensions(shape)
            val bbox = proc.postprocessMask(mask, maskW, maskH)

            synchronized(bboxLock) {
                if (bbox != null) {
                    lastBbox = bbox
                    lastBboxTimestamp = now
                }

                // Build debug mask bitmap if overlay is enabled
                if (SegmentationConfig.showBoundingBoxOverlay) {
                    lastMaskBitmap?.recycle()
                    lastMaskBitmap = proc.buildMaskBitmap(mask, maskW, maskH)
                }
            }

            bbox ?: getStaleBboxIfValid(now)
        } catch (e: Exception) {
            Log.w(TAG, "Segmentation inference failed: ${e.message}")
            getStaleBboxIfValid(now)
        }
    }

    /**
     * Get the current bounding box for overlay rendering (thread-safe).
     */
    fun getCurrentBbox(): RectF? {
        synchronized(bboxLock) {
            return lastBbox?.let { RectF(it) }
        }
    }

    /**
     * Get the debug mask bitmap for overlay rendering.
     * Only populated when [SegmentationConfig.showBoundingBoxOverlay] is true.
     */
    fun getDebugMaskBitmap(): Bitmap? {
        synchronized(bboxLock) {
            return lastMaskBitmap
        }
    }

    /**
     * Release all resources. Call when the camera session ends.
     */
    fun cleanup() {
        processor?.close()
        processor = null
        synchronized(bboxLock) {
            lastBbox = null
            lastBboxTimestamp = 0L
            lastMaskBitmap?.recycle()
            lastMaskBitmap = null
        }
    }

    // -------------------------------------------------------------------------
    // Self-tuning: warmup benchmark + NNAPI validation
    // -------------------------------------------------------------------------

    private fun tuneSegmentation(useNnapi: Boolean) {
        val proc = SegmentationProcessor(context, useNnapi = useNnapi)

        if (!proc.isReady) {
            Log.w(TAG, "SegmentationProcessor not ready (model failed to load)")
            SegmentationConfig.segmentationEnabled = false
            proc.close()
            return
        }

        // Warmup inference with blank input — result is discarded, we only measure time
        val testInput = FloatArray(3 * 384 * 384) { 0.5f }
        val start = System.currentTimeMillis()
        val (mask, _) = proc.runInference(testInput)
        val elapsedMs = System.currentTimeMillis() - start

        Log.d(TAG, "Warmup inference took ${elapsedMs}ms (NNAPI=$useNnapi)")

        // Exynos NNAPI validation: a blank input should produce a near-zero mask,
        // but if NNAPI is malfunctioning the mask may be garbage.
        if (useNnapi) {
            val hasNonTrivialValues = mask.any { it > 0.5f }
            if (hasNonTrivialValues) {
                // A blank image shouldn't produce high-confidence mask values.
                // This likely means NNAPI is corrupting the output.
                Log.w(TAG, "NNAPI produced suspicious mask for blank input — falling back to CPU")
                proc.close()
                tuneSegmentation(useNnapi = false)
                return
            }
        }

        // Set inference interval based on device speed
        when {
            elapsedMs < FAST_DEVICE_THRESHOLD_MS -> {
                Log.d(TAG, "Fast device — segmentation enabled at ${FAST_DEVICE_INTERVAL_MS}ms interval")
                SegmentationConfig.segmentationEnabled = true
                SegmentationConfig.inferenceIntervalMs = FAST_DEVICE_INTERVAL_MS
            }
            elapsedMs < MID_DEVICE_THRESHOLD_MS -> {
                Log.d(TAG, "Mid-range device — segmentation enabled at ${MID_DEVICE_INTERVAL_MS}ms interval")
                SegmentationConfig.segmentationEnabled = true
                SegmentationConfig.inferenceIntervalMs = MID_DEVICE_INTERVAL_MS
            }
            else -> {
                Log.d(TAG, "Slow device (${elapsedMs}ms) — disabling segmentation")
                SegmentationConfig.segmentationEnabled = false
                proc.close()
                return
            }
        }

        processor = proc
    }

    // -------------------------------------------------------------------------
    // Stale bbox reuse — returns the previous bbox if it's within the staleness window
    // -------------------------------------------------------------------------

    private fun getStaleBboxIfValid(now: Long): RectF? {
        synchronized(bboxLock) {
            val staleAge = now - lastBboxTimestamp
            return if (lastBbox != null && staleAge <= SegmentationConfig.maxStaleBboxAgeMs) {
                lastBbox
            } else {
                null
            }
        }
    }
}
