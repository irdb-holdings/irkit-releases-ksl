package com.irdb.irkit.ui

import android.graphics.Bitmap
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Segmentation bounding box overlay drawn on top of the camera preview.
 *
 * Draws the segmentation mask (semi-transparent green showing what the model
 * detects as "the object") and a yellow bounding box derived from the mask.
 * Coordinates are transformed to account for the PreviewView scale type so
 * both the mask and box align correctly with the displayed camera image:
 *   - FILL_CENTER (default): camera frame is scaled to fill the screen, clipping edges
 *   - FIT_CENTER: camera frame fits within the screen with letterboxing
 *
 * @param showOverlay Whether to render the overlay (from ClientConfigBase.showSegmentationBoundingBox)
 * @param boundingBox Normalized [0,1] bounding box in camera frame coordinates, or null
 * @param maskBitmap Debug mask bitmap from the segmentation model (384x384 green pixels), or null
 * @param frameWidth Width of the rotated camera frame in pixels (0 = unknown, falls back to direct mapping)
 * @param frameHeight Height of the rotated camera frame in pixels (0 = unknown, falls back to direct mapping)
 * @param isFillScale True for FILL_CENTER (default PreviewView), false for FIT_CENTER
 */
@Suppress("UNUSED_PARAMETER")
@Composable
fun SegmentationBboxOverlay(
    showOverlay: Boolean,
    boundingBox: RectF?,
    maskBitmap: Bitmap? = null,
    frameWidth: Int = 0,
    frameHeight: Int = 0,
    isFillScale: Boolean = true,
    modifier: Modifier = Modifier
) {
    if (!showOverlay) return
    if (boundingBox == null && maskBitmap == null) return

    Canvas(modifier = modifier.fillMaxSize()) {
        // Compute the FILL/FIT_CENTER transform once, reuse for both mask and bbox
        val hasFrameSize = frameWidth > 0 && frameHeight > 0
        val scaleX = if (hasFrameSize) size.width / frameWidth else 1f
        val scaleY = if (hasFrameSize) size.height / frameHeight else 1f
        val scale = if (hasFrameSize) {
            if (isFillScale) maxOf(scaleX, scaleY) else minOf(scaleX, scaleY)
        } else 1f
        val displayedW = if (hasFrameSize) frameWidth * scale else size.width
        val displayedH = if (hasFrameSize) frameHeight * scale else size.height
        val offsetX = (size.width - displayedW) / 2f
        val offsetY = (size.height - displayedH) / 2f

        // Draw bounding box
        boundingBox?.let { bbox ->
            val left   = offsetX + bbox.left   * displayedW
            val top    = offsetY + bbox.top    * displayedH
            val right  = offsetX + bbox.right  * displayedW
            val bottom = offsetY + bbox.bottom * displayedH

            // Faint yellow fill inside the detected region
            drawRect(
                color = Color(0x28FFFF00),
                topLeft = Offset(left, top),
                size = Size(right - left, bottom - top)
            )

            // Yellow stroke around the detected region
            drawRect(
                color = Color.Yellow,
                topLeft = Offset(left, top),
                size = Size(right - left, bottom - top),
                style = Stroke(width = 3.dp.toPx())
            )
        }
    }
}
