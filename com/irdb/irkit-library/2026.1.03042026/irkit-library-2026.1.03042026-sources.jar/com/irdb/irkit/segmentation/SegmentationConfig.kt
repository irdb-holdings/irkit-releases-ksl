package com.irdb.irkit.segmentation

/**
 * Runtime configuration for the ONNX segmentation pipeline.
 *
 * Values are initialized from IRKit-UI's ClientConfigBase during IRKitUI.initialize().
 * IRKit-UI is the authority for [segmentationEnabled] and [showBoundingBoxOverlay] —
 * they are set per-client in the configuration files (KslConfig, IrcodeConfig, etc.).
 *
 * Self-tuning (SegmentationManager) may override [segmentationEnabled] and
 * [inferenceIntervalMs] at runtime based on device benchmark results.
 *
 * All mutable fields are @Volatile for safe cross-thread access.
 */
object SegmentationConfig {

    // ── Master switch ────────────────────────────────────────────────────────
    // Controlled by IRKit-UI configuration. Self-tuning may disable at runtime
    // on devices too slow for real-time inference.
    @Volatile var segmentationEnabled: Boolean = true

    // ── Bounding box overlay ─────────────────────────────────────────────────
    // Controlled by IRKit-UI configuration. Shows a yellow bounding box on the
    // camera preview where the model detected an object.
    @Volatile var showBoundingBoxOverlay: Boolean = false

    // ── Inference throttle ───────────────────────────────────────────────────
    // Minimum milliseconds between ONNX inference runs. Frames arriving faster
    // than this reuse the previous bounding box. Self-tuning adjusts this based
    // on device speed. Mirrors iOS Constants.segmentationInferenceInterval (0.3s).
    @Volatile var inferenceIntervalMs: Long = 300L

    // ── Stale bbox reuse ─────────────────────────────────────────────────────
    // If the current frame produces no bbox, reuse the previous one as long as
    // it is newer than this. Mirrors iOS Constants.segmentationMaxStaleBoundingBoxAge (1.0s).
    @Volatile var maxStaleBboxAgeMs: Long = 1_000L

    // ── Gaze point ───────────────────────────────────────────────────────────
    // Normalized 0–1; default = image center.
    // Mirrors iOS Constants.segmentationInitialGazeX/Y.
    @Volatile var gazeX: Float = 0.5f
    @Volatile var gazeY: Float = 0.5f

    // ── Debug frame saving ──────────────────────────────────────────────────
    // When true, the exact JPEG sent to the server is saved to device storage.
    // Debug builds only — toggled from IRKit Playground.
    @Volatile var saveDebugFrames: Boolean = false

    // ── Postprocess thresholds — MUST match iOS exactly ──────────────────────
    const val MASK_THRESHOLD: Float = 0.85f
    const val TRIM_PERCENT: Double = 0.02
    const val PADDING_PERCENT: Double = 0.10
}
