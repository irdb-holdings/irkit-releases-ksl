package com.irdb.irkit

import com.google.gson.reflect.TypeToken
import com.irdb.irkit.response.LensResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_44/lenses
suspend fun BackendService.getLens(): LensResponse =
    withContext(Dispatchers.IO) {
        val endpoint = "/lenses"
        val response = request<BaseResponse<LensResponse>>(
            endpoint = endpoint,
            method = HttpMethod.GET,
            responseType = object : TypeToken<BaseResponse<LensResponse>>() {}.type
        )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        payload.results
    }
