package com.irdb.irkit

import android.util.Log
import com.google.common.reflect.TypeToken
import com.irdb.irkit.response.UserIRCodesResponse

data class UserIRCodesPaginatedResponse(
    val completed: Boolean = false,
    val count: Int = 0,
    val nextOffset: Int = 0,
    val pages: Int = 0,
    val results: UserIRCodesResponse? = null
)

suspend fun UserService.getUserIRCodes(offset: Int = 0): UserIRCodesPaginatedResponse {
    var endpoint = "/Images?offset=$offset"
    // TMH REMOVE THIS
    // TODO: REMOVE THIS
    // if (BackendService.isDebugMode()){
    //     endpoint = "$endpoint&user=1200"
    // }

    val response = BackendService.request<BaseResponse<UserIRCodesResponse>>(
        endpoint = endpoint,
        method = HttpMethod.GET,
        responseType = object : TypeToken<BaseResponse<UserIRCodesResponse>>() {}.type
    )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create anonymous user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }

    val completed = payload.completed
    val count = payload.count
    val nextOffset = payload.nextOffset
    val pages = payload.pages
    val results = payload.results

    println("Completed: $completed")
    println("Count: $count")
    println("NextOffset: $nextOffset")
    println("Pages: $pages")

    return UserIRCodesPaginatedResponse(
        completed = completed,
        count = count,
        nextOffset = nextOffset,
        pages = pages,
        results = results
    )
}

/*
getUserIRCodes Response:
        {
          "Completed": true,
          "Count": 1,
          "Environment": "DEV",
          "GCFVersion": "development-v1-43-00754-kup",
          "NextOffset": 20,
          "Pages": 1,
          "Results": {
            "Images": [
              {
                "campaignID": 0,
                "countQueries": 0,
                "editingAllowed": false,
                "imageHeight": 0,
                "imageID": "0198334811EB7155AB311F14C3153C64",
                "imageSize": 0,
                "imageStatus": "publish",
                "imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/4a0b1dfadfb14daea2e9d0aae382ab4c.jpeg",
                "ImageUser": {
                  "fullName": "",
                  "profileUrl": "",
                  "userID": 64119,
                  "userName": ""
                },
                "imageUserID": 64119,
                "imageWidth": 0,
                "internalID": 304095,
                "latitude": 34.0034,
                "longitude": -84.4605,
                "metaArray": [],
                "save": false,
                "timeArchived": "0",
                "title": ""
              }
            ]
          },
          "TimeUsed": 47.0
        }
 */
