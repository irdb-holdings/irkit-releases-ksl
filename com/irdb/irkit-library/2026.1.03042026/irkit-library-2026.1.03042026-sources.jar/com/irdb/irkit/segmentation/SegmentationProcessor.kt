package com.irdb.irkit.segmentation

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.net.Uri
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.nio.FloatBuffer

/**
 * ONNX segmentation inference engine.
 *
 * Exact port of iOS SegmentationProcessor — same model, same preprocessing,
 * same postprocessing algorithm. Both platforms produce the same bounding box
 * for the same input image.
 *
 * Lifecycle: create once per camera session, call [preprocessImage] + [runInference] +
 * [postprocessMask] per frame, call [close] when done.
 *
 * @param context Application context for loading the model from assets
 * @param useNnapi Whether to attempt NNAPI acceleration (set false for known-bad Exynos devices)
 */
class SegmentationProcessor(
    private val context: Context,
    private val useNnapi: Boolean = true
) {

    companion object {
        private const val TAG = "SegmentationProcessor"
        private const val MODEL_NAME = "segmentation_gazenet_transformer.onnx"
        private const val INPUT_SIZE = 384
    }

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()

    private val session: OrtSession by lazy {
        val options = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(2)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            if (useNnapi) {
                try { addNnapi() } catch (_: Exception) { /* fall back to CPU */ }
            }
        }
        val bytes = context.assets.open(MODEL_NAME).readBytes()
        env.createSession(bytes, options)
    }

    val isReady: Boolean get() = try { session; true } catch (_: Exception) { false }

    // -------------------------------------------------------------------------
    // EXIF rotation correction — only needed for JPEGs loaded from disk
    // (snapshot/gallery path). NOT needed for live CameraX frames since
    // processFrame() already handles rotation.
    //
    // Device-dependent: Pixel typically needs it, some Samsungs do not.
    // This is a no-op when EXIF says ORIENTATION_NORMAL.
    // -------------------------------------------------------------------------
    fun correctBitmapOrientation(bitmap: Bitmap, imageUri: Uri): Bitmap {
        val exif = try {
            context.contentResolver.openInputStream(imageUri)?.use { ExifInterface(it) }
        } catch (_: Exception) { null } ?: return bitmap

        val orientation = exif.getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL
        )
        val matrix = android.graphics.Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            else -> return bitmap
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    // -------------------------------------------------------------------------
    // Preprocess bitmap into ONNX input tensor.
    //
    // Matches iOS SegmentationProcessor.makeInputTensor exactly:
    //   1. Resize to 384x384 (bilinear)
    //   2. Channel order: BGR (NOT RGB — model trained on BGR)
    //   3. Layout: NCHW — all B values, then G, then R
    //   4. Normalization: /255f only (no ImageNet mean/std subtraction)
    // -------------------------------------------------------------------------
    fun preprocessImage(bitmap: Bitmap): FloatArray {
        val scaled = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)
        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        scaled.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)

        val planeSize = INPUT_SIZE * INPUT_SIZE
        val tensor = FloatArray(3 * planeSize)
        for (i in pixels.indices) {
            val px = pixels[i]
            tensor[0 * planeSize + i] = Color.blue(px) / 255f   // plane 0 = B
            tensor[1 * planeSize + i] = Color.green(px) / 255f  // plane 1 = G
            tensor[2 * planeSize + i] = Color.red(px) / 255f    // plane 2 = R
        }
        return tensor
    }

    // -------------------------------------------------------------------------
    // Run ONNX inference.
    //
    // Model inputs:
    //   "image"  — [1, 3, 384, 384] float32 NCHW BGR tensor
    //   "gaze_x" — [1] float32 scalar, normalized 0–1 (default = 0.5 = center)
    //   "gaze_y" — [1] float32 scalar, normalized 0–1 (default = 0.5 = center)
    //
    // Returns: Pair(maskFloatArray, outputShapeLongArray)
    // -------------------------------------------------------------------------
    fun runInference(
        imageData: FloatArray,
        gazeX: Float = SegmentationConfig.gazeX,
        gazeY: Float = SegmentationConfig.gazeY
    ): Pair<FloatArray, LongArray> {
        val imageTensor = OnnxTensor.createTensor(
            env,
            FloatBuffer.wrap(imageData),
            longArrayOf(1, 3, INPUT_SIZE.toLong(), INPUT_SIZE.toLong())
        )
        val gazeXTensor = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(floatArrayOf(gazeX)), longArrayOf(1)
        )
        val gazeYTensor = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(floatArrayOf(gazeY)), longArrayOf(1)
        )

        try {
            val inputs = mapOf(
                "image" to imageTensor,
                "gaze_x" to gazeXTensor,
                "gaze_y" to gazeYTensor
            )

            session.run(inputs).use { result ->
                val outputTensor: OnnxTensor = try {
                    result.get("output").get() as OnnxTensor
                } catch (_: Exception) {
                    result.get(0) as OnnxTensor
                }
                val shape = outputTensor.info.shape
                val buf = outputTensor.floatBuffer
                val mask = FloatArray(buf.remaining())
                buf.get(mask)
                return Pair(mask, shape)
            }
        } finally {
            imageTensor.close()
            gazeXTensor.close()
            gazeYTensor.close()
        }
    }

    // -------------------------------------------------------------------------
    // Parse output tensor shape into (maskWidth, maskHeight).
    // Matches iOS postprocessMask shape-parsing logic exactly.
    // -------------------------------------------------------------------------
    fun parseMaskDimensions(shape: LongArray): Pair<Int, Int> {
        return when {
            shape.size >= 4 -> Pair(
                maxOf(1, shape[shape.size - 1].toInt()),
                maxOf(1, shape[shape.size - 2].toInt())
            )
            shape.size == 3 -> Pair(
                maxOf(1, shape[2].toInt()),
                maxOf(1, shape[1].toInt())
            )
            shape.size == 2 -> Pair(
                maxOf(1, shape[1].toInt()),
                maxOf(1, shape[0].toInt())
            )
            else -> Pair(INPUT_SIZE, INPUT_SIZE)
        }
    }

    // -------------------------------------------------------------------------
    // Convert mask to bounding box.
    //
    // Exact port of iOS SegmentationProcessor.postprocessMask:
    //   1. Threshold mask at 0.85 — count above-threshold pixels per row/column
    //   2. If total == 0 return null (no object detected)
    //   3. trimTarget = max(1, total * 2%)
    //   4. Trim 2% from each edge of the histogram to find tight box
    //   5. Pad box by 10% in each direction, clamp to [0, size-1]
    //   6. Normalize to [0, 1] by dividing by maskWidth / maskHeight
    //
    // Returns RectF(left, top, right, bottom) in [0,1], or null if no object.
    // -------------------------------------------------------------------------
    fun postprocessMask(
        mask: FloatArray,
        maskWidth: Int,
        maskHeight: Int,
        threshold: Float = SegmentationConfig.MASK_THRESHOLD,
        trimPercent: Double = SegmentationConfig.TRIM_PERCENT,
        paddingPercent: Double = SegmentationConfig.PADDING_PERCENT
    ): RectF? {
        val histX = IntArray(maskWidth)
        val histY = IntArray(maskHeight)
        var total = 0

        for (y in 0 until maskHeight) {
            for (x in 0 until maskWidth) {
                if (mask[y * maskWidth + x] > threshold) {
                    histX[x]++
                    histY[y]++
                    total++
                }
            }
        }
        if (total == 0) return null

        val trimTarget = maxOf(1, (total * trimPercent).toInt())

        fun trimMin(arr: IntArray): Int {
            var running = 0
            for (i in arr.indices) {
                running += arr[i]
                if (running >= trimTarget) return i
            }
            return 0
        }

        fun trimMax(arr: IntArray): Int {
            var running = 0
            for (i in arr.indices.reversed()) {
                running += arr[i]
                if (running >= trimTarget) return i
            }
            return arr.size - 1
        }

        var minX = trimMin(histX)
        var maxX = trimMax(histX)
        var minY = trimMin(histY)
        var maxY = trimMax(histY)

        val padX = ((maxX - minX + 1) * paddingPercent).toInt()
        val padY = ((maxY - minY + 1) * paddingPercent).toInt()
        minX = maxOf(0, minX - padX)
        maxX = minOf(maskWidth - 1, maxX + padX)
        minY = maxOf(0, minY - padY)
        maxY = minOf(maskHeight - 1, maxY + padY)

        val w = maxOf(1, maxX - minX + 1)
        val h = maxOf(1, maxY - minY + 1)
        return RectF(
            minX / maskWidth.toFloat(),
            minY / maskHeight.toFloat(),
            (minX + w) / maskWidth.toFloat(),
            (minY + h) / maskHeight.toFloat()
        )
    }

    // -------------------------------------------------------------------------
    // Build a visualization bitmap from the raw mask.
    // Each pixel above threshold → semi-transparent green.
    // -------------------------------------------------------------------------
    fun buildMaskBitmap(
        mask: FloatArray,
        maskWidth: Int,
        maskHeight: Int,
        threshold: Float = SegmentationConfig.MASK_THRESHOLD
    ): Bitmap {
        val pixels = IntArray(maskWidth * maskHeight)
        for (i in pixels.indices) {
            pixels[i] = if (mask[i] > threshold) 0x8000FF00.toInt() else Color.TRANSPARENT
        }
        val bmp = Bitmap.createBitmap(maskWidth, maskHeight, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, maskWidth, 0, 0, maskWidth, maskHeight)
        return bmp
    }

    fun close() {
        try { session.close() } catch (_: Exception) {}
        try { env.close() } catch (_: Exception) {}
    }
}
