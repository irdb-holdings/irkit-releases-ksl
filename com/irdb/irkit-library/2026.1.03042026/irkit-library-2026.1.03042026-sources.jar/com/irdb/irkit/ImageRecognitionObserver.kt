package com.irdb.irkit


import java.util.Date
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.irdb.irkit.models.ClipInfoData

private fun ImageModel?.getCampaignIdForAnalytics(): String? {
    return this?.campaignId?.takeIf { campaignId -> campaignId > 0 }?.toString()
}

private fun ImageModel?.getCampaignNameForAnalytics(): String? {
    return this?.campaignName?.takeIf { campaignName -> campaignName.isNotEmpty() }
}

/**
 * Number of seconds to show non-expanded notification before auto-hiding
 * Matches iOS auto-dismiss timing (Phase 4 optimization)
 */
private const val NUMBER_OF_SECONDS_TO_SHOW_NOTIFICATION = 3  // Changed from 5s to match iOS

/**
 * A singleton class that manages and observes image recognition states and events in the application.
 * This observer handles the lifecycle of recognized images, their caching, and state management.
 *
 * Key features:
 * - Maintains state of currently recognized images
 * - Handles image caching with expiration
 * - Manages loading states for image details
 * - Provides reactive state flows for UI updates
 * - Tracks analytics internally using AnalyticsClient (if initialized)
 *
 * States exposed:
 * - lastSeenImage: Flow of the most recently recognized image
 * - isRecognizingAny: Flow indicating if any image recognition is in progress
 * - isLoadingDetails: Flow indicating if image details are being loaded
 *
 * Usage:
 * ```
 * val observer = ImageRecognitionObserver.getInstance()
 * observer.handleImageSeen(imageId, trackingId, bucketName)
 * ```
 */
class ImageRecognitionObserver private constructor() {
    internal val _lastSeenImage = MutableStateFlow<ImageModel?>(null)
    val lastSeenImage = _lastSeenImage.asStateFlow()

    internal val _isRecognizingAny = MutableStateFlow(false)
    val isRecognizingAny = _isRecognizingAny.asStateFlow()

    internal val _isLoadingDetails = MutableStateFlow(false)
    val isLoadingDetails = _isLoadingDetails.asStateFlow()

    internal val seenImages = HashMap<String, Pair<Date, ImageModel>>()
    private val imageCache = HashMap<String, Pair<Date, ImageModel>>()
    internal var currentlyLoadingImageId: String? = null
    internal val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var isContentExpanded = false
    private val cacheDuration = 3 * 60 * 1000L // 3 minutes in milliseconds

    // Phase 3: Deduplication tracking (matches iOS implementation)
    private val inProgressFetches = mutableSetOf<String>() // Prevents concurrent fetches for same imageID
    private val recentAssetKeyTimestamps = mutableMapOf<String, Long>() // Asset clip throttling (5s window)
    private val recentHistoryAddTimestamps = mutableMapOf<String, Long>() // History API throttling (3min window)

    init {
        setupTimer()
    }

    /**
     * Internal helper to track analytics events using AnalyticsClient.
     * Gracefully handles cases where AnalyticsClient is not initialized.
     */
    private fun trackScanEventInternal(
        scanType: String,
        duration: Double,
        matched: Boolean,
        trackingId: String,
        image: ImageModel?,
        viewSource: String? = null,
        similarCount: Int? = null
    ) {
        try {
            val analyticsClient = com.irdb.analytics.AnalyticsClient.getInstance()
            
            // Map scanType string to ScanType enum
            val scanTypeEnum = when (scanType.lowercase()) {
                "live" -> com.irdb.analytics.ScanType.LIVE
                "snapshot" -> com.irdb.analytics.ScanType.SNAPSHOT
                "creator" -> com.irdb.analytics.ScanType.CREATOR
                "capturebutton" -> com.irdb.analytics.ScanType.CAPTURE_BUTTON
                else -> com.irdb.analytics.ScanType.SNAPSHOT
            }
            
            // Map viewSource string to ViewSource enum, or infer from scanType
            val viewSourceEnum = when {
                viewSource != null -> {
                    when (viewSource.lowercase()) {
                        "livescan", "live_scan" -> com.irdb.analytics.ViewSource.LIVE_SCAN
                        "snapshot" -> com.irdb.analytics.ViewSource.SNAPSHOT
                        "creator" -> com.irdb.analytics.ViewSource.CREATOR
                        else -> null
                    }
                }
                else -> {
                    // Infer viewSource from scanType if not provided
                    when (scanType.lowercase()) {
                        "live" -> com.irdb.analytics.ViewSource.LIVE_SCAN
                        "snapshot" -> com.irdb.analytics.ViewSource.SNAPSHOT
                        "creator" -> com.irdb.analytics.ViewSource.CREATOR
                        else -> null
                    }
                }
            }
            
            // Extract similarCount from image if not provided and image is FullImage
            val finalSimilarCount = similarCount ?: (image as? ImageModel.FullImage)?.countSimilar
            
            // Only track matched events (unmatched events are tracked elsewhere if needed)
            if (matched) {
                // Construct imageUrlOfScan from trackingId and bucketName (required after match per analytics spec)
                val imageUrlOfScan = trackingId?.takeIf { it.isNotEmpty() }?.let { tid ->
                    val bucket = image?.bucketName?.ifEmpty { "irdbMain" } ?: "irdbMain"
                    analyticsClient.getQueryImageUrlForTrackingId(tid, bucket)
                }

                analyticsClient.trackScanEvent(
                    scanType = scanTypeEnum,
                    matched = true,
                    imageId = image?.imageId,
                    campaignId = image.getCampaignIdForAnalytics(),
                    campaignName = image.getCampaignNameForAnalytics(),
                    scanTrackingId = trackingId,
                    similarCount = finalSimilarCount,
                    failed = false,
                    imageUrlOfScan = imageUrlOfScan,
                    viewSource = viewSourceEnum,
                    imageTitle = image?.title,
                    imageUrl = image?.displayImageUrl
                    // bucketName comes from AnalyticsConfig, not from image data
                )
            }
        } catch (e: IllegalStateException) {
            // AnalyticsClient not initialized - gracefully skip tracking
            // This is expected for client apps that don't initialize analytics
        } catch (e: Exception) {
            // Log other errors but don't crash
            android.util.Log.e("ImageRecognitionObserver", "Error tracking analytics event", e)
        }
    }

    /**
     * Controls whether the content is in an expanded state.
     * When content is expanded, the automatic cleanup of old images is suspended.
     *
     * @param expanded true if content should be expanded, false otherwise
     */
    fun setContentExpanded(expanded: Boolean) {
        isContentExpanded = expanded
    }

    /**
     * Clears all recognition state data.
     * This includes:
     * - Clearing all seen images from memory
     * - Clearing the image cache to prevent reusing cached images
     * - Resetting the last seen image to null
     * - Setting recognition state to false
     */
    fun clearLastSeenImage() {
        seenImages.clear()
        imageCache.clear() // Clear cache to prevent reusing cached images after reset
        _lastSeenImage.value = null
        _isRecognizingAny.value = false
    }

    /**
     * Handles a successful image recognition event.
     * Updates the observer's state with the matched image information and tracks the event.
     *
     * @param imageSearchResult The result containing the matched image and search metadata
     */
    fun handleImageRecognized(imageSearchResult: ImageSearchResult) {
        imageSearchResult.matchedImage?.let { matchedImage ->
            seenImages[matchedImage.imageId] = Date() to matchedImage
            _lastSeenImage.value = matchedImage
            _isLoadingDetails.value = false
            _isRecognizingAny.value = true
        }

        trackScanEventInternal(
            scanType = if (imageSearchResult.isFromLiveVisualSearch) "live" else "snapshot",
            duration = imageSearchResult.queryTimeMs,
            matched = imageSearchResult.isSuccess,
            trackingId = imageSearchResult.trackingId,
            image = imageSearchResult.matchedImage
        )
    }

    /**
     * Handles a failed image recognition event.
     * Creates a placeholder for the unrecognized image, updates the observer's state,
     * and tracks the event.
     *
     * @param imageSearchResult The result containing the search metadata for the unrecognized image
     */
    fun handleImageNotRecognized(imageSearchResult: ImageSearchResult) {
        val placeholderImage = ImageModel.NotRecognized(UUID.randomUUID().toString())
        seenImages[placeholderImage.imageId] = Date() to placeholderImage
        _lastSeenImage.value = placeholderImage
        _isLoadingDetails.value = false
        _isRecognizingAny.value = true

        // Do not track live visual search events
        // Note: Unmatched events are typically not tracked via AnalyticsClient
        // (only matched events are tracked to avoid spam)
    }

    fun handleImageSeen(imageId: String, trackingId: String, bucketName: String) {
        scope.launch {
            // 1. If we're already showing this image and it's not a placeholder, just update timestamp
            seenImages[imageId]?.let { (_, currentImage) ->
                if (currentImage !is ImageModel.Placeholder) {
                    seenImages[imageId] = Date() to currentImage
                    // NOTE: Still send scan analytics for every recognition.
                    // To restore "first only" behavior, remove this call.
                    trackScanEventInternal(
                        scanType = "live",
                        duration = 0.0,
                        matched = true,
                        trackingId = trackingId,
                        image = currentImage
                    )
                    return@launch // ⭐ EXIT - no fetch needed, just timestamp update
                }
            }

            // 2. Check if fetch already in progress (PHASE 3: Prevents concurrent duplicate fetches)
            synchronized(inProgressFetches) {
                if (inProgressFetches.contains(imageId)) {
                    android.util.Log.d("ImageRecognitionObserver", "Fetch already in progress for $imageId")
                    return@launch // ⭐ EXIT - prevents concurrent duplicate fetches
                }
                inProgressFetches.add(imageId)
            }

            // 3. Asset key throttling (PHASE 3: Prevents rapid re-fetches of asset clips)
            val assetKey = "$trackingId:$bucketName"
            recentAssetKeyTimestamps[assetKey]?.let { lastTime ->
                val timeSinceLastFetch = System.currentTimeMillis() - lastTime
                if (timeSinceLastFetch < ASSET_THROTTLE_WINDOW_MS) {
                    synchronized(inProgressFetches) { inProgressFetches.remove(imageId) }
                    android.util.Log.d("ImageRecognitionObserver", "Throttling asset fetch for $assetKey (${timeSinceLastFetch}ms < ${ASSET_THROTTLE_WINDOW_MS}ms)")
                    return@launch // ⭐ EXIT - too soon since last fetch
                }
            }
            recentAssetKeyTimestamps[assetKey] = System.currentTimeMillis()

            // 4. Legacy check (kept for compatibility)
            if (currentlyLoadingImageId == imageId) {
                synchronized(inProgressFetches) { inProgressFetches.remove(imageId) }
                return@launch
            }

            currentlyLoadingImageId = imageId

            // Create timeout coroutine
            val timeoutJob = scope.launch {
                delay(500) // 0.5 seconds timeout
                _isLoadingDetails.value = true
                if (seenImages[imageId] == null) {
                    val placeholderImage = ImageModel.Placeholder(imageId)
                    seenImages[imageId] = Date() to placeholderImage
                    _lastSeenImage.value = placeholderImage
                    _isRecognizingAny.value = true
                }
            }

            // Fetch actual data
            try {
                val cachedImage = getCachedImage(imageId)
                val matchedImage = if (cachedImage == null) {
                    android.util.Log.d("ImageResult", "Cache MISS for imageId: $imageId - Loading from REST API")
                    val fetchedImage = ImageModel.fetchImage(imageId, trackingId, bucketName)
                    // do not track deeplinks
                    if (!trackingId.equals("deeplink")) { // Using literal instead of constants reference
                        if (fetchedImage != null) {
                            // Launch in separate coroutine to avoid blocking live mode processing
                            CoroutineScope(Dispatchers.IO).launch {
                                trackScanEventInternal(
                                    scanType = "live",
                                    duration = 0.0,
                                    matched = true,
                                    trackingId = trackingId,
                                    image = fetchedImage
                                )
                            }
                        }
                    } else {
                        // Set tells the rest of the code it was not searched on it was brought into the system
                        // through a deeplink or application link
                        if (fetchedImage != null) {
                            fetchedImage.fromDeepLink = true
                        }
                    }
                    fetchedImage
                } else {
                    android.util.Log.d("ImageResult", "Cache HIT for imageId: $imageId - Using cached data")
                    // NOTE: Still send scan analytics for cache-hit recognitions.
                    // To restore "first only" behavior, remove this call.
                    if (!trackingId.equals("deeplink")) {
                        trackScanEventInternal(
                            scanType = "live",
                            duration = 0.0,
                            matched = true,
                            trackingId = trackingId,
                            image = cachedImage
                        )
                    }
                    cachedImage
                }

                matchedImage?.let { image ->
                    if (getCachedImage(imageId) == null) {
                        cacheImage(image, imageId)
                    }
                    withContext(Dispatchers.Main) {
                        seenImages[imageId] = Date() to image
                        _lastSeenImage.value = image
                        _isLoadingDetails.value = false
                        _isRecognizingAny.value = true
                    }
                }
            } finally {
                timeoutJob.cancel()
                currentlyLoadingImageId = null
                _isLoadingDetails.value = false
                // PHASE 3: Clean up in-progress tracking
                synchronized(inProgressFetches) {
                    inProgressFetches.remove(imageId)
                }
            }
        }
    }

    fun handleImageNotSeen() {
        _isRecognizingAny.value = false
    }

    /**
     * PHASE 3: Throttle history add API calls to prevent spam.
     * Only add to history if not added in last 3 minutes.
     * Matches iOS implementation to reduce backend load.
     */
    internal fun shouldAddToHistory(imageId: String): Boolean {
        val now = System.currentTimeMillis()
        recentHistoryAddTimestamps[imageId]?.let { lastTime ->
            if (now - lastTime < HISTORY_THROTTLE_WINDOW_MS) {
                android.util.Log.d("ImageRecognitionObserver", "Throttling history add for $imageId (within 3-minute window)")
                return false // Too soon - don't spam history API
            }
        }
        recentHistoryAddTimestamps[imageId] = now
        return true
    }

    fun getCachedImage(imageId: String): ImageModel? {
        return imageCache[imageId]?.let { (cacheDate, cachedImage) ->
            val timeSinceCache = System.currentTimeMillis() - cacheDate.time
            android.util.Log.d("ImageResult", "Checking cache for imageId: $imageId, timeSinceCache: ${timeSinceCache}ms, cacheDuration: ${cacheDuration}ms")
            if (timeSinceCache < cacheDuration) {
                android.util.Log.d("ImageResult", "Cache VALID for imageId: $imageId")
                cachedImage
            } else {
                android.util.Log.d("ImageResult", "Cache EXPIRED for imageId: $imageId, removing from cache")
                imageCache.remove(imageId)
                null
            }
        } ?: run {
            android.util.Log.d("ImageResult", "No cache entry found for imageId: $imageId")
            null
        }
    }

    fun cacheImage(image: ImageModel, imageId: String) {
        android.util.Log.d("ImageResult", "Caching imageId: $imageId")
        imageCache[imageId] = Date() to image
    }

    private fun setupTimer() {
        scope.launch {
            while (isActive) {
                removeOldImages()
                delay(3000) // Check every 3 seconds (matches iOS)
            }
        }
    }

    private fun removeOldImages() {
        // Skip cleanup if content is expanded
        if (isContentExpanded) {
            return
        }

        val currentTime = System.currentTimeMillis()

        // Remove old images from seenImages
        seenImages.entries.removeIf { (_, value) ->
            currentTime - value.first.time > (NUMBER_OF_SECONDS_TO_SHOW_NOTIFICATION * 1000L) // Use configurable constant
        }

        // Remove old images from imageCache
        imageCache.entries.removeIf { (_, value) ->
            currentTime - value.first.time > cacheDuration
        }

        // Update lastSeenImage and isRecognizingAny
        if (seenImages.isEmpty()) {
            _lastSeenImage.value = null
            _isRecognizingAny.value = false
        } else {
            // Find the most recently seen image
            val mostRecentImage = seenImages.maxByOrNull { it.value.first }?.value?.second
            _lastSeenImage.value = mostRecentImage

            // Check if the current lastSeenImage is still in seenImages
            _lastSeenImage.value?.let { current ->
                if (seenImages[current.imageId] == null) {
                    _lastSeenImage.value = mostRecentImage
                }
            }
        }
    }

    companion object {
        // Phase 3: Deduplication constants (matches iOS implementation)
        private const val ASSET_THROTTLE_WINDOW_MS = 5000L // 5 seconds - prevents rapid re-fetches of asset clips
        private const val HISTORY_THROTTLE_WINDOW_MS = 180000L // 3 minutes - prevents history API spam

        @Volatile
        private var instance: ImageRecognitionObserver? = null

        fun getInstance(): ImageRecognitionObserver {
            return instance ?: synchronized(this) {
                instance ?: ImageRecognitionObserver().also { instance = it }
            }
        }
    }
}
