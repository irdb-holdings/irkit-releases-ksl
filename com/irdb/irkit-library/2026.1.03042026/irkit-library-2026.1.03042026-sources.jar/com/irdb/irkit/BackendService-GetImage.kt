package com.irdb.irkit

import android.util.Log
import com.google.gson.JsonParser
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.BackendService.TAG
import com.irdb.irkit.BackendService.addImageToUsersHistory
import com.irdb.irkit.BackendService.firebaseToken
import com.irdb.irkit.BackendService.gson
import com.irdb.irkit.BackendService.request
import com.irdb.irkit.dto.EditableImageDto
import com.irdb.irkit.dto.ImageDto
import com.irdb.irkit.dto.ImageDtoConverter
import com.irdb.irkit.response.ImageContainer

/**
 * Retrieves an [ImageDto] from the server for the specified image ID.
 *
 * This function fetches the image data from the server and returns it as an [ImageDto] object. The
 * returned object contains all the read-only properties of the image including meta items,
 * products, and basic information. This is the standard way to retrieve image data for display
 * purposes.
 *
 * Note: If you need to edit the image, use [getEditableImage] instead, which returns an
 * [EditableImageDto] that can be modified and uploaded back to the server.
 *
 * @param imageId The unique identifier of the image to retrieve
 *
 * @return An [ImageDto] object containing all the properties of the image
 *
 * @throws BackendServiceError.ServerError if the server request fails or the image is not found
 *
 * @sample
 * ```kotlin
 * val image = getImage("your-image-id")
 *
 * // Access read-only properties
 * println("Image title: ${image.title}")
 * println("Image description: ${image.metaContent.description}")
 * println("Meta items count: ${image.metaArray.size}")
 *
 * // Display the image
 * imageView.load(image.imageUrl)
 * ```
 *
 * @see getEditableImage for retrieving an editable version of the image
 */
suspend fun getImage(imageId: String, logThisInHistory: Boolean = true): ImageDto {
    val endpoint = "/Images/$imageId"

    val response =
            request<BaseResponse<ImageContainer>>(
                    endpoint = endpoint,
                    method = HttpMethod.GET,
                    responseType = object : TypeToken<BaseResponse<ImageContainer>>() {}.type
            )

    if (BackendService.isDebugMode()) {
        Log.i("json", gson.toJson(response))
    }

    if (!response.succeeded || response.payload == null) {
        if (response.payload == null) {
            Log.e(TAG, "getImage: Payload == null")
        }
        if (!response.succeeded) {
            Log.e(TAG, "getImage: response.succeeded did not succeeded")
        }
        try {
            Log.e(TAG, "getImage: sdkapikey=${BackendService.getSubscriptionKey()}")
        } catch (_: Exception) {
            Log.e(TAG, "getImage: sdkapikey=unable to retrieve")
        }
        if (response.errorMessage == "ImageNotFound") {
            throw BackendServiceError.ImageNotFound
        }
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val img = payload.results.image

    // PHASE 3: Throttle history add to prevent API spam (3-minute window)
    if (logThisInHistory) {
        firebaseToken?.let { token ->
            if (ImageRecognitionObserver.getInstance().shouldAddToHistory(imageId)) {
                addImageToUsersHistory(imageId, token)
            }
        }
    }

    return img
}

/**
 * Resolves an IREngine recognition response via the /lookup endpoint.
 * The raw JSON response body from IREngine must be provided as-is.
 */
suspend fun lookupImage(rawRecognitionJson: String, logThisInHistory: Boolean = true): ImageDto {
    val endpoint = "/lookup"
    val jsonElement = try {
        JsonParser.parseString(rawRecognitionJson)
    } catch (e: Exception) {
        throw BackendServiceError.ParseError
    }

    val response =
            request<BaseResponse<ImageContainer>>(
                    endpoint = endpoint,
                    method = HttpMethod.POST,
                    bodyParameters = jsonElement,
                    responseType = object : TypeToken<BaseResponse<ImageContainer>>() {}.type
            )

    if (BackendService.isDebugMode()) {
        Log.i("json", gson.toJson(response))
    }

    if (!response.succeeded || response.payload == null) {
        if (response.payload == null) {
            Log.e(TAG, "lookupImage: Payload == null")
        }
        if (!response.succeeded) {
            Log.e(TAG, "lookupImage: response.succeeded did not succeeded")
        }
        try {
            Log.e(TAG, "lookupImage: sdkapikey=${BackendService.getSubscriptionKey()}")
        } catch (_: Exception) {
            Log.e(TAG, "lookupImage: sdkapikey=unable to retrieve")
        }
        if (response.errorMessage == "ImageNotFound") {
            throw BackendServiceError.ImageNotFound
        }
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val img = payload.results.image

    if (logThisInHistory) {
        firebaseToken?.let { token ->
            if (ImageRecognitionObserver.getInstance().shouldAddToHistory(img.imageId)) {
                addImageToUsersHistory(img.imageId, token)
            }
        }
    }

    return img
}

/**
 * Retrieves an [EditableImageDto] from the server for the specified image ID.
 *
 * This function fetches the image data from the server and converts it to an [EditableImageDto]
 * that can be modified and uploaded back to the server. The returned object contains all the
 * editable properties of the image including meta items, products, and basic information.
 *
 * @param imageId The unique identifier of the image to retrieve
 *
 * @return An [EditableImageDto] object containing all the editable properties of the image
 *
 * @throws BackendServiceError.ServerError if the server request fails or the image is not found
 *
 * @sample
 * ```kotlin
 * val editableImage = getEditableImage("your-image-id")
 *
 * // Make changes to the editable image
 * editableImage.setTitleInMeta("New Title")
 * editableImage.setDescriptionInMeta("New Description")
 *
 * // Upload the changes
 * val success = BackendService.ImageMeta("your-image-id", userId, editableImage)
 * ```
 */
suspend fun getEditableImage(imageId: String): EditableImageDto {
    val endpoint = "/Images/$imageId"

    val response =
            request<BaseResponse<ImageContainer>>(
                    endpoint = endpoint,
                    method = HttpMethod.GET,
                    responseType = object : TypeToken<BaseResponse<ImageContainer>>() {}.type
            )

    if (BackendService.isDebugMode()) {
        Log.i("json", gson.toJson(response))
    }

    if (!response.succeeded || response.payload == null) {
        if (response.payload == null) {
            Log.e(TAG, "getEditableImage: Payload == null")
        }
        if (!response.succeeded) {
            Log.e(TAG, "getEditableImage: response.succeeded did not succeeded")
        }
        if (response.errorMessage == "ImageNotFound") {
            throw BackendServiceError.ImageNotFound
        }
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val img = payload.results.image


    // Convert ImageDto to EditableImageDto for editing
    return ImageDtoConverter.toEditableImageDto(img)
}

// /**
//  * Complete workflow function for editing and uploading image changes to the server.
//  *
//  * This function provides a convenient way to:
//  * 1. Retrieve an [EditableImageDto] from the server using the provided [imageId]
//  * 2. Apply changes to the editable image using the [onChanges] lambda
//  * 3. Validate the changes before uploading to ensure data integrity
//  * 4. Upload the modified image back to the server
//  *
//  * @param imageId The unique identifier of the image to edit
//  * @param userId The user ID associated with the image for authentication
//  * @param onChanges A lambda function that receives the [EditableImageDto] and applies the
// desired
//  * changes
//  *
//  * @return `true` if the upload was successful, `false` otherwise
//  *
//  * @throws BackendServiceError.ServerError if the server request fails or validation errors occur
//  * @throws Exception if any other error occurs during the process
//  *
//  * @sample
//  * ```kotlin
//  * val success = editAndUploadImage(
//  *     imageId = "your-image-id",
//  *     userId = 123
//  * ) { editableImage ->
//  *     editableImage.setTitleInMeta("Updated Title")
//  *     editableImage.setDescriptionInMeta("Updated Description")
//  *     editableImage.addLink("https://example.com", "New Link", "web")
//  * }
//  * ```
//  */
// suspend fun editAndUploadImage(
//         imageId: String,
//         userId: Int,
//         onChanges: (EditableImageDto) -> Unit
// ): Boolean {
//     try {
//         // Step 1: Get the editable image from server
//         val editableImage = getEditableImage(imageId)

//         // Step 2: Apply changes using the provided lambda
//         onChanges(editableImage)

//         // Step 3: Validate the changes before uploading
//         if (!editableImage.isValidForSaving()) {
//             val errors = editableImage.getValidationErrors()
//             throw BackendServiceError.ServerError("Validation failed: ${errors.joinToString(",
// ")}")
//         }

//         // Step 4: Upload the changes back to the server
//         return BackendService.ImageMeta(imageId, userId, editableImage)
//     } catch (e: Exception) {
//         Log.e(TAG, "Error editing and uploading image: ${e.message}")
//         throw e
//     }
// }

// /**
//  * Extension function that provides convenient methods for applying common editing operations to
// an
//  * [EditableImageDto].
//  *
//  * This function allows you to easily update multiple properties of an [EditableImageDto] in a
//  * single call, including title, description, card type, and managing links.
//  *
//  * @param newTitle Optional new title for the image. If provided, will update or create a "Title"
//  * meta item.
//  * @param newDescription Optional new description for the image. If provided, will update or
// create
//  * a "Description" meta item.
//  * @param newCardType Optional new card type for the image. If provided, will update or create a
//  * "CardType" meta item.
//  * @param linksToAdd List of links to add to the image. Each link is represented as a [Triple] of
//  * (url, title, icon).
//  * @param linksToRemove List of URLs to remove from the image's existing links.
//  *
//  * @sample
//  * ```kotlin
//  * val editableImage = getEditableImage("your-image-id")
//  *
//  * editableImage.applyCommonEdits(
//  *     newTitle = "Updated Title",
//  *     newDescription = "Updated Description",
//  *     newCardType = "BusinessCard",
//  *     linksToAdd = listOf(
//  *         Triple("https://example.com", "Example Link", "web"),
//  *         Triple("https://another.com", "Another Link", "link")
//  *     ),
//  *     linksToRemove = listOf("https://old-link.com")
//  * )
//  * ```
//  */
// fun EditableImageDto.applyCommonEdits(
//         newTitle: String? = null,
//         newDescription: String? = null,
//         newCardType: String? = null,
//         linksToAdd: List<Triple<String, String, String>> = emptyList(), // url, title, icon
//         linksToRemove: List<String> = emptyList() // urls to remove
// ) {
//     // Update title if provided
//     newTitle?.let { title -> setTitleInMeta(title) }

//     // Update description if provided
//     newDescription?.let { description -> setDescriptionInMeta(description) }

//     // Update card type if provided
//     newCardType?.let { cardType -> setCardTypeInMeta(cardType) }

//     // Remove specified links
//     linksToRemove.forEach { url -> removeMetaItem("Link", url) }

//     // Add new links
//     linksToAdd.forEach { (url, title, icon) -> addLink(url = url, title = title, icon = icon) }
// }
