package com.irdb.irkit

import android.util.Log
import com.irdb.irkit.dto.ImageDto
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.MetaContent.CardType
import com.irdb.irkit.dto.ParsedMetaItem
import com.irdb.irkit.dto.ProductInCampaignDto
import com.irdb.irkit.dto.UserDto
import com.irdb.irkit.dto.getMetaContentByType
import com.irdb.irkit.dto.parseMetaItems
import com.irdb.irkit.enums.CardTypes
import com.irdb.irkit.enums.ImageStatus
import com.irdb.irkit.enums.MetaTypes
import com.irdb.irkit.extensions.extractValueFromParentheses
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Date


sealed class ImageModel {
    abstract val imageId: String
    abstract val bucketName: String
    abstract val trackingId: String
    abstract val title: String
    abstract val description: String
    abstract val displayImageUrl: String
    abstract val campaignId: Int
    abstract val campaignName: String?
    abstract val products: List<ProductInCampaignDto>
    abstract val metaItems: List<ParsedMetaItem>
    abstract val location: Location?
    abstract var save: Boolean
    open val imageUser: UserDto? = null

    lateinit var status: ImageStatus
    var cropped: Boolean = false // if the image was cropped during initial registration, used for double checks
    var timeTheImageWasScanned: Long = 0 // what time the original image was scanned, used for double checks, in millis

    var fromDeepLink = false

    override fun toString(): String {
        return buildString {
            appendLine("ImageModel [${this@ImageModel::class.simpleName}]")
            appendLine("├─ Image ID: $imageId")
            appendLine("├─ Title: ${title.ifEmpty { "N/A" }}")
            appendLine("├─ Description: ${description.ifEmpty { "N/A" }}")
            appendLine("├─ Bucket: ${bucketName.ifEmpty { "N/A" }}")
            appendLine("├─ Tracking ID: ${trackingId.ifEmpty { "N/A" }}")
            appendLine("├─ Campaign ID: $campaignId")
            appendLine("├─ Display URL: ${displayImageUrl.ifEmpty { "N/A" }}")
            appendLine("├─ Status: $status")
            appendLine("├─ Saved: $save")
            appendLine("├─ Cropped: $cropped")
            appendLine("├─ From Deep Link: $fromDeepLink")

            if (timeTheImageWasScanned > 0) {
                appendLine("├─ Scan Time: ${Date(timeTheImageWasScanned)}")
            }

            location?.let { loc ->
                appendLine("├─ Location: (${loc.latitude}, ${loc.longitude})")
            }

            imageUser?.let { user ->
                appendLine("├─ User: $user")
            }

            if (products.isNotEmpty()) {
                appendLine("├─ Products (${products.size}):")
                products.forEachIndexed { index, product ->
                    appendLine("│  ${index + 1}. $product")
                }
            }

            if (metaItems.isNotEmpty()) {
                appendLine("├─ Meta Items (${metaItems.size}):")
                metaItems.forEachIndexed { index, item ->
                    appendLine("│  ${index + 1}. ${item.metaType}: ${item.content}")
                }
            }

            // Add subtype-specific information
            when (this@ImageModel) {
                is FullImage -> {
                    appendLine("├─ Image Dimensions: ${imageWidth}x$imageHeight")
                    appendLine("├─ Image Size: $imageSize bytes")
                    appendLine("├─ Manual Capture: $isFromManualCapture")
                }
                is RecognizedByAI -> {
                    appendLine("├─ AI Recognition: true")
                }
                is Placeholder -> {
                    appendLine("├─ Type: Placeholder")
                }
                is NotRecognized -> {
                    appendLine("├─ Type: Not Recognized")
                }
            }

            // Add computed properties
            appendLine("├─ Show Smart View: $showSmartView")
            appendLine("├─ Show in Chrome Tab: $showInChromeTab")
            appendLine("├─ Card Type: ${getCardType()}")
            appendLine("├─ Artist Name: ${getArtistName()}")

            getLinks()?.let { link ->
                appendLine("├─ Link URL: ${link.url}")
                appendLine("├─ Link Open in New Window: ${link.openInNewWindow}")
                appendLine("├─ Link Private Details: ${link.privateDetails}")
                appendLine("├─ Link On Scan Display: ${link.onScanDisplay}")
            }

            append("└─ End ImageModel")
        }
    }

    fun getImageTags(): String {
        val item = metaItems.find { it.metaTypeEnum == MetaTypes.Tags }
        val title = item?.content?.toString() ?: ""
        return title.extractValueFromParentheses()
    }

    fun getImageTitle(): String {
        val item = metaItems.find { it.metaTypeEnum == MetaTypes.Title }
        val title = item?.content?.toString() ?: ""
        return title.extractValueFromParentheses()
    }

    fun getArtistName(): String {
        val item = metaItems.find { it.metaTypeEnum == MetaTypes.ArtistName }
        val title = item?.content?.toString() ?: ""
        return title.extractValueFromParentheses()
    }

    fun getMetaTypeValue(metaType: MetaTypes): String {
        val item = metaItems.find { it.metaTypeEnum == metaType }
        val itemString = item?.content?.toString() ?: ""
        return itemString.extractValueFromParentheses()
    }

    fun getLinks(): MetaContent.Link? {
        return metaItems.find { it.metaTypeEnum() == MetaTypes.Link }?.content as? MetaContent.Link
    }

    fun getArtist(): MetaContent.Link? {
        return metaItems.find { it.metaTypeEnum() == MetaTypes.ArtistName }?.content as? MetaContent.Link
    }

    val showSmartView: Boolean
        get() {
            val links = getLinks()
//            return links?.let {
//                !it.openInNewWindow &&
//                    !it.privateDetails
//                it.onScanDisplay
//            } ?: false

            return links?.let { it.onScanDisplay && !it.openInNewWindow && !it.privateDetails } ?: false
        }

    val showInChromeTab: Boolean
        get() {
            val links = getLinks()
            return links?.let { it.openInNewWindow && it.url.isNotEmpty() } ?: false
        }

    fun getMetaItemForType(searchString: String): ParsedMetaItem? {
        return metaItems.find { it.metaType == searchString }
    }

    data class Placeholder(override val imageId: String) : ImageModel() {
        override val title: String = ""
        override val bucketName: String = ""
        override val trackingId: String = ""
        override val description: String = ""
        override val displayImageUrl: String = ""
        override val campaignId: Int = 0
        override val campaignName: String = ""
        override val products: List<ProductInCampaignDto> = emptyList()
        override val metaItems: List<ParsedMetaItem> = emptyList()
        override val location: Location? = null
        override var save: Boolean = false

        init {
            status = ImageStatus.PUBLISH
        }
    }

    data class NotRecognized(override val imageId: String) : ImageModel() {
        override val title: String = ""
        override val bucketName: String = ""
        override val trackingId: String = ""
        override val description: String = ""
        override val displayImageUrl: String = ""
        override val campaignId: Int = 0
        override val campaignName: String = ""
        override val products: List<ProductInCampaignDto> = emptyList()
        override val metaItems: List<ParsedMetaItem> = emptyList()
        override val location: Location? = null
        override var save: Boolean = false

        init {
            status = ImageStatus.PUBLISH
        }
    }

    data class RecognizedByAI(
        override val imageId: String,
        override val description: String
    ) : ImageModel() {
        override val title: String = "AI Recognition"
        override val bucketName: String = ""
        override val trackingId: String = ""
        override val displayImageUrl: String = ""
        override val campaignId: Int = 0
        override val campaignName: String = ""
        override val products: List<ProductInCampaignDto> = emptyList()
        override val metaItems: List<ParsedMetaItem> = emptyList()
        override val location: Location? = null
        override var save: Boolean = false

        init {
            status = ImageStatus.PUBLISH
        }
    }

    data class FullImage(
        override val imageId: String,
        override val bucketName: String,
        override val trackingId: String,
        override val title: String,
        override val description: String,
        override var displayImageUrl: String,
        override val campaignId: Int,
        override val campaignName: String,
        override val products: List<ProductInCampaignDto>,
        override val metaItems: List<ParsedMetaItem>,
        override val location: Location?,
        override val imageUser: UserDto? = null,
        override var save: Boolean = false,
        val imageWidth: Int,
        val imageHeight: Int,
        val imageSize: Int,
        val isFromManualCapture: Boolean = false,
        val countSaved: Int = 0,
        val countViews: Int = 0,
        val countComments: Int = 0,
        val countSimilar: Int = 0,
        val imageStatus: ImageStatus
    ) : ImageModel() {
        init {
            status = imageStatus
        }
    }




    companion object {
        suspend fun fetchImage(imageId: String, trackingId: String, bucketName: String): ImageModel? {
            return withContext(Dispatchers.IO) {
                try {
                    val response = getImage(imageId)
                    fromImageDto(response, trackingId, bucketName, isFromManualCapture = false)
                } catch (e: Exception) {
                    Log.e("network", e.toString())
                    null
                }
            }
        }

        fun fromImageDto(dto: ImageDto, trackingId: String, bucketName: String, isFromManualCapture: Boolean = false): FullImage {
            if (dto.imageId == "01982843552573B286D2C3E133FF7091") {
                Log.d("Crash", "imageid: ${dto.imageId} ${dto.imageUrl}")
            }

            return FullImage(
                imageId = dto.imageId,
                bucketName = bucketName,
                trackingId = trackingId,
                title = dto.getMetaContentByType<MetaContent.Title>("Title")?.value ?: "",
                description = dto.getMetaContentByType<MetaContent.Description>("Description")?.value ?: "",
                displayImageUrl = dto.imageUrl ?: dto.assetDisplayImage ?: "",
                campaignId = dto.campaignId,
                campaignName = dto.campaignName ?: "",
                products = dto.products,
                metaItems = dto.parseMetaItems(),
                location = if (dto.latitude != 0.0 && dto.longitude != 0.0) {
                    Location(dto.latitude, dto.longitude)
                } else {
                    null
                },
                imageWidth = dto.imageWidth,
                imageHeight = dto.imageHeight,
                imageSize = dto.imageSize,
                isFromManualCapture = isFromManualCapture,
                imageUser = dto.imageUser,
                save = dto.save,
                countSaved = dto.countSaved ?: 0,
                countViews = dto.countViews ?: 0,
                countComments = dto.countComments ?: 0,
                countSimilar = dto.countSimilar ?: 0,
                imageStatus = when ((dto.imageStatus as String?)?.lowercase() ?: "publish") {
                    "draft" -> ImageStatus.DRAFT
                    "publish" -> ImageStatus.PUBLISH
                    else -> ImageStatus.PUBLISH
                }
            )
        }

        fun fromAIResponse(aiResult: OpenAIService.OpenAIResult): ImageModel? {
            return when (aiResult) {
                is OpenAIService.OpenAIResult.Success -> {
                    if (aiResult.isSuccess) {
                        RecognizedByAI(
                            imageId = "ai_${System.currentTimeMillis()}",
                            description = aiResult.content
                        )
                    } else {
                        null
                    }
                }
                is OpenAIService.OpenAIResult.Error -> {
                    null
                }
            }
        }
    }
}

fun ImageModel.setParams(image: ImageModel? = null): Map<String, Any> {
    val params = mutableMapOf<String, Any>()

    params["imageID"] = imageId // this is only used by update call, query and add create their own in BE
    params["imageUrl"] = displayImageUrl
    params["status"] = status.toString()
    params["cropped"] = cropped
    params["scanTime"] = timeTheImageWasScanned

    // image?.let { bitmap -> // if image is not present, then we are updating textual fields
    //     params[JSONData.imageWidth.name] = bitmap.width
    //     params[JSONData.imageHeight.name] = bitmap.height

    //     currentImage = FireBaseHelper.downSizeImageForRegistration(bitmap)
    //     params[JSONData.imageSize.name] = currentImage.size
    // }

    // // If you are running in beta and you do not set bucket, it defaults to irdbMain
    // if (currentEnvironment == Environment.BETA && ImageModel.betaBucketName.isNotEmpty()) {
    //     params["bucket"] = ImageModel.betaBucketName // this is only available in Environment beta
    // }
    return params
}

data class Location(val latitude: Double, val longitude: Double)

// Get any meta content by type
inline fun <reified T : MetaContent> ImageModel.getMetaContent(type: String): T? {
    return metaItems.find { it.metaType == type }?.content as? T
}

// Convenience functions for common meta types

fun ImageModel.getCardType(): String {
    return getMetaContent<CardType>("CardType")?.value ?: ""
}

fun ImageModel.getCardTypeEmum(): CardTypes {
    val cardType = getMetaContent<CardType>("CardType")?.value?.lowercase() ?: ""

    when (cardType) {
        "artcard" -> return CardTypes.ArtCard
        "contact" -> return CardTypes.Contact
        "products", "productcard" -> return CardTypes.ProductCard
        "general" -> return CardTypes.General
    }
    return CardTypes.General
}

fun ImageModel.getLinks(): MetaContent.Link? = getMetaContent("Link")

fun ImageModel.getLinkArray(): List<MetaContent>? = getMetaContent("Link")

fun ImageModel.getTags(): List<String> = getMetaContent<MetaContent.Tags>("Tags")?.tags ?: emptyList()

fun ImageModel.getEmbeddedVideo(): String? = getMetaContent<MetaContent.EmbeddedVideo>("EmbeddedVideo")?.videoUrl

fun ImageModel.getCustomContent(): Map<String, Any>? = getMetaContent<MetaContent.Custom>("Custom")?.data
