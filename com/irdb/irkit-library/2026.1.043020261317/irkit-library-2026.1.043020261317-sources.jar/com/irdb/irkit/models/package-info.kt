/**
 * Domain models and data classes.
 * 
 * This package will contain:
 * - Core domain models
 * - Business logic entities
 * - Value objects
 * - Model converters and mappers
 */
package com.irdb.irkit.models