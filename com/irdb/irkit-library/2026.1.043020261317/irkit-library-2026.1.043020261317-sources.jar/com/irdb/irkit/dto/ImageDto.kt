package com.irdb.irkit.dto

import androidx.core.net.toUri
import com.google.gson.annotations.JsonAdapter
import com.google.gson.annotations.SerializedName

import com.irdb.irkit.enums.MetaTypes
import com.irdb.irkit.enums.SupportedWebSites
import com.irdb.irkit.enums.IRKitResourceProvider
import com.irdb.irkit.enums.getIconResId

/*
{
    "webUrl": "https://development-ircode-1a662.web.app/image/0198334811EB7155AB311F14C3153C64",
    "nativeUrl": "https://development-ircode-1a662.web.app/image/info/0198334811EB7155AB311F14C3153C64",
    "line1": "",
    "line2": "",
    "title": "",
    "displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/4a0b1dfadfb14daea2e9d0aae382ab4c.jpeg",
    "objectDetectionStatus": 0,
    "editingAllowed": false,
    "latitude": 34.0034,
    "longitude": -84.4605,
    "save": false,
    "timeArchived": 0,
    "fugacious": false,
    "imageStatus": "publish",
    "internalID": 304095,
    "imageID": "0198334811EB7155AB311F14C3153C64",
    "imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/4a0b1dfadfb14daea2e9d0aae382ab4c.jpeg",
    "imageUrlSmall": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/4a0b1dfadfb14daea2e9d0aae382ab4c.jpeg",
    "imageUserID": 64119,
    "imageCreated": 1753207019,
    "sponsored": 0,
    "transferInProcess": 0,
    "removeAfter": 0,
    "countSimilar": 0,
    "countSearches": 0,
    "countShares": 0,
    "countQueries": 0,
    "viewCount": 0,
    "timeScanned": 1753207276,
    "countViews": 1,
    "countSaved": 0,
    "countComments": 0,
    "ImageUser": {
      "userID": 64119,
      "fullName": "",
      "userName": "",
      "userType": "Anonymous",
      "profileUrl": ""
    },
    "metaArray": [],
    "productsArray": [],
    "masterTemplate": false,
    "imageCreatedReadable": "2025-07-22 05:56:59 pm UTC"
  }
 */
data class ImageDto(
        @SerializedName("editingAllowed") val editingAllowed: Boolean,
        @SerializedName("longitude") val longitude: Double,
        @SerializedName("latitude") val latitude: Double,
        @SerializedName("save") @JsonAdapter(BooleanTypeAdapter::class) val save: Boolean,
        @SerializedName("timeArchived") val timeArchived: String,
        @SerializedName("campaignID") val campaignId: Int,
        @SerializedName("campaignName") val campaignName: String?,
        @SerializedName("title") val title: String,
        @SerializedName("metaContent") val metaContent: MetaContentDto,
        @SerializedName("specialType") val specialType: String?,
        @SerializedName("imageStatus") val imageStatus: String,
        @SerializedName("internalID") val internalId: Int,
        @SerializedName("imageID") val imageId: String,
        @SerializedName("imageUserID") val imageUserId: Int,
        @SerializedName("ImageUser") val imageUser: UserDto?,
        @SerializedName("imageUrl") val imageUrl: String?,
        @SerializedName("imageWidth") val imageWidth: Int,
        @SerializedName("imageHeight") val imageHeight: Int,
        @SerializedName("imageSize") val imageSize: Int,
        @SerializedName("metaArray") val metaArray: List<MetaItem>,
        @SerializedName("countQueries") val countQueries: Int,
        @SerializedName("webUrl") val webUrl: String?,
        @SerializedName("nativeUrl") val nativeUrl: String?,
        @SerializedName("line1") val line1: String?,
        @SerializedName("line2") val line2: String?,
        @SerializedName("displayImageUrl") val displayImageUrl: String?,
        @SerializedName("objectDetectionStatus") val objectDetectionStatus: Int?,
        @SerializedName("fugacious") val fugacious: Boolean?,
        @SerializedName("imageCreated") val imageCreated: Long?,
        @SerializedName("sponsored") val sponsored: Int?,
        @SerializedName("transferInProcess") val transferInProcess: Int?,
        @SerializedName("removeAfter") val removeAfter: Int?,
        @SerializedName("countSimilar") val countSimilar: Int?,
        @SerializedName("countSearches") val countSearches: Int?,
        @SerializedName("countShares") val countShares: Int?,
        @SerializedName("viewCount") val viewCount: Int?,
        @SerializedName("timeScanned") val timeScanned: Long?,
        @SerializedName("countViews") val countViews: Int?,
        @SerializedName("countSaved") val countSaved: Int?,
        @SerializedName("countComments") val countComments: Int?,
        @SerializedName("productsArray") val productsArray: List<ProductInCampaignDto>?,
        @SerializedName("masterTemplate") val masterTemplate: Boolean?,
        @SerializedName("imageCreatedReadable") val imageCreatedReadable: String?,

        // fields added for assets
        // ============
        @SerializedName("displayImage")
        val assetDisplayImage: String?,

        @SerializedName("assetUrl")
        val assetUrl: String?,

        @SerializedName("assetID")
        val assetID: String?
        // ============
) {
    val urlForImage: String
        get() = imageUrl ?: assetUrl ?: ""

    val products: List<ProductInCampaignDto>
        get() =
                try {
                    metaArray.firstOrNull { it.metaType == "ProductLink" }?.metaContent?.let {
                            content ->
                        val links = content["links"] as? ArrayList<*>
                        links?.mapNotNull { link ->
                            (link as? Map<*, *>)?.let { map ->
                                ProductInCampaignDto(
                                        id = map["id"]?.toString(),
                                        imageUrl = map["imageUrl"]?.toString() ?: "",
                                        title = map["title"]?.toString() ?: "",
                                        linkToFollow = map["linkToFollow"]?.toString() ?: ""
                                )
                            }
                        }
                    }
                            ?: emptyList()
                } catch (e: Exception) {
                    emptyList()
                }
}

data class MetaItem(
        @SerializedName("metaID") val metaId: Int,
        @SerializedName("imageID") val imageId: String,
        @SerializedName("metaType") val metaType: String,
        @SerializedName("metaContent") val metaContent: Map<String, Any>,
        @SerializedName("metaOrder") val metaOrder: Int?,
        @SerializedName("created") val created: Long?

//    @SerializedName("MetaUser")
//    val metaUser: UserDto
)

sealed class MetaContent {
    data class CardType(val value: String) : MetaContent()
    data class Title(val value: String) : MetaContent()
    data class Description(val value: String) : MetaContent()
    data class Link(
            val url: String,
            val title: String,
            val privateDetails: Boolean,
            val icon: String,
            val onScanDisplay: Boolean,
            val openInNewWindow: Boolean
    ) : MetaContent() {

        fun useDefaultIcon(): Boolean {
            return SupportedWebSites.fromIconIdentifier(icon) == SupportedWebSites.WEB
        }

        /**
         * Gets the drawable resource name for this icon.
         * The consuming application should use this to look up the actual resource ID.
         */
        fun getIconDrawableName(): String {
            return SupportedWebSites.fromIconIdentifier(icon).drawableName
        }

        /**
         * Gets the icon resource ID using a resource provider.
         * This method requires the consuming application to provide a resource provider.
         */
        fun getIconResId(resourceProvider: IRKitResourceProvider): Int {
            return SupportedWebSites.fromIconIdentifier(icon).getIconResId(resourceProvider)
        }

        val openInExternalBrowser: Boolean
            get() = openInNewWindow && isLinkAWebAddress

        val fullURLString: String
            get() =
                    when {
                        url.startsWith("http://") || url.startsWith("https://") -> url
                        else -> "https://$url"
                    }

        val isLinkAWebAddress: Boolean
            get() = fullURLString.toUri().scheme?.lowercase() in listOf("http", "https")
    }

    data class ProductLink(val products: List<ProductInCampaignDto>) : MetaContent()
    data class Custom(val data: Map<String, Any>) : MetaContent()
    data class EmbeddedVideo(val videoUrl: String) : MetaContent()
    data class Tags(val tags: List<String>) : MetaContent()
    data class FirstName(val firstName: String) : MetaContent()
    data class LastName(val lastName: String) : MetaContent()
    data class Company(val company: String) : MetaContent()
    data class JobTitle(val jobTitle: String) : MetaContent()
    data class Phone(val phone: String) : MetaContent()
    data class Email(val email: String) : MetaContent()
    data class Address(val address: String) : MetaContent()

    // New Fields
    data class Year(val year: String) : MetaContent()
    data class Size(val size: String) : MetaContent()
    data class Provenance(val provenance: String) : MetaContent()
    data class GalleryName(val galleryName: String) : MetaContent()
    data class Medium(val medium: String) : MetaContent()
    data class ArtistName(val artistName: String) : MetaContent()
    data class UserProvidedInfo(val userProvidedInfo: String) : MetaContent()
}

data class ParsedMetaItem(
        val metaId: Int,
        val metaType: String,
        val content: MetaContent,
        val contentArray: List<MetaContent>?,
        val order: Int?,
        val created: Long?,
        val metaTypeEnum: MetaTypes?
) {
    override fun toString(): String {
        return "ParsedMetaItem(metaId=$metaId, metaType='$metaType', content=$content, contentArray=${contentArray?.joinToString(
            prefix = "[",
            postfix = "]"
        )}, order=$order, created=$created)"
    }

    fun metaTypeEnum(): MetaTypes {
        return try {
            MetaTypes.valueOf(metaType)
        } catch (e: IllegalArgumentException) {
            MetaTypes.Unknown
        }
    }
}

fun ParsedMetaItem.getLinksForCTADisplay(): List<MetaContent>? {
    // Filter on onScanDisplay = true
    // take the first 2 or one
    var contentArray =
            this.contentArray
                    ?.filter {
                        val link = it as? MetaContent.Link
                        link?.onScanDisplay == true
                    }
                    ?.take(2)

    val count = contentArray?.count() ?: 0

    // if there is room for more add the next 1 or 2 to the list
    contentArray =
            contentArray?.plus(
                    this.contentArray
                            ?.reversed()
                            ?.filter {
                                val link = it as? MetaContent.Link
                                link?.onScanDisplay == false
                            }
                            ?.take(2 - count)
                            ?: emptyList()
            )
    return contentArray
}

fun ImageDto.parseMetaItems(): List<ParsedMetaItem> {
    return metaArray.mapNotNull { meta ->
        if (meta.metaType == "Link") {
            val content = parseLink(meta.metaContent) ?: return@mapNotNull null

            val contentArray = parseLinkArray(meta.metaContent)

            ParsedMetaItem(
                    metaId = meta.metaId,
                    metaType = meta.metaType,
                    content = content,
                    contentArray = contentArray,
                    order = meta.metaOrder,
                    created = meta.created,
                    metaTypeEnum = MetaTypes.getEnumFromString(meta.metaType)
            )
        } else {
            val content =
                    when (meta.metaType) {
                        "UserProvidedInfo" ->
                                meta.metaContent["UserProvidedInfo"]?.toString()?.let {
                                    MetaContent.UserProvidedInfo(it)
                                }
                        "CardType" ->
                                meta.metaContent["cardType"]?.toString()?.let {
                                    MetaContent.CardType(it)
                                }
                        "Title" ->
                                meta.metaContent["title"]?.toString()?.let { MetaContent.Title(it) }
                        "Description" ->
                                meta.metaContent["description"]?.toString()?.let {
                                    MetaContent.Description(it)
                                }
                        "Link" -> parseLink(meta.metaContent)
                        "ProductLink" -> MetaContent.ProductLink(products)
                        "Custom" -> MetaContent.Custom(meta.metaContent)
                        "EmbeddedVideo" ->
                                meta.metaContent["embeddedVideo"]?.toString()?.let {
                                    MetaContent.EmbeddedVideo(it)
                                }
                        "Tags" ->
                                MetaContent.Tags(
                                        (meta.metaContent["tags"] as? List<*>)?.mapNotNull {
                                            it?.toString()
                                        }
                                                ?: emptyList()
                                )
                        "FirstName" ->
                                meta.metaContent["firstName"]?.toString()?.let {
                                    MetaContent.FirstName(it)
                                }
                        "LastName" ->
                                meta.metaContent["lastName"]?.toString()?.let {
                                    MetaContent.LastName(it)
                                }
                        "Company" ->
                                meta.metaContent["company"]?.toString()?.let {
                                    MetaContent.Company(it)
                                }
                        "JobTitle" ->
                                meta.metaContent["jobTitle"]?.toString()?.let {
                                    MetaContent.JobTitle(it)
                                }
                        "Phone" ->
                                meta.metaContent["phone"]?.toString()?.let { MetaContent.Phone(it) }
                        "Email" ->
                                meta.metaContent["email"]?.toString()?.let { MetaContent.Email(it) }
                        "Address" ->
                                meta.metaContent["address"]?.toString()?.let {
                                    MetaContent.Address(it)
                                }
                        "Size" -> meta.metaContent["size"]?.toString()?.let { MetaContent.Size(it) }
                        "Year" -> meta.metaContent["year"]?.toString()?.let { MetaContent.Year(it) }
                        "Provenance" ->
                                meta.metaContent["provenance"]?.toString()?.let {
                                    MetaContent.Provenance(it)
                                }
                        "Medium" ->
                                meta.metaContent["medium"]?.toString()?.let {
                                    MetaContent.Medium(it)
                                }
                        "GalleryName" ->
                                meta.metaContent["galleryName"]?.toString()?.let {
                                    MetaContent.GalleryName(it)
                                }
                        "ArtistName" ->
                                meta.metaContent["name"]?.toString()?.let {
                                    MetaContent.ArtistName(it)
                                }
                        "Price" ->
                                meta.metaContent["price"]?.toString()?.let {
                                    MetaContent.Medium(it)
                                }
                        "DisplayLocation" ->
                                meta.metaContent["displayLocation"]?.toString()?.let {
                                    MetaContent.Medium(it)
                                }
                        else -> null
                    }
                            ?: return@mapNotNull null

            val metaTypeEnum = MetaTypes.getEnumFromString(meta.metaType)

            ParsedMetaItem(
                    metaId = meta.metaId,
                    metaType = meta.metaType,
                    content = content,
                    contentArray = null,
                    order = meta.metaOrder,
                    created = meta.created,
                    metaTypeEnum = MetaTypes.getEnumFromString(meta.metaType)
            )
        }
    }
}

private fun parseLinkArray(metaContent: Map<String, Any>): List<MetaContent.Link>? {
    return try {
        val links = metaContent["links"] as? ArrayList<*>
        links?.mapNotNull { link ->
            (link as? Map<*, *>)?.let { linkMap ->
                MetaContent.Link(
                        url = linkMap["url"]?.toString() ?: "",
                        title = linkMap["title"]?.toString() ?: "",
                        privateDetails = linkMap["privateDetails"] as? Boolean ?: false,
                        icon = linkMap["icon"]?.toString() ?: "",
                        onScanDisplay = linkMap["onScanDisplay"] as? Boolean ?: false,
                        openInNewWindow = linkMap["openInNewWindow"] as? Boolean ?: false
                )
            }
        }
    } catch (e: Exception) {
        null
    }
}

private fun parseLink(metaContent: Map<String, Any>): MetaContent.Link? {
    return try {
        val links = metaContent["links"] as? ArrayList<*>
        val firstLink = links?.firstOrNull() as? Map<*, *> ?: return null

        MetaContent.Link(
                url = firstLink["url"]?.toString() ?: "",
                title = firstLink["title"]?.toString() ?: "",
                privateDetails = firstLink["privateDetails"] as? Boolean ?: false,
                icon = firstLink["icon"]?.toString() ?: "",
                onScanDisplay = firstLink["onScanDisplay"] as? Boolean ?: false,
                openInNewWindow = firstLink["openInNewWindow"] as? Boolean ?: false
        )
    } catch (e: Exception) {
        null
    }
}

inline fun <reified T : MetaContent> ImageDto.getMetaContentByType(type: String): T? {
    return metaArray.find { it.metaType == type }?.let { meta ->
        when (T::class) {
            MetaContent.Description::class ->
                    MetaContent.Description(meta.metaContent["description"]?.toString() ?: "") as T
            MetaContent.CardType::class ->
                    MetaContent.CardType(meta.metaContent["cardType"]?.toString() ?: "") as T
            MetaContent.Title::class ->
                    MetaContent.Title(meta.metaContent["title"]?.toString() ?: "") as T
            MetaContent.FirstName::class ->
                    MetaContent.FirstName(meta.metaContent["firstName"]?.toString() ?: "") as T
            MetaContent.LastName::class ->
                    MetaContent.LastName(meta.metaContent["lastName"]?.toString() ?: "") as T
            MetaContent.Company::class ->
                    MetaContent.Company(meta.metaContent["company"]?.toString() ?: "") as T
            MetaContent.JobTitle::class ->
                    MetaContent.JobTitle(meta.metaContent["jobTitle"]?.toString() ?: "") as T
            MetaContent.Phone::class ->
                    MetaContent.Phone(meta.metaContent["phone"]?.toString() ?: "") as T
            MetaContent.Email::class ->
                    MetaContent.Email(meta.metaContent["email"]?.toString() ?: "") as T
            MetaContent.Address::class ->
                    MetaContent.Address(meta.metaContent["address"]?.toString() ?: "") as T
            MetaContent.Address::class ->
                    MetaContent.Address(meta.metaContent["artistName"]?.toString() ?: "") as T
            MetaContent.Address::class ->
                    MetaContent.Address(meta.metaContent["size"]?.toString() ?: "") as T
            MetaContent.Address::class ->
                    MetaContent.Address(meta.metaContent["year"]?.toString() ?: "") as T
            else -> null
        }
    }
}
