/**
 * Utility classes and helper functions.
 * 
 * This package will contain:
 * - Extension functions
 * - Common helper classes
 */
package com.irdb.irkit.utils