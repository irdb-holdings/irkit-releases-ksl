package com.irdb.irkit.dto

import android.util.Log
import com.google.gson.GsonBuilder
import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import com.google.gson.stream.JsonWriter

class GsonErrorHandler {
    companion object {
        fun createGsonBuilder(): GsonBuilder {
            // CRITICAL: Gson's default behavior is to NOT serialize null values to JSON
            // This prevents sending null/empty deviceToken which would delete the token on backend
            // Do NOT call .serializeNulls() as that would ENABLE null serialization
            return GsonBuilder()
                .registerTypeAdapterFactory(object : com.google.gson.TypeAdapterFactory {
                    override fun <T> create(gson: com.google.gson.Gson, type: com.google.gson.reflect.TypeToken<T>): TypeAdapter<T>? {
                        val delegate = gson.getDelegateAdapter(this, type)
                        return object : TypeAdapter<T>() {
                            override fun write(out: JsonWriter, value: T?) {
                                delegate.write(out, value)
                            }

                            override fun read(reader: JsonReader): T {
                                try {
                                    return delegate.read(reader)
                                } catch (e: Exception) {
                                    val path = reader.path
                                    val token = reader.peek()
                                    val value = when (token) {
                                        JsonToken.BOOLEAN -> reader.nextBoolean()
                                        JsonToken.NUMBER -> reader.nextDouble()
                                        JsonToken.STRING -> reader.nextString()
                                        JsonToken.NULL -> reader.nextNull()
                                        else -> "unknown"
                                    }
                                    Log.e(
                                        "GsonErrorHandler",
                                        """
                                        Parsing error in field: $path
                                        Expected type: ${type.type}
                                        Received value: $value
                                        Token type: $token
                                        Error: ${e.message}
                                        """.trimIndent()
                                    )
                                    throw e
                                }
                            }
                        }
                    }
                })
        }
    }
}