package com.irdb.irkit

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.pow
import kotlin.math.sqrt

class GyroscopeManager(context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val stabilityThreshold = 0.1f // Same threshold as iOS
    private val updateInterval = 100L // 0.1 seconds in milliseconds

    private var lastUpdateTime = 0L
    private var isDeviceStable = false
    private var onStabilityChanged: ((Boolean) -> Unit)? = null

    fun startGyroscopeUpdates(callback: (Boolean) -> Unit) {
        if (gyroscope == null) {
            // If gyroscope is not available, assume device is stable
            callback(true)
            return
        }

        onStabilityChanged = callback
        sensorManager.registerListener(
            this,
            gyroscope,
            SensorManager.SENSOR_DELAY_NORMAL
        )
    }

    fun stopGyroscopeUpdates() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastUpdateTime < updateInterval) {
            return
        }
        lastUpdateTime = currentTime

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val totalRotation = sqrt(x.pow(2) + y.pow(2) + z.pow(2))

        // Update stability based on threshold
        val newStability = totalRotation < stabilityThreshold
        if (isDeviceStable != newStability) {
            isDeviceStable = newStability
            onStabilityChanged?.invoke(newStability)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not needed for this implementation
    }
}
