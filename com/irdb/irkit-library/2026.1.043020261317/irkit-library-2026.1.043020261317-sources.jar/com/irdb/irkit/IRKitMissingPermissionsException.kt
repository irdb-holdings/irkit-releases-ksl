package com.irdb.irkit

/**
 * Thrown when [IRKit.initialize] is called and one or more required runtime permissions
 * (camera, location, gallery) are not granted.
 *
 * @param missingPermissions List of Android permission names that are not granted
 *   (e.g. [android.Manifest.permission.CAMERA], [android.Manifest.permission.ACCESS_FINE_LOCATION]).
 */
class IRKitMissingPermissionsException(
    val missingPermissions: List<String>
) : Exception(
    "IRKit initialization failed: the following permissions are not granted: ${missingPermissions.joinToString(", ")}"
) {

    init {
        require(missingPermissions.isNotEmpty()) {
            "missingPermissions must not be empty"
        }
    }
}
