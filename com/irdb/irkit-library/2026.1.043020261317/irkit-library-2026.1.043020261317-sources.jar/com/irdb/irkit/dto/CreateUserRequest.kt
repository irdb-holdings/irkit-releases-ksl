package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

/**
 * Request body for creating/updating a user via the backend API.
 * Fields are nullable so absent values are omitted from JSON.
 */
data class CreateUserRequest(
    @SerializedName("email") val email: String? = null,
    @SerializedName("phone") val phone: String? = null,
    @SerializedName("profileUrl") val profileUrl: String? = null,
    @SerializedName("fullName") val fullName: String? = null,
    @SerializedName("userName") val userName: String? = null,
    @SerializedName("version") val version: String = "Android-1.0",
    @SerializedName("mergeFirebaseID") val mergeFirebaseID: String? = null,
    @SerializedName("deviceToken") val deviceToken: String? = null,
    // API expects a string value like "0" or "1"
    @SerializedName("privateAccount") val privateAccount: String? = null
) {
    override fun toString(): String {
        return buildString {
            append("CreateUserRequest(")
            append("email=${email?.let { "'$it'" } ?: "null"}")
            append(", phone=${phone?.let { "'$it'" } ?: "null"}")
            append(", profileUrl=${profileUrl?.let { "'$it'" } ?: "null"}")
            append(", fullName=${fullName?.let { "'$it'" } ?: "null"}")
            append(", userName=${userName?.let { "'$it'" } ?: "null"}")
            append(", version='$version'")
            append(", mergeFirebaseID=${mergeFirebaseID?.let { "'$it'" } ?: "null"}")
            append(", deviceToken=${deviceToken?.let { "'$it'" } ?: "null"}")
            append(", privateAccount=${privateAccount?.let { "'$it'" } ?: "null"}")
            append(")")
        }
    }
    companion object {
        /**
         * Creates a CreateUserRequest with the default Android version prefix
         * @param appVersion The app version string (e.g., from AppVersionUtils.getFormattedVersion())
         * @param email User's email address
         * @param phone User's phone number
         * @param profileUrl User's profile URL
         * @param fullName User's full name
         * @param userName User's user Name
         * @param mergeFirebaseID Firebase ID for merging accounts
         * @param deviceToken Device token (note: API comment says "do not send")
         * @param privateAccount Whether account is private ("0" or "1")
         * @return CreateUserRequest with "Android-" prefixed version
         */
        fun createWithAndroidVersion(
            appVersion: String,
            email: String? = null,
            phone: String? = null,
            profileUrl: String? = null,
            fullName: String? = null,
            userName: String? = null,
            mergeFirebaseID: String? = null,
            deviceToken: String? = null,
            privateAccount: String? = null
        ): CreateUserRequest {
            return CreateUserRequest(
                email = email,
                phone = phone,
                profileUrl = profileUrl,
                fullName = fullName,
                userName = userName,
                version = "Android-$appVersion",
                mergeFirebaseID = mergeFirebaseID,
                deviceToken = deviceToken,
                privateAccount = privateAccount
            )
        }
    }
}
