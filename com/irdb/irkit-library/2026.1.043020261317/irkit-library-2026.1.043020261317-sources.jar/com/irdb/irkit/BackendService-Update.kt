package com.irdb.irkit

import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.dto.ImageDto
import com.irdb.irkit.dto.MetaItem
import com.irdb.irkit.response.ImageContainer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// THiS IS NOT USED YET!
/**
 * Request body for updating image metadata
 */
// data class UpdateImageRequest(
//     val imageId: String,
//     val title: String? = null,
//     val description: String? = null,
//     val metaArray: List<MetaItem>? = null,
//     val latitude: Double? = null,
//     val longitude: Double? = null,
//     val save: Boolean? = null
// )

// /**
//  * Update image metadata on the server
//  */
// suspend fun BackendService.updateImage(
//     imageId: String,
//     title: String? = null,
//     description: String? = null,
//     metaArray: List<MetaItem>? = null,
//     latitude: Double? = null,
//     longitude: Double? = null,
//     save: Boolean? = null
// ): ImageDto = withContext(Dispatchers.IO) {
//     val endpoint = "/Images/$imageId"

//     if (BackendService.isDebugMode()) {
//         Log.i(TAG, "Updating image: $imageId")
//         Log.d(TAG, "Update data - title: $title, description: $description, metaArray size: ${metaArray?.size}")
//     }

//     val requestBody = UpdateImageRequest(
//         imageId = imageId,
//         title = title,
//         description = description,
//         metaArray = metaArray,
//         latitude = latitude,
//         longitude = longitude,
//         save = save
//     )

//     val response = request<BaseResponse<ImageContainer>>(
//         endpoint = endpoint,
//         method = HttpMethod.PUT,
//         bodyParameters = requestBody,
//         responseType = object : TypeToken<BaseResponse<ImageContainer>>() {}.type
//     )

//     if (!response.succeeded || response.payload == null) {
//         throw BackendServiceError.ServerError(response.errorMessage)
//     }

//     val updatedImage = (response.payload as BaseResponse<ImageContainer>).results.image

//     if (BackendService.isDebugMode()) {
//         Log.i(TAG, "Image updated successfully: ${updatedImage.imageId}")
//     }

//     updatedImage
// }
