package com.irdb.irkit.extensions

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

/**
 * Optimizes a bitmap for registration/upload by resizing and compressing
 * @param targetMegapixels Target megapixel count (default: 2.56MP)
 * @param maxFileSizeBytes Maximum file size in bytes (default: 9MB)
 * @param initialQuality Starting JPEG compression quality (default: 40%)
 * @param minQuality Minimum acceptable quality (default: 5%)
 * @param qualityStep Quality reduction step (default: 5%)
 * @return Optimized image as ByteArray
 */
fun Bitmap.downSizeForRegistration(
    targetMegapixels: Float = 2_560_000f,
    maxFileSizeBytes: Int = 9 * 1024 * 1024, // 9MB
    initialQuality: Int = 40,
    minQuality: Int = 5,
    qualityStep: Int = 5
): ByteArray {
    // Calculate original megapixels
    val originalMegapixels = width.toFloat() * height.toFloat()

    // Determine if resizing is needed
    val resizedBitmap = if (originalMegapixels > targetMegapixels) {
        val scaleRatio = sqrt(targetMegapixels / originalMegapixels)
        val newWidth = (width * scaleRatio).toInt()
        val newHeight = (height * scaleRatio).toInt()

        // Create scaled bitmap
        Bitmap.createScaledBitmap(this, newWidth, newHeight, true)
    } else {
        this
    }

    // Compress with adaptive quality
    var quality = initialQuality
    var imageData: ByteArray

    do {
        val outputStream = ByteArrayOutputStream()
        resizedBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        imageData = outputStream.toByteArray()
        outputStream.close()

        if (imageData.size <= maxFileSizeBytes) break

        quality -= qualityStep
    } while (quality >= minQuality)

    // Clean up if we created a new bitmap
    if (resizedBitmap != this) {
        resizedBitmap.recycle()
    }

    return imageData
}

/**
 * Alternative version that returns a new optimized Bitmap instead of ByteArray
 */
fun Bitmap.downSizeForRegistrationBitmap(
    targetMegapixels: Float = 2_560_000f
): Bitmap {
    val originalMegapixels = width.toFloat() * height.toFloat()

    return if (originalMegapixels > targetMegapixels) {
        val scaleRatio = sqrt(targetMegapixels / originalMegapixels)
        val newWidth = (width * scaleRatio).toInt()
        val newHeight = (height * scaleRatio).toInt()

        Bitmap.createScaledBitmap(this, newWidth, newHeight, true)
    } else {
        this
    }
}

/**
 * Helper extension to get file size of bitmap as JPEG
 */
fun Bitmap.getJpegSizeBytes(quality: Int = 90): Int {
    val outputStream = ByteArrayOutputStream()
    compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
    val size = outputStream.size()
    outputStream.close()
    return size
}
