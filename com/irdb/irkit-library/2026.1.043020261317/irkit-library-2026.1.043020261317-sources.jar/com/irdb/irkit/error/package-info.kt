/**
 * Error handling and custom exceptions.
 * 
 * This package will contain:
 * - APIError sealed class
 * - Custom exception types
 * - Error mapping utilities
 * - Error reporting interfaces
 */
package com.irdb.irkit.error