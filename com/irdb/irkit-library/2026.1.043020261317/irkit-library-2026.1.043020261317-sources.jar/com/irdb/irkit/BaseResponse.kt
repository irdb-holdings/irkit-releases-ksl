package com.irdb.irkit

import com.google.gson.annotations.JsonAdapter
import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.TimeUsedTypeAdapter

data class BaseResponse<T>(
    @SerializedName("Completed")
    override val completed: Boolean,

    @SerializedName("TimeUsed")
    @JsonAdapter(TimeUsedTypeAdapter::class)
    override val timeUsed: Double,

    @SerializedName("NextOffset")
    override val nextOffset: Int,

    @SerializedName("Count")
    override val count: Int,

    @SerializedName("Pages")
    override val pages: Int,

    @SerializedName("Environment")
    override val environment: String,

    @SerializedName("GCFVersion")
    override val gcfVersion: String,

    @SerializedName("ErrorMessage")
    val errorMessageObj: ErrorMessage?,

    @SerializedName("Results")
    val results: T
) : BEDecodable {
    override val errorMessage: String
        get() = errorMessageObj?.getErrorMessage() ?: ""
}
