package com.irdb.irkit.dto

import com.irdb.irkit.response.UserData

data class UserDataDTO(
    var totalHistoryCount: Int = 0,
    var totalSavedCount: Int = 0,
    var totalImagesCount: Int = 0,
    var totalArchivedCount: Int = 0,
    val email: String = "",
    val phone: String = "",
    val profileUrl: String = "",
    val userName: String = "",
    val fullName: String = "",
    val userTypeId: Int = 0,
    val userType: String = "",
    val userTypeDisplay: String = "",
    val accountLocked: Int = 0,
    val userId: Int = 0,
    val fbUserId: String = "",
    var countRead: Int = 0,
    var countUnRead: Int = 0,
    var totalNotificationsCount: Int = 0,
    val privateAccount: Boolean = false,
    // New fields for creator mode
    val emailVerified: Boolean = false,
    val phoneVerified: Boolean = false
) {
    companion object {
        fun fromUserResponse(response: UserData): UserDataDTO {
            return UserDataDTO(
                totalImagesCount = 0, // yes I know not needed but....
                totalHistoryCount = response.totalHistoryCount,
                totalSavedCount = response.totalSavedCount,
                totalArchivedCount = response.totalArchivedCount,
                email = response.email,
                phone = response.phone,
                profileUrl = response.profileUrl,
                userName = response.userName,
                fullName = response.fullName,
                userTypeId = response.userTypeId,
                userType = response.userType,
                userTypeDisplay = response.userTypeDisplay,
                accountLocked = response.accountLocked,
                userId = response.userId,
                fbUserId = response.fbUserId,
                countRead = response.countRead,
                countUnRead = response.countUnRead,
                totalNotificationsCount = response.totalNotificationsCount,
                privateAccount = response.privateAccount,
                emailVerified = response.emailVerified,
                phoneVerified = response.phoneVerified
            )
        }
    }
    
    // Helper properties for creator mode
    val isCreator: Boolean
        get() = userType.trim().equals("Pro", ignoreCase = true)
    
    val isBasicOrAnonymous: Boolean
        get() {
            val trimmedType = userType.trim()
            return trimmedType.equals("Basic", ignoreCase = true) || 
                   trimmedType.equals("Anonymous", ignoreCase = true)
        }
    
    val canUpgradeToCreator: Boolean
        get() = isBasicOrAnonymous
    
    val displayName: String
        get() = if (userName.isNotEmpty()) userName else fullName
}
