package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.ImageDto

data class CreateIRCodeResponse(
    @SerializedName("ImageAdded")
    val ImageAdded: Boolean = false,

    @SerializedName("Image")
    val image: ImageDto
)
