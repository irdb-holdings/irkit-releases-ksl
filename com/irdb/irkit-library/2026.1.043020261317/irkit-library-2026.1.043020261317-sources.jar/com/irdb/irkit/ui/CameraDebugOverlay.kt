package com.irdb.irkit.ui

import android.graphics.Rect
import android.util.Size
import com.irdb.irkit.BuildConfig
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Visual debugging overlay for camera resolution and crop regions.
 *
 * Shows:
 * - Red box: Live mode crop sent every 3 seconds
 * - Green box: 1x zoom (widest) foveated crop
 * - Blue box: 2x zoom foveated crop
 * - Yellow box: 4x zoom (tightest) foveated crop
 * - Top-right text: Source resolution from ImageAnalysis
 *
 * This overlay shows simplified boxes overlaid on the camera preview
 * to visualize what regions are being sent to the server.
 */
@Composable
fun CameraDebugOverlay(
    showOverlay: Boolean,
    liveModeCropBounds: Rect?,
    foveatedCropBounds: List<Rect>?,
    imageResolution: Size?,
    modifier: Modifier = Modifier
) {
    if (!showOverlay) return

    val density = LocalDensity.current
    val textMeasurer = rememberTextMeasurer()

    // Debug logging
    if (BuildConfig.DEBUG) {
        android.util.Log.d("CameraDebugOverlay", "Overlay rendering - showOverlay: $showOverlay")
        android.util.Log.d("CameraDebugOverlay", "liveModeCropBounds: $liveModeCropBounds")
        android.util.Log.d("CameraDebugOverlay", "foveatedCropBounds: $foveatedCropBounds")
        android.util.Log.d("CameraDebugOverlay", "imageResolution: $imageResolution")
    }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Show debug indicator in top-left corner (small white square)
            drawRect(
                color = Color.White,
                topLeft = Offset(10.dp.toPx(), 10.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(20.dp.toPx(), 20.dp.toPx()),
                style = Stroke(width = 2.dp.toPx())
            )

            // Red box: Live mode crop (sent every 3 seconds)
            liveModeCropBounds?.let { bounds ->
                val strokeWidth = 4.dp.toPx()
                val color = Color.Red

                // Show a centered box representing the live crop
                val centerX = size.width / 2
                val centerY = size.height / 2
                val boxSize = 200.dp.toPx()

                drawRect(
                    color = color,
                    topLeft = Offset(centerX - boxSize/2, centerY - boxSize/2),
                    size = androidx.compose.ui.geometry.Size(boxSize, boxSize),
                    style = Stroke(width = strokeWidth)
                )

                // Label for live crop
                val labelText = "LIVE: ${bounds.width()}x${bounds.height()}"
                val textStyle = TextStyle(
                    color = Color.Red,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = labelText,
                    topLeft = Offset(centerX - boxSize/2, centerY - boxSize/2 - 30.dp.toPx()),
                    style = textStyle
                )
            }

            // Green/Blue/Yellow boxes: Foveated crops (1x, 2x, 4x zoom)
            // Show these continuously for debugging, accounting for 90-degree rotation
            val centerX = size.width / 2
            val centerY = size.height / 2

            // Always show the three foveated crop regions for debugging
            val foveatedColors = listOf(Color.Green, Color.Blue, Color.Yellow)
            val foveatedLabels = listOf("1x", "2x", "4x")

            // Calculate proper sizes based on screen dimensions (accounting for rotation)
            val screenWidth = size.width
            val screenHeight = size.height
            val minDimension = minOf(screenWidth, screenHeight)
            val maxDimension = maxOf(screenWidth, screenHeight)

            // Base sizes as percentages of the smaller dimension (after rotation)
            val foveatedSizes = listOf(
                minDimension * 0.4f,  // 1x zoom (40% of smaller dimension)
                minDimension * 0.28f, // 2x zoom (28% of smaller dimension)
                minDimension * 0.16f  // 4x zoom (16% of smaller dimension)
            )

            foveatedColors.forEachIndexed { index, color ->
                val strokeWidth = 3.dp.toPx()
                val boxSize = foveatedSizes[index]

                // All foveated boxes should be centered on the same point (different zoom levels of same region)
                drawRect(
                    color = color,
                    topLeft = Offset(centerX - boxSize/2, centerY - boxSize/2),
                    size = androidx.compose.ui.geometry.Size(boxSize, boxSize),
                    style = Stroke(width = strokeWidth)
                )

                // Label for foveated crop - position labels to avoid overlap
                val zoomLabel = "${foveatedLabels[index]}: ${(boxSize / density.density).toInt()}x${(boxSize / density.density).toInt()}"

                val textStyle = TextStyle(
                    color = color,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                // Position labels at different vertical offsets to avoid overlap
                val labelOffsetY = when(index) {
                    0 -> -boxSize/2 - 25.dp.toPx()  // 1x zoom label above
                    1 -> -boxSize/2 - 5.dp.toPx()   // 2x zoom label just above
                    2 -> boxSize/2 + 5.dp.toPx()    // 4x zoom label below
                    else -> -boxSize/2 - 25.dp.toPx()
                }

                drawText(
                    textMeasurer = textMeasurer,
                    text = zoomLabel,
                    topLeft = Offset(centerX - boxSize/2, centerY + labelOffsetY),
                    style = textStyle
                )
            }

            // Show actual foveated crop bounds if available (from server calls)
            foveatedCropBounds?.forEachIndexed { index, bounds ->
                val color = when(index) {
                    0 -> Color.Green.copy(alpha = 0.5f)  // 1x zoom (semi-transparent)
                    1 -> Color.Blue.copy(alpha = 0.5f)   // 2x zoom (semi-transparent)
                    2 -> Color.Yellow.copy(alpha = 0.5f) // 4x zoom (semi-transparent)
                    else -> Color.White.copy(alpha = 0.5f)
                }

                val strokeWidth = 2.dp.toPx()
                val centerX = size.width / 2
                val centerY = size.height / 2

                // Use the same rotation-aware sizing as the debug boxes
                val boxSize = foveatedSizes[index]

                // Draw actual server crop bounds as filled rectangles (semi-transparent)
                // All server crops should also be centered on the same point
                drawRect(
                    color = color,
                    topLeft = Offset(centerX - boxSize/2, centerY - boxSize/2),
                    size = androidx.compose.ui.geometry.Size(boxSize, boxSize)
                )

                // Label for actual server crop - position to avoid overlap with debug labels
                val serverLabel = "SERVER: ${bounds.width()}x${bounds.height()}"

                val textStyle = TextStyle(
                    color = color.copy(alpha = 1f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                // Position server labels to the right of the boxes to avoid overlap
                val serverLabelOffsetX = boxSize/2 + 10.dp.toPx()
                val serverLabelOffsetY = when(index) {
                    0 -> -boxSize/2 - 15.dp.toPx()  // 1x zoom label
                    1 -> -boxSize/2 + 5.dp.toPx()   // 2x zoom label
                    2 -> boxSize/2 - 15.dp.toPx()   // 4x zoom label
                    else -> -boxSize/2 - 15.dp.toPx()
                }

                drawText(
                    textMeasurer = textMeasurer,
                    text = serverLabel,
                    topLeft = Offset(centerX + serverLabelOffsetX, centerY + serverLabelOffsetY),
                    style = textStyle
                )
            }

            // Show timing info for foveated crops
            if (foveatedCropBounds != null) {
                val timingText = "SERVER CROPS (every 3s)"
                val timingStyle = TextStyle(
                    color = Color.Cyan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                val timingLayoutResult = textMeasurer.measure(timingText, timingStyle)
                val timingWidth = timingLayoutResult.size.width
                val timingHeight = timingLayoutResult.size.height

                drawRect(
                    color = Color.Black.copy(alpha = 0.7f),
                    topLeft = Offset(size.width - timingWidth - 16.dp.toPx(), 60.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(timingWidth + 16.dp.toPx(), timingHeight + 16.dp.toPx())
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = timingText,
                    topLeft = Offset(size.width - timingWidth - 8.dp.toPx(), 68.dp.toPx()),
                    style = timingStyle
                )
            }

            // Resolution info overlay (top right)
            imageResolution?.let { resolution ->
                val text = "Source: ${resolution.width}x${resolution.height}"
                val textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                // Draw background rectangle
                val padding = 8.dp.toPx()
                val textLayoutResult = textMeasurer.measure(text, textStyle)
                val textWidth = textLayoutResult.size.width
                val textHeight = textLayoutResult.size.height

                drawRect(
                    color = Color.Black.copy(alpha = 0.7f),
                    topLeft = Offset(size.width - textWidth - padding * 2, 20.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(textWidth + padding * 2, textHeight + padding * 2)
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = text,
                    topLeft = Offset(size.width - textWidth - padding, 20.dp.toPx() + padding),
                    style = textStyle
                )
            }

            // Legend overlay (bottom left)
            val legendText = "Red: Live (0.3s) | Green/Blue/Yellow: Foveated regions (always visible)"
            val legendStyle = TextStyle(
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            val legendLayoutResult = textMeasurer.measure(legendText, legendStyle)
            val legendWidth = legendLayoutResult.size.width
            val legendHeight = legendLayoutResult.size.height

            drawRect(
                color = Color.Black.copy(alpha = 0.7f),
                topLeft = Offset(10.dp.toPx(), size.height - legendHeight - 20.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(legendWidth + 16.dp.toPx(), legendHeight + 16.dp.toPx())
            )

            drawText(
                textMeasurer = textMeasurer,
                text = legendText,
                topLeft = Offset(18.dp.toPx(), size.height - legendHeight - 12.dp.toPx()),
                style = legendStyle
            )
        }
    }
}
