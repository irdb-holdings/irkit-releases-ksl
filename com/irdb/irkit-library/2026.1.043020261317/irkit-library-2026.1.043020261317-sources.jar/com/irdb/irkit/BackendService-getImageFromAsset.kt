package com.irdb.irkit


import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.dto.ImageDto
import com.irdb.irkit.models.ClipInfoData
import com.irdb.irkit.response.ImageContainer
import java.text.DecimalFormat

//https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/Asset/ircode/0198C344960B725CBE0F17B93B946F5E?startTime=0.04&stopTime=0.64
suspend fun BackendService.getImageFromAsset(clipInfoData: ClipInfoData): ImageDto {

    val timeFormatter = DecimalFormat("0.00")
    val endpoint = "/Asset/ircode/${clipInfoData.assetId}?startTime=${timeFormatter.format(clipInfoData.timeRangeMin)}&stopTime=${timeFormatter.format(clipInfoData.timeRangeMax)}"

    val response = request<BaseResponse<ImageContainer>>(
        endpoint = endpoint,
        method = HttpMethod.GET,
        responseType = object : TypeToken<BaseResponse<ImageContainer>>() {}.type
    )


    Log.i("json", gson.toJson(response))

    if (!response.succeeded || response.payload == null) {
        if (response.payload == null){
            Log.e(TAG, "getImageFromAsset: Payload == null")
        }
        if (!response.succeeded){
            Log.e(TAG, "getImageFromAsset: response.succeeded did not succeeded")
        }
        try {
            Log.e(TAG, "getImageFromAsset: sdkapikey=${BackendService.getSubscriptionKey()}")
        } catch (_: Exception) {
            Log.e(TAG, "getImageFromAsset: sdkapikey=unable to retrieve")
        }
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val img = payload.results.image
        ?: throw BackendServiceError.ImageNotFound
    return img
}
