/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.irdb.irkit;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.irdb.irkit";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final boolean ENABLE_CHARLES_PROXY = false;
  // Field from default config.
  public static final String LIBRARY_MAIN_RELEASE = "2026";
  // Field from default config.
  public static final String LIBRARY_POINT_RELEASE = "1.03042026";
  // Field from default config.
  public static final String LIBRARY_VERSION = "2026.1.03042026";
}
