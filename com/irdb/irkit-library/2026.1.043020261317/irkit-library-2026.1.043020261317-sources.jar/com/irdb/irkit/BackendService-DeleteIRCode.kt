package com.irdb.irkit

import com.google.gson.reflect.TypeToken
import com.irdb.irkit.response.DeleteIRCodeResponse
import com.irdb.irkit.response.RestoreIRCodeResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class RestoreIRCodeResult {
    object Success : RestoreIRCodeResult()
    data class Failure(val gcrLog: String?) : RestoreIRCodeResult()
}

/**
 * Deletes an IR code image from the backend server.
 *
 * This function sends a DELETE request to the backend API to permanently remove an IR code image
 * identified by the provided [imageId]. The operation is performed on a background thread using
 * [Dispatchers.IO] to avoid blocking the main thread.
 *
 * @param imageId The unique identifier of the IR code image to delete.
 *                This should be a valid image ID that exists on the server.
 *
 * @return [DeleteIRCodeResponse] containing the result of the deletion operation.
 *         The response includes an [imageRemoved] boolean field indicating whether
 *         the image was successfully removed from the server.
 *
 * @throws BackendServiceError.ServerError if the server request fails, the image doesn't exist,
 *         or any other server-side error occurs. The error message will contain details
 *         about what went wrong.
 *
 * @throws BackendServiceError.InvalidResponse if the server response cannot be parsed
 *         or is in an unexpected format.
 *
 * @throws BackendServiceError.AccessDenied if the user doesn't have permission to delete
 *         the specified image.
 *
 * @sample
 * ```kotlin
 * try {
 *     val response = BackendService.DeleteIRCode("image123")
 *     if (response.imageRemoved) {
 *         println("Image successfully deleted")
 *     } else {
 *         println("Image deletion failed")
 *     }
 * } catch (e: BackendServiceError.ServerError) {
 *     println("Failed to delete image: ${e.message}")
 * }
 * ```
 *
 * @see DeleteIRCodeResponse
 * @see BackendServiceError
 */

// DELETE https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/IREngine/89BAC1B1691B4B258ED6E40B3B8FA36A
suspend fun BackendService.DeleteIRCode(imageId: String): DeleteIRCodeResponse =
    withContext(Dispatchers.IO) {
        val endpoint = "/IREngine/$imageId"

        val response = request<BaseResponse<DeleteIRCodeResponse>>(
            endpoint = endpoint,
            method = HttpMethod.DELETE,
            responseType = object : TypeToken<BaseResponse<DeleteIRCodeResponse>>() {}.type
        )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        payload.results
    }


/*
 {
    "Completed": true,
    "Time": "2025-9-23 19:31:31.377",
    "TimeUsed": 5421,
    "GCRLog": "development-v1-43-3998627865-211",
    "NextOffset": 0,
    "Total": 0,
    "Count": 0,
    "Pages": 0,
    "Environment": "DEV",
    "GCFVersion": "development-v1-43-00980-joh",
    "Results": {
    "ImageRestored": true
    }
}
*/
suspend fun BackendService.RestoreIRCode(imageId: String): RestoreIRCodeResult =
    withContext(Dispatchers.IO) {
        val endpoint = "/Removed/image/$imageId"

        val response = request<BaseResponse<RestoreIRCodeResponse>>(
            endpoint = endpoint,
            method = HttpMethod.PATCH,
            responseType = object : TypeToken<BaseResponse<RestoreIRCodeResponse>>() {}.type
        )

        if (!response.succeeded || response.payload == null) {
            return@withContext RestoreIRCodeResult.Failure(gcrLog = response.gcrLog)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        val imageRestored = payload.results.imageRestored
        if (imageRestored) {
            RestoreIRCodeResult.Success
        } else {
            RestoreIRCodeResult.Failure(gcrLog = response.gcrLog)
        }
    }
