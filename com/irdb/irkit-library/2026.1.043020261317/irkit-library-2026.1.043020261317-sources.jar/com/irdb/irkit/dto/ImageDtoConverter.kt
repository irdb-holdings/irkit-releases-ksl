package com.irdb.irkit.dto

/**
 * Converter functions for converting between ImageDto and EditableImageDto
 */
object ImageDtoConverter {

    /**
     * Convert ImageDto to EditableImageDto for editing
     */
    fun toEditableImageDto(imageDto: ImageDto): EditableImageDto {
        return EditableImageDto(
            // Basic image information
            imageId = imageDto.imageId,

            // Save preference
            save = imageDto.save,

            // Status and permissions
            imageStatus = imageDto.imageStatus ?: "draft",
            editingAllowed = imageDto.editingAllowed,

            // Convert meta items to editable format
            metaItems = convertMetaItemsToEditable(imageDto.metaArray, imageDto.imageId),

            // Convert products
            products = imageDto.products.toMutableList()
        )
    }

    /**
     * Convert EditableImageDto back to ImageDto for saving
     */
    fun toImageDto(editableImageDto: EditableImageDto): ImageDto {
        return ImageDto(
            // Basic image information
            imageId = editableImageDto.imageId,

            // Save preference
            save = editableImageDto.save,

            // Status and permissions
            imageStatus = editableImageDto.imageStatus,
            editingAllowed = editableImageDto.editingAllowed,

            // Convert editable meta items back to regular format
            metaArray = convertEditableMetaItemsToMetaItems(editableImageDto.metaItems),

            // Required parameters with default values
            longitude = 0.0,
            latitude = 0.0,
            timeArchived = "0",
            campaignId = 0,
            campaignName = "",
            title = editableImageDto.getTitleFromMeta(),
            metaContent = MetaContentDto(title = editableImageDto.getTitleFromMeta()),
            specialType = null,
            internalId = 0,
            imageUserId = 0,
            imageUser = null,
            imageUrl = "",
            imageWidth = 0,
            imageHeight = 0,
            imageSize = 0,
            countQueries = 0,
            webUrl = null,
            nativeUrl = null,
            line1 = null,
            line2 = null,
            displayImageUrl = null,
            objectDetectionStatus = null,
            fugacious = null,
            imageCreated = null,
            sponsored = null,
            transferInProcess = null,
            removeAfter = null,
            countSimilar = null,
            countSearches = null,
            countShares = null,
            viewCount = null,
            timeScanned = null,
            countViews = null,
            countSaved = null,
            countComments = null,
            productsArray = null,
            masterTemplate = null,
            imageCreatedReadable = null,

            // Asset-related parameters
            assetDisplayImage = null,
            assetUrl = null,
            assetID = null
        )
    }

    /**
     * Convert MetaItem list to EditableMetaItem list
     * For Link items, unpack the links array into separate EditableMetaItem objects
     */
    private fun convertMetaItemsToEditable(metaItems: List<MetaItem>, imageId: String): MutableList<EditableMetaItem> {
        val editableItems = mutableListOf<EditableMetaItem>()
        
        metaItems.forEach { metaItem ->
            if (metaItem.metaType == "Link") {
                // Unpack links array into separate EditableMetaItem objects
                val linksArray = metaItem.metaContent["links"] as? List<*>
                if (linksArray != null && linksArray.isNotEmpty()) {
                    linksArray.forEach { linkItem ->
                        (linkItem as? Map<*, *>)?.let { linkMap ->
                            // Only process links that have a non-empty URL
                            val url = linkMap["url"]?.toString() ?: ""
                            if (url.isNotEmpty()) {
                                val linkContent = mutableMapOf<String, Any>()
                                linkMap.forEach { (key, value) ->
                                    if (value != null) {
                                        linkContent[key.toString()] = value
                                    }
                                }
                                
                                editableItems.add(
                                    EditableMetaItem(
                                        metaId = metaItem.metaId, // All links from same server item share same metaId
                                        imageId = imageId,
                                        metaType = "Link",
                                        metaContent = linkContent,
                                        metaOrder = metaItem.metaOrder,
                                        created = metaItem.created
                                    )
                                )
                            }
                        }
                    }
                } else {
                    // Fallback: if no links array, treat as single link item (only if it has a URL)
                    val url = metaItem.metaContent["url"]?.toString() ?: ""
                    if (url.isNotEmpty()) {
                        editableItems.add(
                            EditableMetaItem(
                                metaId = metaItem.metaId,
                                imageId = imageId,
                                metaType = metaItem.metaType,
                                metaContent = metaItem.metaContent.toMutableMap(),
                                metaOrder = metaItem.metaOrder,
                                created = metaItem.created
                            )
                        )
                    }
                }
            } else {
                // Non-Link items: convert directly
                editableItems.add(
                    EditableMetaItem(
                        metaId = metaItem.metaId,
                        imageId = imageId,
                        metaType = metaItem.metaType,
                        metaContent = metaItem.metaContent.toMutableMap(),
                        metaOrder = metaItem.metaOrder,
                        created = metaItem.created
                    )
                )
            }
        }
        
        return editableItems
    }

    /**
     * Convert EditableMetaItem list back to MetaItem list
     */
    private fun convertEditableMetaItemsToMetaItems(editableMetaItems: List<EditableMetaItem>): List<MetaItem> {
        return editableMetaItems.map { editableMetaItem ->
            MetaItem(
                metaId = editableMetaItem.metaId,
                imageId = editableMetaItem.imageId,
                metaType = editableMetaItem.metaType,
                metaContent = editableMetaItem.metaContent.toMap(),
                metaOrder = editableMetaItem.metaOrder,
                created = editableMetaItem.created
            )
        }
    }

    /**
     * Create a new EditableImageDto for creating a new IRCode
     */
    fun createNewEditableImageDto(
        imageId: String = ""
    ): EditableImageDto {
        return EditableImageDto(
            imageId = imageId,
            imageStatus = "draft",
            editingAllowed = true
        )
    }

    /**
     * Create a copy of EditableImageDto for editing
     * Note: This creates a new instance which will reset the internal backup.
     * For proper deletion tracking, use copyEditableImageDtoWithBackup instead.
     */
    fun copyEditableImageDto(original: EditableImageDto): EditableImageDto {
        return original.copy(
            metaItems = original.metaItems.map { it.copy(metaContent = it.metaContent.toMutableMap()) }.toMutableList(),
            products = original.products.toMutableList()
        )
    }
    
    /**
     * Create a copy of EditableImageDto while preserving the original backup for deletion tracking.
     * This is important when copying after modifications to ensure deleted items can be detected.
     * 
     * This uses reflection to preserve the private backup field, which is necessary for
     * proper deletion tracking when items are removed from metaItems.
     */
    fun copyEditableImageDtoWithBackup(original: EditableImageDto): EditableImageDto {
        val copy = original.copy(
            metaItems = original.metaItems.map { it.copy(metaContent = it.metaContent.toMutableMap()) }.toMutableList(),
            products = original.products.toMutableList()
        )
        
        // Preserve the original backup using reflection
        try {
            val backupField = EditableImageDto::class.java.getDeclaredField("metaItemsBackup")
            backupField.isAccessible = true
            @Suppress("UNCHECKED_CAST")
            val originalBackup = backupField.get(original) as? MutableList<com.irdb.irkit.dto.EditableMetaItem>
            if (originalBackup != null) {
                @Suppress("UNCHECKED_CAST")
                val copyBackup = backupField.get(copy) as? MutableList<com.irdb.irkit.dto.EditableMetaItem>
                copyBackup?.clear()
                originalBackup.forEach { item ->
                    copyBackup?.add(item.copy(metaContent = item.metaContent.toMutableMap()))
                }
            }
        } catch (e: Exception) {
            // If reflection fails, fall back to regular copy
            // The backup will be reset, but deletion tracking may not work perfectly
            android.util.Log.w("ImageDtoConverter", "Failed to preserve backup during copy: ${e.message}")
        }
        
        return copy
    }
}
