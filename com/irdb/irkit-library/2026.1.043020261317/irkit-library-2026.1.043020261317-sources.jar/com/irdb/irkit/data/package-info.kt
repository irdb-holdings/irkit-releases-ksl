/**
 * Data layer containing repositories and data sources.
 *
 * This package will contain:
 * - Repository implementations
 * - Data source abstractions
 * - Local storage implementations
 */
package com.irdb.irkit.data
