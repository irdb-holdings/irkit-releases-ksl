package com.irdb.irkit

import com.irdb.irkit.dto.ImageDto

/**
 * In-memory LRU cache for `/lookup` responses, keyed by the IR Engine
 * recognition ID (`entry:<id>` or `asset:<id>`).
 *
 * The live-scan path can hit `/lookup` several times per second while the
 * camera is aimed at the same recognized image; this cache short-circuits the
 * repeat calls. Bounded to keep the library safe on small phones when embedded
 * in larger host apps.
 *
 *  - Storage: in-memory only (process-scoped).
 *  - Size: bounded LRU at [MAX_ENTRIES] (~30 × ~2–4 KB per ImageDto = ~60–120 KB typical).
 *  - TTL: entries expire after [TTL_MS] (60s) to bound staleness — IRCODEs
 *    older than 60 seconds are dropped so the next recognition re-resolves
 *    fresh content from the backend.
 *  - Eviction: lazy — on `get()` (TTL) and on `put()` (size via removeEldestEntry).
 *    No background threads or timers.
 *
 * Only successful resolutions are cached; ImageNotFound / parse / network
 * failures are left for the next frame to retry.
 */
internal object LookupCache {
    private const val MAX_ENTRIES = 30
    private const val TTL_MS = 60L * 1000L  // 60 seconds

    private data class CacheEntry(val dto: ImageDto, val storedAt: Long)

    // accessOrder=true turns the map into an LRU; removeEldestEntry caps size.
    private val map = object : LinkedHashMap<String, CacheEntry>(MAX_ENTRIES, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CacheEntry>?): Boolean =
            size > MAX_ENTRIES
    }
    private val lock = Any()

    fun get(key: String): ImageDto? = synchronized(lock) {
        val entry = map[key] ?: return null
        if (System.currentTimeMillis() - entry.storedAt > TTL_MS) {
            map.remove(key)
            return null
        }
        entry.dto
    }

    fun put(key: String, dto: ImageDto) = synchronized(lock) {
        map[key] = CacheEntry(dto, System.currentTimeMillis())
    }

    fun clear() = synchronized(lock) { map.clear() }

    internal fun size(): Int = synchronized(lock) { map.size }

    fun cacheKeyFor(entry: String?, asset: String?): String? = when {
        !entry.isNullOrEmpty() -> "entry:$entry"
        !asset.isNullOrEmpty() -> "asset:$asset"
        else -> null
    }
}
