package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

data class ProductInCampaignDto(
    @SerializedName("id")
    val id: String?,

    @SerializedName("imageUrl")
    val imageUrl: String,

    @SerializedName("title")
    val title: String,

    @SerializedName("linkToFollow")
    val linkToFollow: String
)
