package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
/*
{
	"Completed": true,
	"Time": "2025-6-9 19:24:13.165",
	"TimeUsed": 81,
	"GCRLog": "development-v1-43-576288968-940",
	"NextOffset": 0,
	"Total": 0,
	"Count": 0,
	"Pages": 0,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00565-hug",
	"Results": {
		"Save": true
	}
}
 */
data class ImageSavePostResponse(
    @SerializedName("Save")
    val save: Boolean
)

/*
{
	"Completed": true,
	"Time": "2025-6-9 19:24:11.731",
	"TimeUsed": 27,
	"GCRLog": "development-v1-43-1350413293-942",
	"NextOffset": 0,
	"Total": 0,
	"Count": 0,
	"Pages": 0,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00565-hug",
	"Results": {
		"Removed": true
	}
}
 */
data class ImageSaveDeleteResponse(
    @SerializedName("Removed")
    val removed: Boolean
)
