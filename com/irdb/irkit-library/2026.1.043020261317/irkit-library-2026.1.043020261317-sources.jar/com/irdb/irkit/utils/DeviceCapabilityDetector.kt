package com.irdb.irkit.utils

import android.app.ActivityManager
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraProvider
import androidx.camera.core.ImageAnalysis

/**
 * Device capability detection system for adaptive camera resolution.
 *
 * Detects device capabilities (RAM, CPU, camera specs) to determine optimal resolution tier
 * for ImageAnalysis. Provides progressive fallback system for graceful degradation.
 */
object DeviceCapabilityDetector {

    private const val CAMERA_SPEC_TAG = "CameraSpec"

    /**
     * Device capabilities data class containing optimal settings for the device.
     */
    data class DeviceCapabilities(
        val optimalResolution: Size,
        val deviceTier: DeviceTier,
        val maxConcurrentUseCases: Int,
        val supportsHighResolution: Boolean
    )

    /**
     * Device tier classification based on hardware capabilities.
     */
    enum class DeviceTier {
        HIGH_END,      // 4K: 3840x2160
        MID_RANGE,     // 1080p: 1920x1080
        LOW_END,       // 720p: 1280x720
        VERY_LOW_END   // VGA: 640x480
    }

    /**
     * Easy configuration object - adjust thresholds here for different device tiers.
     */
    object ResolutionConfig {
        // Resolution targets by tier
        val HIGH_END_RESOLUTION = Size(3840, 2160)
        val MID_RANGE_RESOLUTION = Size(1920, 1080)
        val LOW_END_RESOLUTION = Size(1280, 720)
        val VERY_LOW_END_RESOLUTION = Size(640, 480)

        // Device tier thresholds (easy to adjust)
        const val HIGH_END_MIN_RAM_GB = 8.0
        const val MID_RANGE_MIN_RAM_GB = 4.0
        const val LOW_END_MIN_RAM_GB = 2.0

        const val HIGH_END_MIN_CPU_CORES = 8
        const val MID_RANGE_MIN_CPU_CORES = 6
        const val LOW_END_MIN_CPU_CORES = 4

        // Live crop targets
        const val TARGET_LIVE_CROP_SIZE = 1280
        const val MIN_LIVE_CROP_SIZE = 1280

        // Foveated image targets
        const val TARGET_FOVEATED_CROP_SIZE = 1280

        // Progressive fallback order
        val RESOLUTION_FALLBACK_ORDER = listOf(
            Size(3840, 2160),  // 4K
            Size(1920, 1080),  // 1080p
            Size(1280, 720),   // 720p
            Size(640, 480)     // VGA
        )
    }

    /**
     * Detects device capabilities and returns optimal camera settings.
     *
     * @param context Android context for accessing system services
     * @param cameraProvider CameraX provider for camera characteristics
     * @return DeviceCapabilities with optimal resolution and settings
     */
    fun detect(context: Context, cameraProvider: CameraProvider?): DeviceCapabilities {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        // Convert bytes to GB
        val totalRAM = memoryInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
        val availableRAM = memoryInfo.availMem / (1024.0 * 1024.0 * 1024.0)

        // Get CPU core count
        val cpuCores = Runtime.getRuntime().availableProcessors()

        // Determine device tier based on hardware capabilities
        val deviceTier = when {
            totalRAM >= ResolutionConfig.HIGH_END_MIN_RAM_GB &&
            cpuCores >= ResolutionConfig.HIGH_END_MIN_CPU_CORES -> {
                Log.i(CAMERA_SPEC_TAG, "High-end device detected: ${totalRAM}GB RAM, ${cpuCores} cores")
                DeviceTier.HIGH_END
            }
            totalRAM >= ResolutionConfig.MID_RANGE_MIN_RAM_GB &&
            cpuCores >= ResolutionConfig.MID_RANGE_MIN_CPU_CORES -> {
                Log.i(CAMERA_SPEC_TAG, "Mid-range device detected: ${totalRAM}GB RAM, ${cpuCores} cores")
                DeviceTier.MID_RANGE
            }
            totalRAM >= ResolutionConfig.LOW_END_MIN_RAM_GB &&
            cpuCores >= ResolutionConfig.LOW_END_MIN_CPU_CORES -> {
                Log.i(CAMERA_SPEC_TAG, "Low-end device detected: ${totalRAM}GB RAM, ${cpuCores} cores")
                DeviceTier.LOW_END
            }
            else -> {
                Log.i(CAMERA_SPEC_TAG, "Very low-end device detected: ${totalRAM}GB RAM, ${cpuCores} cores")
                DeviceTier.VERY_LOW_END
            }
        }

        // Get optimal resolution for this tier
        val optimalResolution = when (deviceTier) {
            DeviceTier.HIGH_END -> ResolutionConfig.HIGH_END_RESOLUTION
            DeviceTier.MID_RANGE -> ResolutionConfig.MID_RANGE_RESOLUTION
            DeviceTier.LOW_END -> ResolutionConfig.LOW_END_RESOLUTION
            DeviceTier.VERY_LOW_END -> ResolutionConfig.VERY_LOW_END_RESOLUTION
        }

        // Determine max concurrent use cases based on device tier
        val maxConcurrentUseCases = when (deviceTier) {
            DeviceTier.HIGH_END -> 3 // Preview + ImageCapture + ImageAnalysis
            DeviceTier.MID_RANGE -> 3
            DeviceTier.LOW_END -> 2 // Preview + ImageAnalysis (skip ImageCapture)
            DeviceTier.VERY_LOW_END -> 2
        }

        // Check if device supports high resolution (4K+)
        val supportsHighResolution = deviceTier == DeviceTier.HIGH_END

        // Log device detection results
        Log.i(CAMERA_SPEC_TAG, "Device tier: $deviceTier")
        Log.i(CAMERA_SPEC_TAG, "Total RAM: ${String.format("%.1f", totalRAM)}GB, Available: ${String.format("%.1f", availableRAM)}GB")
        Log.i(CAMERA_SPEC_TAG, "CPU cores: $cpuCores")
        Log.i(CAMERA_SPEC_TAG, "Target resolution: ${optimalResolution.width}x${optimalResolution.height}")
        Log.i(CAMERA_SPEC_TAG, "Max concurrent use cases: $maxConcurrentUseCases")
        Log.i(CAMERA_SPEC_TAG, "Supports high resolution: $supportsHighResolution")

        return DeviceCapabilities(
            optimalResolution = optimalResolution,
            deviceTier = deviceTier,
            maxConcurrentUseCases = maxConcurrentUseCases,
            supportsHighResolution = supportsHighResolution
        )
    }

    /**
     * Gets the appropriate backpressure strategy for the device tier.
     *
     * @param deviceTier The detected device tier
     * @return ImageAnalysis backpressure strategy
     */
    fun getBackpressureStrategy(deviceTier: DeviceTier): Int {
        return when (deviceTier) {
            DeviceTier.HIGH_END, DeviceTier.MID_RANGE -> {
                ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
            }
            DeviceTier.LOW_END, DeviceTier.VERY_LOW_END -> {
                ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
            }
        }
    }

    /**
     * Checks if the device is Samsung and adjusts capabilities accordingly.
     * Samsung devices sometimes have issues with high resolution targets.
     *
     * @param capabilities Original device capabilities
     * @return Adjusted capabilities for Samsung devices
     */
    fun adjustForSamsungDevice(capabilities: DeviceCapabilities): DeviceCapabilities {
        val isSamsung = android.os.Build.MANUFACTURER.equals("samsung", ignoreCase = true)

        if (!isSamsung) {
            return capabilities
        }

        Log.i(CAMERA_SPEC_TAG, "Samsung device detected, adjusting capabilities")

        // Samsung devices: downgrade one tier for stability
        val adjustedTier = when (capabilities.deviceTier) {
            DeviceTier.HIGH_END -> DeviceTier.MID_RANGE
            DeviceTier.MID_RANGE -> DeviceTier.LOW_END
            DeviceTier.LOW_END -> DeviceTier.VERY_LOW_END
            DeviceTier.VERY_LOW_END -> DeviceTier.VERY_LOW_END
        }

        val adjustedResolution = when (adjustedTier) {
            DeviceTier.HIGH_END -> ResolutionConfig.HIGH_END_RESOLUTION
            DeviceTier.MID_RANGE -> ResolutionConfig.MID_RANGE_RESOLUTION
            DeviceTier.LOW_END -> ResolutionConfig.LOW_END_RESOLUTION
            DeviceTier.VERY_LOW_END -> ResolutionConfig.VERY_LOW_END_RESOLUTION
        }

        Log.i(CAMERA_SPEC_TAG, "Samsung adjustment: ${capabilities.deviceTier} -> $adjustedTier")
        Log.i(CAMERA_SPEC_TAG, "Samsung resolution: ${capabilities.optimalResolution.width}x${capabilities.optimalResolution.height} -> ${adjustedResolution.width}x${adjustedResolution.height}")

        return capabilities.copy(
            optimalResolution = adjustedResolution,
            deviceTier = adjustedTier,
            supportsHighResolution = false // Samsung devices don't support high resolution in our implementation
        )
    }
}
