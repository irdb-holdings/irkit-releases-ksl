package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.ImageDto

data class UserHistoryResponse(
    @SerializedName("Images") val images: List<ImageDto> = emptyList()
)

data class UserSavedResponse(
    @SerializedName("Images")
    val images: List<ImageDto> = emptyList()
)

data class UserIRCodesResponse(
    @SerializedName("Images")
    val images: List<ImageDto> = emptyList()
)

data class TrashResponse(
    @SerializedName("Images")
    val images: List<ImageDto> = emptyList()
)

/*

{
	"Completed": true,
	"Time": "2025-5-11 07:45:28.944",
	"TimeUsed": 115,
	"GCRLog": "development-v1-43-2004686244-22",
	"NextOffset": 20,
	"Total": 5,
	"Count": 5,
	"Pages": 1,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00362-xek",
	"Results": {
		"Images": [{
			"imageID": "0194B8AAE242739AB837A372626C35D5",
			"timeScanned": 1746818171,
			"timeSaved": 1746818171,
			"campaignID": null,
			"campaignName": null,
			"internalID": 151962,
			"imageUserID": 35888,
			"imageCreated": 1738264998,
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd%2F30ec74af-da03-468d-aad1-4b0f4a7c68d6.jpeg",
			"ImageUser": {
				"email": "tom+00@irdb.com",
				"phone": "",
				"userID": 35888,
				"fullName": "Tom Hackbarth",
				"userName": "tom00",
				"profileUrl": ""
			},
			"metaArray": [{
				"metaID": 140092,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "ArtistName",
				"metaContent": {
					"name": "Tom Hackbarth"
				},
				"metaOrder": null,
				"created": 1738264999,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140106,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "CardType",
				"metaContent": {
					"cardType": "general"
				},
				"metaOrder": -1,
				"created": 1738265154,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140091,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "Title",
				"metaContent": {
					"title": "a watermelon in the style of Attack of the Killer Tomatoes, comic style, attacking something or someone"
				},
				"metaOrder": 0,
				"created": 1738264999,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140107,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "Description",
				"metaContent": {
					"description": ""
				},
				"metaOrder": 2,
				"created": 1738265154,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140093,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "Link",
				"metaContent": {
					"links": [{
						"icon": "amazon",
						"privateDetails": false,
						"openInNewWindow": false,
						"onScanDisplay": false,
						"title": "amazon",
						"url": "https://amazon.com/"
					}]
				},
				"metaOrder": 8,
				"created": 1738264999,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140109,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "Custom",
				"metaContent": {
					"custom": {}
				},
				"metaOrder": 13,
				"created": 1738265154,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140110,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "EmbeddedVideo",
				"metaContent": {
					"embeddedVideo": ""
				},
				"metaOrder": 23,
				"created": 1738265154,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140108,
				"imageID": "0194B8AAE242739AB837A372626C35D5",
				"metaType": "Tags",
				"metaContent": {
					"tags": []
				},
				"metaOrder": 29,
				"created": 1738265154,
				"imageInternalID": 151962,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}],
			"productsArray": [],
			"masterTemplate": false
		}, {
			"imageID": "0194B8AAF46471AFAB78838F31CED288",
			"timeScanned": 1746804252,
			"timeSaved": 1746804252,
			"campaignID": null,
			"campaignName": null,
			"internalID": 151963,
			"imageUserID": 35888,
			"imageCreated": 1738265003,
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd%2F76ac0339-202f-4576-9f04-8dc8910a8050.jpeg",
			"ImageUser": {
				"email": "tom+00@irdb.com",
				"phone": "",
				"userID": 35888,
				"fullName": "Tom Hackbarth",
				"userName": "tom00",
				"profileUrl": ""
			},
			"metaArray": [{
				"metaID": 140097,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "CardType",
				"metaContent": {
					"cardType": "artCard"
				},
				"metaOrder": -1,
				"created": 1738265003,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140094,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Title",
				"metaContent": {
					"title": "A green grape and banana in the style of Attack of the Killer Tomatoes, comic style, attacking each other without arms"
				},
				"metaOrder": 0,
				"created": 1738265003,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140095,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "ArtistName",
				"metaContent": {
					"name": "Tom"
				},
				"metaOrder": 1,
				"created": 1738265003,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150029,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Description",
				"metaContent": {
					"description": ""
				},
				"metaOrder": 2,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150035,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Phone",
				"metaContent": {
					"phone": ""
				},
				"metaOrder": 4,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150034,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Email",
				"metaContent": {
					"email": ""
				},
				"metaOrder": 5,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 140096,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Link",
				"metaContent": {
					"links": [{
						"title": "amazon.com",
						"url": "www.amazon.com",
						"openInNewWindow": false,
						"privateDetails": false,
						"icon": "web",
						"onScanDisplay": true
					}, {
						"url": "https://thackbarth.com/",
						"onScanDisplay": false,
						"icon": "",
						"privateDetails": false,
						"openInNewWindow": false,
						"title": "Home Page"
					}]
				},
				"metaOrder": 8,
				"created": 1738265003,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150037,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Custom",
				"metaContent": {
					"custom": {}
				},
				"metaOrder": 13,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150032,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "DisplayLocation",
				"metaContent": {
					"displayLocation": ""
				},
				"metaOrder": 14,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150031,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "GalleryName",
				"metaContent": {
					"galleryName": ""
				},
				"metaOrder": 15,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150027,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Medium",
				"metaContent": {
					"medium": ""
				},
				"metaOrder": 16,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150030,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Price",
				"metaContent": {
					"price": ""
				},
				"metaOrder": 17,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150033,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Provenance",
				"metaContent": {
					"provenance": ""
				},
				"metaOrder": 18,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150028,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Size",
				"metaContent": {
					"size": ""
				},
				"metaOrder": 19,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150026,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Year",
				"metaContent": {
					"year": ""
				},
				"metaOrder": 21,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150038,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "EmbeddedVideo",
				"metaContent": {
					"embeddedVideo": ""
				},
				"metaOrder": 23,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150036,
				"imageID": "0194B8AAF46471AFAB78838F31CED288",
				"metaType": "Tags",
				"metaContent": {
					"tags": []
				},
				"metaOrder": 29,
				"created": 1745508012,
				"imageInternalID": 151963,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}],
			"productsArray": [],
			"masterTemplate": false
		}, {
			"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
			"timeScanned": 1746661128,
			"timeSaved": 1746661128,
			"campaignID": null,
			"campaignName": null,
			"internalID": 4543,
			"imageUserID": 2500,
			"imageCreated": 1704816890,
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/E6279697-87FF-4FC2-A037-90585FC3D86D.jpeg",
			"ImageUser": {
				"email": "mb@ircode.com",
				"phone": "+15048133918",
				"userID": 2500,
				"fullName": "Matty Dev Test",
				"userName": "Matty Beckerman",
				"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
			},
			"metaArray": [{
				"metaID": 21443,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "CardType",
				"metaContent": {
					"cardType": "general"
				},
				"metaOrder": -1,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 2897,
				"imageID": "7b8e060accd74330b4e558dfe0dc1a40",
				"metaType": "Title",
				"metaContent": {
					"title": "Mona Lisa"
				},
				"metaOrder": 0,
				"created": 1704816991,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "",
					"phone": "",
					"userID": 5189,
					"fullName": "",
					"userName": "",
					"profileUrl": null
				}
			}, {
				"metaID": 21454,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "ArtistName",
				"metaContent": {
					"name": "Leonardo da Vinci"
				},
				"metaOrder": 1,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21447,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Description",
				"metaContent": {
					"description": ""
				},
				"metaOrder": 2,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21452,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Email",
				"metaContent": {
					"email": ""
				},
				"metaOrder": 4,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21453,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Phone",
				"metaContent": {
					"phone": ""
				},
				"metaOrder": 5,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 2898,
				"imageID": "7b8e060accd74330b4e558dfe0dc1a40",
				"metaType": "Link",
				"metaContent": {
					"links": [{
						"url": "https://en.wikipedia.org/wiki/Mona_Lisa",
						"onTouchDisplay": false,
						"onScanDisplay": false,
						"title": "Mona Lisa - Wikipedia"
					}]
				},
				"metaOrder": 7,
				"created": 1704816991,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "",
					"phone": "",
					"userID": 5189,
					"fullName": "",
					"userName": "",
					"profileUrl": null
				}
			}, {
				"metaID": 21455,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Tags",
				"metaContent": {
					"tags": []
				},
				"metaOrder": 10,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 23379,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Custom",
				"metaContent": {
					"custom": {}
				},
				"metaOrder": 13,
				"created": 1715214770,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21450,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "DisplayLocation",
				"metaContent": {
					"displayLocation": ""
				},
				"metaOrder": 14,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21449,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "GalleryName",
				"metaContent": {
					"galleryName": ""
				},
				"metaOrder": 15,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21445,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Medium",
				"metaContent": {
					"medium": ""
				},
				"metaOrder": 16,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21448,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Price",
				"metaContent": {
					"price": ""
				},
				"metaOrder": 17,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21451,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Provenance",
				"metaContent": {
					"provenance": ""
				},
				"metaOrder": 18,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21446,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Size",
				"metaContent": {
					"size": ""
				},
				"metaOrder": 19,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 21444,
				"imageID": "7B8E060ACCD74330B4E558DFE0DC1A40",
				"metaType": "Year",
				"metaContent": {
					"year": ""
				},
				"metaOrder": 21,
				"created": 1713244729,
				"imageInternalID": 4543,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}],
			"productsArray": [],
			"masterTemplate": false
		}, {
			"imageID": "00A1A269757545BD8CE1C85A58D91109",
			"timeScanned": 1746660591,
			"timeSaved": 1746660591,
			"campaignID": null,
			"campaignName": null,
			"internalID": 4775,
			"imageUserID": 2500,
			"imageCreated": 1705445248,
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/44CEF108-919F-4D67-906B-AECF71E5BE26.jpeg",
			"ImageUser": {
				"email": "mb@ircode.com",
				"phone": "+15048133918",
				"userID": 2500,
				"fullName": "Matty Dev Test",
				"userName": "Matty Beckerman",
				"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
			},
			"metaArray": [{
				"metaID": 20156,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "CardType",
				"metaContent": {
					"cardType": "artCard"
				},
				"metaOrder": -1,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 3113,
				"imageID": "00a1a269757545bd8ce1c85a58d91109",
				"metaType": "Title",
				"metaContent": {
					"title": "Mona Lisa"
				},
				"metaOrder": 0,
				"created": 1705445332,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "",
					"phone": "",
					"userID": 5189,
					"fullName": "",
					"userName": "",
					"profileUrl": null
				}
			}, {
				"metaID": 20157,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "ArtistName",
				"metaContent": {
					"name": "Leonardo da Vinci"
				},
				"metaOrder": 1,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20161,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Description",
				"metaContent": {
					"description": "The Mona Lisa is a half-length portrait painting by Italian artist Leonardo da Vinci. Considered an archetypal masterpiece of the Italian Renaissance, it has been described as \"the best known, the most visited, the most written about, the most sung about, [and] the most parodied work of art in the world\"."
				},
				"metaOrder": 2,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20179,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Email",
				"metaContent": {
					"email": "Info@ircode.com"
				},
				"metaOrder": 4,
				"created": 1711939768,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20178,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Phone",
				"metaContent": {
					"phone": "323-300-6055"
				},
				"metaOrder": 5,
				"created": 1711939768,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 3114,
				"imageID": "00a1a269757545bd8ce1c85a58d91109",
				"metaType": "Link",
				"metaContent": {
					"links": [{
						"onScanDisplay": false,
						"onTouchDisplay": false,
						"url": "https://en.wikipedia.org/wiki/Mona_Lisa",
						"title": ""
					}]
				},
				"metaOrder": 7,
				"created": 1705445332,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "",
					"phone": "",
					"userID": 5189,
					"fullName": "",
					"userName": "",
					"profileUrl": null
				}
			}, {
				"metaID": 6756,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "UserProvidedInfo",
				"metaContent": {},
				"metaOrder": 7,
				"created": 1709062938,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20163,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Tags",
				"metaContent": {
					"tags": []
				},
				"metaOrder": 10,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20162,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "GalleryName",
				"metaContent": {
					"galleryName": "Louvre Musuem"
				},
				"metaOrder": 15,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20159,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Medium",
				"metaContent": {
					"medium": "Oil on poplar panel"
				},
				"metaOrder": 16,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20177,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Provenance",
				"metaContent": {
					"provenance": "Owned by the louvre museum "
				},
				"metaOrder": 18,
				"created": 1711939524,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20160,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Size",
				"metaContent": {
					"size": "2'6\" x 1'9\""
				},
				"metaOrder": 19,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}, {
				"metaID": 20158,
				"imageID": "00A1A269757545BD8CE1C85A58D91109",
				"metaType": "Year",
				"metaContent": {
					"year": "1503"
				},
				"metaOrder": 21,
				"created": 1711939048,
				"imageInternalID": 4775,
				"MetaUser": {
					"email": "mb@ircode.com",
					"phone": "+15048133918",
					"userID": 2500,
					"fullName": "Matty Dev Test",
					"userName": "Matty Beckerman",
					"profileUrl": "https://firebasestorage.googleapis.com:443/v0/b/ircode-1a662.appspot.com/o/profilePics%2F255EA21272814781AC70C6C32BB32BE6.jpeg?alt=media&token=0b9c7d16-b9a8-436f-8a1d-587be9e735cd"
				}
			}],
			"productsArray": [],
			"masterTemplate": false
		}, {
			"imageID": "0196691DC5D0766B8D3739EB02BD0A62",
			"timeScanned": 1746315291,
			"timeSaved": 1746315291,
			"campaignID": null,
			"campaignName": null,
			"internalID": 172004,
			"imageUserID": 35888,
			"imageCreated": 1745520282,
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/97C48CD18D654C2E814B4B16D2DE21ED.jpeg",
			"ImageUser": {
				"email": "tom+00@irdb.com",
				"phone": "",
				"userID": 35888,
				"fullName": "Tom Hackbarth",
				"userName": "tom00",
				"profileUrl": ""
			},
			"metaArray": [{
				"metaID": 150046,
				"imageID": "0196691DC5D0766B8D3739EB02BD0A62",
				"metaType": "CardType",
				"metaContent": {
					"cardType": "general"
				},
				"metaOrder": null,
				"created": 1745520282,
				"imageInternalID": 172004,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150050,
				"imageID": "0196691DC5D0766B8D3739EB02BD0A62",
				"metaType": "Custom",
				"metaContent": {
					"custom": {}
				},
				"metaOrder": null,
				"created": 1745520282,
				"imageInternalID": 172004,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150189,
				"imageID": "0196691DC5D0766B8D3739EB02BD0A62",
				"metaType": "Link",
				"metaContent": {
					"links": [{
						"title": "my site",
						"url": "https://www.thackbarth.com/",
						"onScanDisplay": true,
						"privateDetails": true,
						"openInNewWindow": true
					}]
				},
				"metaOrder": null,
				"created": 1745837931,
				"imageInternalID": 172004,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150047,
				"imageID": "0196691DC5D0766B8D3739EB02BD0A62",
				"metaType": "Title",
				"metaContent": {
					"title": "Crazy links"
				},
				"metaOrder": null,
				"created": 1745520282,
				"imageInternalID": 172004,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}, {
				"metaID": 150051,
				"imageID": "0196691DC5D0766B8D3739EB02BD0A62",
				"metaType": "EmbeddedVideo",
				"metaContent": {
					"embeddedVideo": ""
				},
				"metaOrder": null,
				"created": 1745520282,
				"imageInternalID": 172004,
				"MetaUser": {
					"email": "tom+00@irdb.com",
					"phone": "",
					"userID": 35888,
					"fullName": "Tom Hackbarth",
					"userName": "tom00",
					"profileUrl": ""
				}
			}],
			"productsArray": [],
			"masterTemplate": false
		}]
	}
}
 */
