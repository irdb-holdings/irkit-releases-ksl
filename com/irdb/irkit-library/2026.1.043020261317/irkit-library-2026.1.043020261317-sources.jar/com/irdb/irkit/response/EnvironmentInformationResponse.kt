package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.EnvironmentInformationDto

// json Structure is
// {
//    "Completed": true,
//    "Time": "2025-2-6 13:18:29.510",
//    "TimeUsed": 0.027,
//    "NextOffset": 0,
//    "Total": 0,
//    "Count": 0,
//    "Pages": 0,
//    "Environment": "DEV",
//    "GCFVersion": "92",
//    "ErrorMessage": "",
//    "Results": {
//      "environmentInformation": {
//      "environment": "DEV",
//      "urlToIREngine": "https://dev.backend.irdb.com/v1/",
//      "APIKeyForIREngine": "0194DCB30D7976ECB13EFAFE160C84180194DCB30D7976ECB13EFE0585A1A8F10194DCB30D7976ECB13F0270357F36EB",
//      "expires": 1738876709
//  }
// }
// }

data class EnvironmentInformationResponse(

    @SerializedName("Completed")
    val completed: Boolean,

    @SerializedName("Time")
    val time: String,

    @SerializedName("Environment")
    val environment: String,

    @SerializedName("ErrorMessage")
    val errorMessage: String,

    @SerializedName("environmentInformation")
    val environmentInformation: EnvironmentInformationDto
)
