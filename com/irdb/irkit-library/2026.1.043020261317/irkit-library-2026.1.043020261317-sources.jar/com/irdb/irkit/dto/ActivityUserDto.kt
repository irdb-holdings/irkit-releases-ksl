package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

/**
 * Data class representing the ActivityUser in a notification.
 * This is the user who triggered the notification.
 */
data class ActivityUserDto(
    @SerializedName("userID")
    val userId: Int = 0,

    @SerializedName("userName")
    val userName: String = "",

    @SerializedName("fullName")
    val fullName: String = "",

    @SerializedName("profileUrl")
    val profileUrl: String = "",

    @SerializedName("userType")
    val userType: String = "Anonymous",

    @SerializedName("privateAccount")
    val privateAccount: Int = 0
) {
    val displayName: String
        get() = if (userName.isEmpty()) fullName else userName

    val isPrivate: Boolean
        get() = privateAccount == 1
}

