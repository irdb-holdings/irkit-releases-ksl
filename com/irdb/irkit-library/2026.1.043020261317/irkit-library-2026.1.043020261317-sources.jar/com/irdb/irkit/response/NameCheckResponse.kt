package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName

/*
{
	"Completed": true,
	"Time": "2025-6-3 12:16:06.748",
	"TimeUsed": 17,
	"GCRLog": "development-v1-43-3087604546-2565",
	"NextOffset": 0,
	"Total": 0,
	"Count": 0,
	"Pages": 0,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00482-xam",
	"Results": {
		"Available": true
	}
}
 */
data class NameCheckResponse(
    @SerializedName("Available")
    val Available: Boolean = false
)
