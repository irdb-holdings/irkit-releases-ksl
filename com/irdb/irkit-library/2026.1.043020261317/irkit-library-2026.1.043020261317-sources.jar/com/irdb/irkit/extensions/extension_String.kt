package com.irdb.irkit.extensions

/**
 * Extension function for String that extracts a value from within parentheses.
 * This function looks for a pattern of the form "something(=value)" and extracts the "value" part.
 * Examples:
 * - "something(=value)" returns "value"
 * - "something(=)" returns ""
 * - "something(value)" returns "something(value)" (when no equals sign is present)
 * - "something(other)(=value)" returns "value" (uses last parentheses with equals)
 * - "plain text" returns "plain text" (when no parentheses found)
 * @return The extracted value if the pattern is found, otherwise returns the original string
 */
fun String.extractValueFromParentheses(): String {
    val equalsIndex = this.indexOf('=')
    if (equalsIndex == -1) return this
    val lastParen = this.lastIndexOf(')')
    if (lastParen == -1 || lastParen <= equalsIndex) return this
    val value = this.substring(equalsIndex + 1, lastParen)
    return value.ifEmpty { "" }
}

/**
 * Extension function for String that extracts the main domain from a URL.
 *
 * This function removes the protocol prefix, www prefix, and any subdomains to get the main domain.
 *
 * Examples:
 * - "https://example.com" returns "example.com"
 * - "https://www.example.com" returns "example.com"
 * - "https://blog.example.com" returns "example.com"
 * - "https://example.com/path" returns "example.com"
 * - "example.com" returns "example.com"
 * - "invalid-string" returns "invalid-string"
 * - "" returns ""
 *
 * @return The main domain if successfully extracted, otherwise returns the original string
 */
fun String.extractDomain(): String {
    return try {
        // Remove protocol (http://, https://, etc) and get the domain part
        val domainPart = this.replace(Regex("^(https?://)?"), "")
            .split("/")[0] // Get the domain part before any path
            .replace(Regex("^www\\."), "") // Remove www. if present

        // Get the main domain (e.g., "example.com" from "subdomain.example.com")
        val parts = domainPart.split(".")
        when {
            parts.size >= 2 -> "${parts[parts.size - 2]}.${parts[parts.size - 1]}"
            else -> domainPart
        }
    } catch (e: Exception) {
        this // Return original string if parsing fails
    }
}