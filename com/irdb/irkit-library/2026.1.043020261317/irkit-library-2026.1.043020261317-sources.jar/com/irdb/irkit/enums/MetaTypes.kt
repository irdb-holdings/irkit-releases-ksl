package com.irdb.irkit.enums

import org.json.JSONObject

enum class MetaTypes {
    Title,
    ArtistName,
    Description,
    ImageInfo, // this is probably replaced by Description enum
    SocialLinks,
    Link,
    ProductLink,
    NftLink,
    UserProvidedInfo, // to be replaced by Custom enum
    Tags,
    Email,
    Phone,
    Unknown,
    ArtCard,
    ContactInfo, // does not appear to be used anymore
    Custom,
    DisplayLocation,
    GalleryName,
    Medium,
    Price,
    Provenance,
    Size,
    Urls, // I am pretty sure this is replaced by Link enum
    Year,
    CardType, // must always be present from API call
    Category,
    EmbeddedVideo,
    FirstName,
    LastName,
    Company,
    Address,
    JobTitle;

    val order: Int
        get() = when (this) {
            CardType -> -1
            Title -> 0
            ArtistName -> 1
            Description -> 2
            ImageInfo -> 3
            Phone -> 4
            Email -> 5
            Address -> 6
            SocialLinks -> 7
            Link -> 8
            NftLink -> 9
            UserProvidedInfo -> 10
            ArtCard -> 11
            ContactInfo -> 12
            Custom -> 13
            DisplayLocation -> 14
            GalleryName -> 15
            Medium -> 16
            Price -> 17
            Provenance -> 18
            Size -> 19
            Urls -> 20
            Year -> 21
            Category -> 22
            EmbeddedVideo -> 23
            ProductLink -> 24
            FirstName -> 25
            LastName -> 26
            Company -> 27
            JobTitle -> 28
            Tags -> 29
            Unknown -> 30
        }

    val title: String
        get() = when (this) {
            Title -> "Title"
            ArtistName -> "Artist Name"
            Description -> "Description"
            ImageInfo -> "Image Info"
            SocialLinks -> "Socials"
            Link -> "Add another link"
            NftLink -> "NFT data"
            UserProvidedInfo -> "Custom Fields"
            Tags -> "Tags"
            Email -> "Email"
            Phone -> "Phone"
            ArtCard -> "Art Card"
            ContactInfo -> "Contact Info"
            Custom -> "Custom"
            DisplayLocation -> "Display Location"
            GalleryName -> "Gallery Name"
            Medium -> "Medium"
            Price -> "Price"
            Provenance -> "Provenance"
            Size -> "Size"
            Urls -> "Urls"
            Year -> "Year"
            CardType -> "Card Type"
            Category -> "Category"
            EmbeddedVideo -> "Embedded Video"
            ProductLink -> "Products"
            Unknown -> ""
            FirstName -> "First Name"
            LastName -> "Last Name"
            Company -> "Company"
            Address -> "Address"
            JobTitle -> "Job Title"
        }

    val TableName: String
        get() = when (this) {
            Title -> "Title"
            ArtistName -> "Artist Name"
            Description -> "Description"
            ImageInfo -> "Image Info"
            SocialLinks -> "Socials"
            Link -> "Add another link"
            NftLink -> "NFT data"
            UserProvidedInfo -> "Custom Fields"
            Tags -> "Tags"
            Email -> "Email"
            Phone -> "Phone"
            ArtCard -> "Art Card"
            ContactInfo -> "Contact Info"
            Custom -> "Custom"
            DisplayLocation -> "On Display"
            GalleryName -> "Museum"
            Medium -> "Medium"
            Price -> "Price"
            Provenance -> "Provenance"
            Size -> "Size"
            Urls -> "Urls"
            Year -> "Year"
            CardType -> "Card Type"
            Category -> "Category"
            EmbeddedVideo -> "Embedded Video"
            ProductLink -> "Products"
            Unknown -> ""
            FirstName -> "First Name"
            LastName -> "Last Name"
            Company -> "Company"
            Address -> "Address"
            JobTitle -> "Job Title"
        }

    companion object {
        fun getEnumFromString(searchTitle: String): MetaTypes? {
            // First try to match the enum name directly
            try {
                return valueOf(searchTitle)
            } catch (e: IllegalArgumentException) {
                // If direct match fails, continue to title matching
            }
            return entries.find { it.title.equals(searchTitle, ignoreCase = true) }
        }

    /*
    {
      "metaID": 0,
      "metaOrder": -1,
      "metaDelete": false,
      "metaContent": "{\"cardType\":\"general\"}",
      "metaType": "CardType"
    },

    */
        fun buildAPIFieldDataValue(metaType: MetaTypes, value: String): JSONObject {
            val jsonObject = JSONObject()
            jsonObject.put("metaID", 0)
            jsonObject.put("metaOrder", metaType.order)
            jsonObject.put("metaDelete", false)
            jsonObject.put("metaContent", "{\"${metaType.name}\":\"$value\"}")
            jsonObject.put("metaType", metaType.name)
            return jsonObject
        }
    }
}