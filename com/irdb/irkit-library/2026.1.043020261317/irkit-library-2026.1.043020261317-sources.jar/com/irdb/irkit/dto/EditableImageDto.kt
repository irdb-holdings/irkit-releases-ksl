package com.irdb.irkit.dto

import com.irdb.irkit.enums.MetaTypes
import org.json.JSONArray
import org.json.JSONObject

/**
 * Editable version of ImageDto for creating and editing IRCodes. This class contains mutable fields
 * that can be modified during the creation/editing process.
 */
data class EditableImageDto(
        // Basic image information
        var imageId: String = "",

        // Save preference
        var save: Boolean = false,

        // Status and permissions
        var imageStatus: String = "draft",
        var editingAllowed: Boolean = true,

        // Meta content - editable list of meta items
        var metaItems: MutableList<EditableMetaItem> = mutableListOf(),

        // Products - editable list of products
        var products: MutableList<ProductInCampaignDto> = mutableListOf()
) {

    // Backup copy of metaItems to track existing metaIds and detect deletions
    private val metaItemsBackup: MutableList<EditableMetaItem> = mutableListOf()

    init {
        // Initialize backup with current metaItems (deep copy to preserve original state)
        metaItemsBackup.addAll(metaItems.map { 
            it.copy(metaContent = it.metaContent.toMutableMap()) 
        })
    }
    
    /**
     * Get a copy of the original backup for comparison
     * This is used to detect deleted items when building the request
     */
    private fun getOriginalBackup(): List<EditableMetaItem> {
        return metaItemsBackup.map { 
            it.copy(metaContent = it.metaContent.toMutableMap()) 
        }
    }

    /** Helper function to find existing metaId for a given metaType */
    private fun findExistingMetaId(metaType: String): Int {
        return metaItemsBackup.find { it.metaType == metaType }?.metaId ?: 0
    }

    /** Get the title from meta items */
    fun getTitleFromMeta(): String {
        return metaItems.find { it.metaType == "Title" }?.getStringValue() ?: ""
    }

    /** Set the title in meta items */
    fun setTitleInMeta(newTitle: String) {
        val titleMeta = metaItems.find { it.metaType == "Title" }
        if (titleMeta != null) {
            titleMeta.setStringValue(newTitle)
        } else {
            metaItems.add(
                    EditableMetaItem(
                            metaId = findExistingMetaId("Title"),
                            imageId = imageId,
                            metaType = "Title",
                            metaContent = mutableMapOf("title" to newTitle),
                            metaOrder = metaItems.size + 1,
                            created = System.currentTimeMillis()
                    )
            )
        }
    }

    /** Get the description from meta items */
    fun getDescriptionFromMeta(): String {
        return metaItems.find { it.metaType == "Description" }?.getStringValue() ?: ""
    }

    /** Set the description in meta items */
    fun setDescriptionInMeta(newDescription: String) {
        val descMeta = metaItems.find { it.metaType == "Description" }
        if (descMeta != null) {
            descMeta.setStringValue(newDescription)
        } else {
            metaItems.add(
                    EditableMetaItem(
                            metaId = findExistingMetaId("Description"),
                            imageId = imageId,
                            metaType = "Description",
                            metaContent = mutableMapOf("description" to newDescription),
                            metaOrder = metaItems.size + 1,
                            created = System.currentTimeMillis()
                    )
            )
        }
    }

    /** Get the card type from meta items */
    fun getCardTypeFromMeta(): String {
        return metaItems.find { it.metaType == "CardType" }?.getStringValue() ?: ""
    }

    /** Set the card type in meta items */
    fun setCardTypeInMeta(cardType: String) {
        val cardTypeMeta = metaItems.find { it.metaType == "CardType" }
        if (cardTypeMeta != null) {
            cardTypeMeta.setStringValue(cardType)
        } else {
            metaItems.add(
                    EditableMetaItem(
                            metaId = findExistingMetaId("CardType"),
                            imageId = imageId,
                            metaType = "CardType",
                            metaContent = mutableMapOf("cardType" to cardType),
                            metaOrder = metaItems.size + 1,
                            created = System.currentTimeMillis()
                    )
            )
        }
    }

    /** Get first name from meta items */
    fun getFirstNameFromMeta(): String {
        return metaItems.find { it.metaType == "FirstName" }?.getStringValue() ?: ""
    }

    /** Set first name in meta items */
    fun setFirstNameInMeta(newFirstName: String) {
        val firstNameMeta = metaItems.find { it.metaType == "FirstName" }
        if (firstNameMeta != null) {
            firstNameMeta.setStringValue(newFirstName)
        } else {
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("FirstName"),
                    imageId = imageId,
                    metaType = "FirstName",
                    metaContent = mutableMapOf("firstName" to newFirstName),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Get last name from meta items */
    fun getLastNameFromMeta(): String {
        return metaItems.find { it.metaType == "LastName" }?.getStringValue() ?: ""
    }

    /** Set last name in meta items */
    fun setLastNameInMeta(newLastName: String) {
        val lastNameMeta = metaItems.find { it.metaType == "LastName" }
        if (lastNameMeta != null) {
            lastNameMeta.setStringValue(newLastName)
        } else {
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("LastName"),
                    imageId = imageId,
                    metaType = "LastName",
                    metaContent = mutableMapOf("lastName" to newLastName),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Get company from meta items */
    fun getCompanyFromMeta(): String {
        return metaItems.find { it.metaType == "Company" }?.getStringValue() ?: ""
    }

    /** Set company in meta items */
    fun setCompanyInMeta(newCompany: String) {
        val companyMeta = metaItems.find { it.metaType == "Company" }
        if (companyMeta != null) {
            companyMeta.setStringValue(newCompany)
        } else {
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("Company"),
                    imageId = imageId,
                    metaType = "Company",
                    metaContent = mutableMapOf("company" to newCompany),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Get job title from meta items */
    fun getJobTitleFromMeta(): String {
        return metaItems.find { it.metaType == "JobTitle" }?.getStringValue() ?: ""
    }

    /** Set job title in meta items */
    fun setJobTitleInMeta(newJobTitle: String) {
        val jobTitleMeta = metaItems.find { it.metaType == "JobTitle" }
        if (jobTitleMeta != null) {
            jobTitleMeta.setStringValue(newJobTitle)
        } else {
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("JobTitle"),
                    imageId = imageId,
                    metaType = "JobTitle",
                    metaContent = mutableMapOf("jobTitle" to newJobTitle),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Get phone from meta items */
    fun getPhoneFromMeta(): String {
        return metaItems.find { it.metaType == "Phone" }?.getStringValue() ?: ""
    }

    /** Set phone in meta items */
    fun setPhoneInMeta(newPhone: String) {
        val phoneMeta = metaItems.find { it.metaType == "Phone" }
        if (phoneMeta != null) {
            phoneMeta.setStringValue(newPhone)
        } else {
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("Phone"),
                    imageId = imageId,
                    metaType = "Phone",
                    metaContent = mutableMapOf("phone" to newPhone),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Get email from meta items */
    fun getEmailFromMeta(): String {
        return metaItems.find { it.metaType == "Email" }?.getStringValue() ?: ""
    }

    /** Set email in meta items */
    fun setEmailInMeta(newEmail: String) {
        val emailMeta = metaItems.find { it.metaType == "Email" }
        if (emailMeta != null) {
            emailMeta.setStringValue(newEmail)
        } else {
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("Email"),
                    imageId = imageId,
                    metaType = "Email",
                    metaContent = mutableMapOf("email" to newEmail),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Get all links from meta items */
    fun getLinks(): List<EditableMetaItem> {
        return metaItems.filter { it.metaType == "Link" }
    }

    fun getTags(): List<EditableMetaItem> {
        return metaItems.filter { it.metaType == "Tags" }
    }

    /** Set tags in meta items */
    fun setTagsInMeta(newTags: List<String>) {
        val tagsMeta = metaItems.find { it.metaType == "Tags" }
        if (tagsMeta != null) {
            tagsMeta.metaContent["tags"] = newTags
        } else {
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("Tags"),
                    imageId = imageId,
                    metaType = "Tags",
                    metaContent = mutableMapOf("tags" to newTags),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Get custom fields from meta items */
    fun getCustomFieldsFromMeta(): List<Pair<String, String>> {
        val customMeta = metaItems.find { it.metaType == "Custom" }
        return if (customMeta != null) {
            val customData = customMeta.metaContent["custom"]
            when (customData) {
                is Map<*, *> -> customData.entries.mapNotNull { entry ->
                    val key = entry.key?.toString()?.trim().orEmpty()
                    if (key.isEmpty()) null else key to (entry.value?.toString() ?: "")
                }
                is List<*> -> customData.mapNotNull { item ->
                    when (item) {
                        is Map<*, *> -> {
                            val keyCandidate = item["label"] ?: item["key"] ?: item["name"] ?: item["title"]
                            val key = keyCandidate?.toString()?.trim().orEmpty()
                            if (key.isEmpty()) null else {
                                val valueCandidate = item["value"] ?: item["val"] ?: item["text"]
                                key to (valueCandidate?.toString() ?: "")
                            }
                        }
                        else -> null
                    }
                }
                else -> emptyList()
            }
        } else {
            emptyList()
        }
    }

    /** Set custom fields in meta items */
    fun setCustomFieldsInMeta(customFields: List<Pair<String, String>>) {
        val customMeta = metaItems.find { it.metaType == "Custom" }
        if (customMeta != null) {
            // Convert list of pairs to map for storage
            val customMap = customFields.associate { (key, value) -> key to value }
            customMeta.metaContent["custom"] = customMap
        } else {
            // Convert list of pairs to map for storage
            val customMap = customFields.associate { (key, value) -> key to value }
            metaItems.add(
                EditableMetaItem(
                    metaId = findExistingMetaId("Custom"),
                    imageId = imageId,
                    metaType = "Custom",
                    metaContent = mutableMapOf("custom" to customMap),
                    metaOrder = metaItems.size + 1,
                    created = System.currentTimeMillis()
                )
            )
        }
    }

    /** Add a new link to meta items */
    fun addLink(
            url: String,
            title: String,
            icon: String = "web",
            onScanDisplay: Boolean = true,
            openInNewWindow: Boolean = true,
            privateDetails: Boolean = false
    ) {
        val linkContent =
                mutableMapOf<String, Any>(
                        "url" to url,
                        "title" to title,
                        "icon" to icon,
                        "onScanDisplay" to onScanDisplay,
                        "openInNewWindow" to openInNewWindow,
                        "privateDetails" to privateDetails
                )

        metaItems.add(
                EditableMetaItem(
                        metaId = findExistingMetaId("Link"),
                        imageId = imageId,
                        metaType = "Link",
                        metaContent = linkContent,
                        metaOrder = metaItems.size + 1,
                        created = System.currentTimeMillis()
                )
        )
    }

    /** Remove a meta item by type and value */
    fun removeMetaItem(metaType: String, value: String? = null) {
        metaItems.removeAll { item ->
            item.metaType == metaType && (value == null || when (metaType) {
                "Link" -> {
                    // Handle both individual link properties and array format
                    when {
                        item.metaContent.containsKey("links") -> {
                            // Array format - check first link's URL
                            val links = item.metaContent["links"] as? List<*>
                            val firstLink = links?.firstOrNull() as? Map<*, *>
                            firstLink?.get("url")?.toString() == value
                        }
                        item.metaContent.containsKey("url") -> {
                            // Individual link properties
                            item.metaContent["url"]?.toString() == value
                        }
                        else -> false
                    }
                }
                else -> item.getStringValue() == value
            })
        }
    }

    /** Check if the image has required fields for saving */
    fun isValidForSaving(): Boolean {
        return imageId.isNotEmpty() &&
                (getTitleFromMeta().isNotEmpty() || getDescriptionFromMeta().isNotEmpty())
    }

    /** Get validation errors */
    fun getValidationErrors(): List<String> {
        val errors = mutableListOf<String>()

        if (imageId.isEmpty()) {
            errors.add("Image ID is required")
        }

        if (getTitleFromMeta().isEmpty() && getDescriptionFromMeta().isEmpty()) {
            errors.add("Title or description is required")
        }

        return errors
    }

    /** Convert EditableImageDto to ImageMetaRequest for server update */
    fun toImageMetaRequest(): ImageMetaRequest {
        val originalBackup = getOriginalBackup()
        val currentMetaIds = metaItems.map { it.metaId }.toSet()
        
        // Find items that existed in backup but are now missing (deleted items)
        val deletedItems = originalBackup.filter { backupItem ->
            // Only include items with non-zero metaId (existing items, not new ones)
            backupItem.metaId != 0 && backupItem.metaId !in currentMetaIds
        }
        
        // Build request items for current metaItems
        val metaRequestItems = mutableListOf<MetaRequestItem>()
        
        // Process current metaItems (excluding Link items that will be bundled)
        val linkItemsProcessed = mutableSetOf<Int>()
        val nonLinkItems = metaItems.filter { metaItem ->
            if (metaItem.metaType == "Link") {
                // For Link items, we'll process them separately to bundle them
                false
            } else {
                true
            }
        }
        
        nonLinkItems.forEach { metaItem ->
            val metaContent = when (metaItem.metaType) {
                "Tags" -> {
                    // For Tags, create a JSON object with a "tags" array
                    val tagsArray = JSONArray()
                    metaItem.metaContent["tags"]?.let { tags ->
                        when (tags) {
                            is List<*> -> tags.forEach { tag -> tagsArray.put(tag) }
                            is String -> tags.split(",").forEach { tag -> tagsArray.put(tag.trim()) }
                            else -> tagsArray.put(tags.toString())
                        }
                    }
                    val tagsObject = JSONObject()
                    tagsObject.put("tags", tagsArray)
                    tagsObject.toString()
                }
                "Custom" -> {
                    // For Custom, ensure we wrap the inner map/list into a {"custom": {...}} object
                    val containerObject = JSONObject()
                    val customData = metaItem.metaContent["custom"]

                    val customObject: JSONObject = when (customData) {
                        is Map<*, *> -> JSONObject().apply {
                            customData.forEach { (k, v) ->
                                if (k != null) put(k.toString(), v)
                            }
                        }
                        is List<*> -> {
                            // Convert list entries to key/value pairs when possible
                            val obj = JSONObject()
                            customData.forEach { item ->
                                when (item) {
                                    is Pair<*, *> -> {
                                        val key = item.first?.toString()
                                        val value = item.second
                                        if (!key.isNullOrBlank()) obj.put(key, value)
                                    }
                                    is Map<*, *> -> {
                                        val key = (item["label"] ?: item["key"] ?: item["name"] ?: item["title"])?.toString()
                                        val value = (item[
                                            "value"] ?: item["val"] ?: item["text"]
                                        )
                                        if (!key.isNullOrBlank()) obj.put(key, value)
                                    }
                                }
                            }
                            obj
                        }
                        is JSONObject -> customData
                        is String -> try {
                            JSONObject(customData)
                        } catch (_: Exception) {
                            JSONObject()
                        }
                        else -> JSONObject()
                    }

                    containerObject.put("custom", customObject)
                    containerObject.toString()
                }
                else -> {
                    // For other meta types, convert metaContent map to JSON string as before
                    val contentObject = JSONObject()
                    metaItem.metaContent.forEach { (key, value) -> contentObject.put(key, value) }
                    contentObject.toString()
                }
            }

            metaRequestItems.add(
                MetaRequestItem(
                    metaId = metaItem.metaId,
                    metaType = metaItem.metaType,
                    metaContent = metaContent,
                    metaOrder = metaItem.metaOrder,
                    metaDelete = false
                )
            )
        }
        
        // Handle Link items - bundle all current Link items into one meta item
        val currentLinkItems = metaItems.filter { it.metaType == "Link" }
        val originalLinkItems = originalBackup.filter { it.metaType == "Link" }
        
        if (currentLinkItems.isNotEmpty()) {
            // There are still links, bundle them together
            val linksArray = JSONArray()
            currentLinkItems.forEach { linkItem ->
                val linkObject = JSONObject()
                linkItem.metaContent.forEach { (key, value) ->
                    linkObject.put(key, value)
                }
                linksArray.put(linkObject)
            }

            val linksContainer = JSONObject()
            linksContainer.put("links", linksArray)
            
            // Use the first link's metaId (or find original if available)
            val linkMetaId = currentLinkItems.firstOrNull()?.metaId 
                ?: originalLinkItems.firstOrNull()?.metaId 
                ?: 0

            metaRequestItems.add(
                MetaRequestItem(
                    metaId = linkMetaId,
                    metaType = "Link",
                    metaContent = linksContainer.toString(),
                    metaOrder = currentLinkItems.firstOrNull()?.metaOrder,
                    metaDelete = false
                )
            )
        } else if (originalLinkItems.isNotEmpty()) {
            // Links were deleted - need to send deletion request
            // Use the original link's metaId and send with metaDelete = true
            val deletedLinkItem = originalLinkItems.first()
            
            // Create empty links array for deletion
            val linksContainer = JSONObject()
            linksContainer.put("links", JSONArray())
            
            metaRequestItems.add(
                MetaRequestItem(
                    metaId = deletedLinkItem.metaId,
                    metaType = "Link",
                    metaContent = linksContainer.toString(),
                    metaOrder = deletedLinkItem.metaOrder,
                    metaDelete = true
                )
            )
        }
        
        // Add other deleted items (non-Link items that were removed)
        deletedItems.filter { it.metaType != "Link" }.forEach { deletedItem ->
            // Create minimal content for deletion
            val contentObject = JSONObject()
            deletedItem.metaContent.forEach { (key, value) -> 
                contentObject.put(key, value) 
            }
            
            metaRequestItems.add(
                MetaRequestItem(
                    metaId = deletedItem.metaId,
                    metaType = deletedItem.metaType,
                    metaContent = contentObject.toString(),
                    metaOrder = deletedItem.metaOrder,
                    metaDelete = true
                )
            )
        }

        return ImageMetaRequest(imageId = imageId, metaArray = metaRequestItems)
    }

    /**
     * Convert EditableImageDto to JSON string for server update Returns JSON in format: {"imageID":
     * "...", "metaArray": [...]}
     * @deprecated Use toImageMetaRequest() instead
     */
    @Deprecated("Use toImageMetaRequest() instead", ReplaceWith("toImageMetaRequest()"))
    fun getUpdateString(): String {
        val jsonObject = JSONObject()

        // Add imageID
        jsonObject.put("imageID", imageId)

        // Build metaArray
        val metaArray = JSONArray()
        val linkItemsProcessed = mutableSetOf<Int>() // Track processed link items
        
        metaItems.forEach { metaItem ->
            // Skip Link items that will be bundled together
            if (metaItem.metaType == "Link" && linkItemsProcessed.contains(metaItem.metaId)) {
                return@forEach
            }
            
            val metaObject = JSONObject()
            metaObject.put("metaID", metaItem.metaId)
            metaObject.put("metaType", metaItem.metaType)

            // Convert metaContent map to JSON string
            val contentObject = when (metaItem.metaType) {
                "Link" -> {
                    // For Link, create the proper array format - bundle ALL links into ONE meta item
                    val linksArray = JSONArray()
                    metaItems.filter { it.metaType == "Link" }.forEach { linkItem ->
                        // Mark this link as processed
                        linkItemsProcessed.add(linkItem.metaId)
                        
                        val linkObject = JSONObject()
                        linkItem.metaContent.forEach { (key, value) ->
                            // Don't include nested links array, only the individual properties
                            if (key != "links") {
                                linkObject.put(key, value)
                            }
                        }
                        linksArray.put(linkObject)
                    }
                    val linksContainer = JSONObject()
                    linksContainer.put("links", linksArray)
                    linksContainer
                }
                else -> {
                    // For other types, convert metaContent map to JSON object
                    val contentObj = JSONObject()
                    metaItem.metaContent.forEach { (key, value) -> contentObj.put(key, value) }
                    contentObj
                }
            }
            metaObject.put("metaContent", contentObject.toString())

            metaArray.put(metaObject)
        }

        jsonObject.put("metaArray", metaArray)

        return jsonObject.toString()
    }
}

/** Editable version of MetaItem for creating and editing meta content */
data class EditableMetaItem(
        var metaId: Int,
        var imageId: String,
        var metaType: String,
        var metaContent: MutableMap<String, Any>,
        var metaOrder: Int?,
        var created: Long?
) {

    /** Get string value from meta content based on meta type */
    fun getStringValue(): String {
        return when (metaType) {
            "Title" -> metaContent["title"]?.toString() ?: ""
            "Description" -> metaContent["description"]?.toString() ?: ""
            "CardType" -> metaContent["cardType"]?.toString() ?: ""
            "FirstName" -> metaContent["firstName"]?.toString() ?: ""
            "LastName" -> metaContent["lastName"]?.toString() ?: ""
            "Company" -> metaContent["company"]?.toString() ?: ""
            "JobTitle" -> metaContent["jobTitle"]?.toString() ?: ""
            "Phone" -> metaContent["phone"]?.toString() ?: ""
            "Email" -> metaContent["email"]?.toString() ?: ""
            "Address" -> metaContent["address"]?.toString() ?: ""
            "Year" -> metaContent["year"]?.toString() ?: ""
            "Size" -> metaContent["size"]?.toString() ?: ""
            "Provenance" -> metaContent["provenance"]?.toString() ?: ""
            "GalleryName" -> metaContent["galleryName"]?.toString() ?: ""
            "Medium" -> metaContent["medium"]?.toString() ?: ""
            "ArtistName" -> metaContent["name"]?.toString() ?: ""
            "UserProvidedInfo" -> metaContent["UserProvidedInfo"]?.toString() ?: ""
            "Link" -> {
                // Handle both individual link properties and array format
                when {
                    metaContent.containsKey("links") -> {
                        // Array format - get first link's URL
                        val links = metaContent["links"] as? List<*>
                        val firstLink = links?.firstOrNull() as? Map<*, *>
                        firstLink?.get("url")?.toString() ?: ""
                    }
                    metaContent.containsKey("url") -> {
                        // Individual link properties
                        metaContent["url"]?.toString() ?: ""
                    }
                    else -> ""
                }
            }
            else -> ""
        }
    }

    /** Set string value in meta content based on meta type */
    fun setStringValue(value: String) {
        when (metaType) {
            "Title" -> metaContent["title"] = value
            "Description" -> metaContent["description"] = value
            "CardType" -> metaContent["cardType"] = value
            "FirstName" -> metaContent["firstName"] = value
            "LastName" -> metaContent["lastName"] = value
            "Company" -> metaContent["company"] = value
            "JobTitle" -> metaContent["jobTitle"] = value
            "Phone" -> metaContent["phone"] = value
            "Email" -> metaContent["email"] = value
            "Address" -> metaContent["address"] = value
            "Year" -> metaContent["year"] = value
            "Size" -> metaContent["size"] = value
            "Provenance" -> metaContent["provenance"] = value
            "GalleryName" -> metaContent["galleryName"] = value
            "Medium" -> metaContent["medium"] = value
            "ArtistName" -> metaContent["name"] = value
            "UserProvidedInfo" -> metaContent["UserProvidedInfo"] = value
            "Link" -> {
                // Handle both individual link properties and array format
                when {
                    metaContent.containsKey("links") -> {
                        // Array format - update first link's URL
                        val links = metaContent["links"] as? MutableList<*>
                        val firstLink = (links?.firstOrNull() as? Map<*, *>)?.let {
                            @Suppress("UNCHECKED_CAST")
                            it as? MutableMap<String, Any>
                        }
                        firstLink?.put("url", value)
                    }
                    metaContent.containsKey("url") -> {
                        // Individual link properties
                        metaContent["url"] = value
                    }
                    else -> {
                        // Create individual link properties if neither format exists
                        metaContent["url"] = value
                    }
                }
            }
        }
    }

    /** Get the MetaTypes enum for this meta item */
    fun getMetaTypeEnum(): MetaTypes? {
        return try {
            MetaTypes.valueOf(metaType)
        } catch (e: IllegalArgumentException) {
            MetaTypes.Unknown
        }
    }
}
