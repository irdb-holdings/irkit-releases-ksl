package com.irdb.irkit

import android.graphics.Bitmap
import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.dto.BooleanTypeAdapter
import com.irdb.irkit.dto.GsonErrorHandler
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.MetaContentTypeAdapter
import com.irdb.irkit.response.RawResponse

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

suspend fun BackendService.Raw(capturedBitmap: Bitmap): RawResponse =
    withContext(Dispatchers.IO) {
        val endpoint = "/IREngine"
        // Use the same base URL logic as BackendService
        val baseUrl = BackendService.getBaseUrl()
        val url = "$baseUrl$endpoint"

        // Convert bitmap to byte array for octet-stream
        val outputStream = ByteArrayOutputStream()
        capturedBitmap.compress(Bitmap.CompressFormat.JPEG, 65, outputStream)
        val imageData = outputStream.toByteArray()

        // Log endpoint for development debugging only
        if (BackendService.isDebugMode()) {
            Log.d("EndPoint", "url: $url")
        }

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Making request to: $url")
            Log.d(TAG, "Method: POST")
            Log.d(TAG, "Firebase token present: ${firebaseToken != null}")
        }

        try {
            // Create headers similar to BackendService
            val headers = mutableMapOf(
                "Content-Type" to "application/octet-stream",
                "Accept" to "application/json",
                "sdkapikey" to BackendService.getSubscriptionKey()
            )

            firebaseToken?.let { token ->
                headers["auth"] = token
            }

            if (BackendService.isDebugMode()) {
                headers.forEach { (key, value) ->
                    Log.d(TAG, "Header: $key = $value")
                }
            }

            // Create connection and set properties
            val connection = createTrustAllConnection(URL(url))
            connection.requestMethod = "POST"
            connection.doInput = true
            connection.doOutput = true

            // Set headers before any connection is made
            headers.forEach { (key, value) ->
                connection.setRequestProperty(key, value)
                Log.d(TAG, "Header: $key = $value")
            }

            // Make the connection
            connection.connect()

            // Write image data directly
            connection.outputStream.use {
                it.write(imageData)
            }

            return@withContext processRawResponse(connection, url)
        } catch (e: Exception) {
            Log.e(TAG, "Request failed: ${e.message}", e)
            Log.e(TAG, "Request URL: $url")
            Log.e(TAG, "Request method: POST")
            throw BackendServiceError.InvalidResponse
        }
    }

private fun processRawResponse(connection: HttpURLConnection, url: String): RawResponse {
    val TAG = "RAW"
    val responseData = when {
        connection.responseCode in 200..299 -> connection.inputStream
        else -> connection.errorStream
    }.bufferedReader().use { it.readText() }

    // DO NOT LOG THIS IN STAGING OR PROD!!! EVER!!!
    if (BackendService.isDebugMode()) {
        Log.d("RAW RESPONSE", "Raw response data: $responseData")
    }

    // Process response
    when (connection.responseCode) {
        in 200..202 -> {
            try {
                // Use the same gson instance as BackendService
                val gson = GsonErrorHandler.createGsonBuilder()
                    .registerTypeAdapter(MetaContent::class.java, MetaContentTypeAdapter())
                    .registerTypeAdapter(Boolean::class.java, BooleanTypeAdapter())
                    .create()

                val baseResponse = gson.fromJson<BaseResponse<RawResponse>>(
                    responseData,
                    object : TypeToken<BaseResponse<RawResponse>>() {}.type
                )
                if (BackendService.isDebugMode()) {
                    Log.d(TAG, "Success with status code ${connection.responseCode}")
                }
                return baseResponse.results
            } catch (e: Exception) {
                Log.e(TAG, "Parsing failed: ${e.message}")
                throw BackendServiceError.ServerError(BackendServiceError.ParseError.message)
            }
        }
        401, 403 -> {
            if (BackendService.isDebugMode()) {
                Log.d(TAG, "Unauthorized access with status code ${connection.responseCode}")
            }
            throw BackendServiceError.ServerError("Unauthorized access")
        }
        else -> {
            if (BackendService.isDebugMode()) {
                Log.d(TAG, "Failed with status code ${connection.responseCode}")
            }
            throw BackendServiceError.ServerError("Server error: ${connection.responseCode}")
        }
    }
}

private fun createTrustAllConnection(url: URL): HttpURLConnection {
    val connection = if (url.protocol == "https") {
        // Create a trust manager that does not validate certificate chains
        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        })

        // Install the all-trusting trust manager
        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, trustAllCerts, java.security.SecureRandom())

        // Create an ssl socket factory with our all-trusting manager
        url.openConnection().apply {
            (this as HttpsURLConnection).sslSocketFactory = sslContext.socketFactory
            (this as HttpsURLConnection).hostnameVerifier = HostnameVerifier { _, _ -> true }
        }
    } else {
        url.openConnection()
    }

    return connection as HttpURLConnection
}

// https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/IREngine/raw

/*
{
	"Completed": true,
	"Time": "2025-7-16 11:01:26.804",
	"TimeUsed": 3452,
	"GCRLog": "development-v1-43-1832076064-73",
	"NextOffset": 20,
	"Total": 10,
	"Count": 10,
	"Pages": 1,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00684-xiw",
	"Results": {
		"ImageAlreadyExists": false,
		"Images": [{
			"webUrl": "https://development-ircode-1a662.web.app/image/19000C9255174F448DA1DD126129F619",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/19000C9255174F448DA1DD126129F619",
			"line1": "Eagles Ball",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/19000C9255174F448DA1DD126129F619.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 38.00881,
			"longitude": -122.11746,
			"save": false,
			"timeArchived": 0,
			"campaignName": "Eagles Ball",
			"campaignID": 2370,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 116283,
			"imageID": "19000C9255174F448DA1DD126129F619",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/19000C9255174F448DA1DD126129F619.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 1200,
			"securedTill": null,
			"imageCreated": 1738099248,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 1200,
				"fullName": "Robert Johnson",
				"userName": "rjatirdb",
				"userType": "Enterprise",
				"profileUrl": "https://lh3.googleusercontent.com/a-/ALV-UjVtoRefaGSRWFsGc-Vv0blN3j4gN1S_KLqmg6TKEtPx=s96-c"
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-01-28 09:20:48 pm UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/1E7029DAA76F4A57A75993AE4B3530D1",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/1E7029DAA76F4A57A75993AE4B3530D1",
			"line1": "Below Deck Mediterranean - S03E16 - Definitely not Prague",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/1E7029DAA76F4A57A75993AE4B3530D1.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 41.2324,
			"longitude": -95.8751,
			"save": false,
			"timeArchived": 0,
			"campaignName": "Below Deck Mediterranean - S03E16 - Definitely not Prague",
			"campaignID": 8824,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 268328,
			"imageID": "1E7029DAA76F4A57A75993AE4B3530D1",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/1E7029DAA76F4A57A75993AE4B3530D1.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 36337,
			"securedTill": null,
			"imageCreated": 1751696140,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 36337,
				"fullName": "Bravo Script",
				"userName": "BravoScript",
				"userType": "Enterprise",
				"profileUrl": ""
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-07-05 06:15:40 am UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/295ED78BED9242A2B607F13D639E14F4",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/295ED78BED9242A2B607F13D639E14F4",
			"line1": "Good Morning America - S50E20 - John Cena/Molly Ringwald/Snoop Dogg/Kate Gibson & Charlie Gibson",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/295ED78BED9242A2B607F13D639E14F4.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 38.00881,
			"longitude": -122.11746,
			"save": false,
			"timeArchived": 0,
			"campaignName": "Good Morning America - S50E20 - John Cena/Molly Ringwald/Snoop Dogg/Kate Gibson & Charlie Gibson",
			"campaignID": 2365,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 106527,
			"imageID": "295ED78BED9242A2B607F13D639E14F4",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/295ED78BED9242A2B607F13D639E14F4.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 1200,
			"securedTill": null,
			"imageCreated": 1738073546,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 1200,
				"fullName": "Robert Johnson",
				"userName": "rjatirdb",
				"userType": "Enterprise",
				"profileUrl": "https://lh3.googleusercontent.com/a-/ALV-UjVtoRefaGSRWFsGc-Vv0blN3j4gN1S_KLqmg6TKEtPx=s96-c"
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-01-28 02:12:26 pm UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/2A589E9C1DC4472CB919548C3689EB69",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/2A589E9C1DC4472CB919548C3689EB69",
			"line1": "Eagles Ball",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/2A589E9C1DC4472CB919548C3689EB69.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 38.00881,
			"longitude": -122.11746,
			"save": false,
			"timeArchived": 0,
			"campaignName": "Eagles Ball",
			"campaignID": 2370,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 123364,
			"imageID": "2A589E9C1DC4472CB919548C3689EB69",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/2A589E9C1DC4472CB919548C3689EB69.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 1200,
			"securedTill": null,
			"imageCreated": 1738112842,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 1200,
				"fullName": "Robert Johnson",
				"userName": "rjatirdb",
				"userType": "Enterprise",
				"profileUrl": "https://lh3.googleusercontent.com/a-/ALV-UjVtoRefaGSRWFsGc-Vv0blN3j4gN1S_KLqmg6TKEtPx=s96-c"
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-01-29 01:07:22 am UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/6AB73491F24E4C90A0F022012A05966A",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/6AB73491F24E4C90A0F022012A05966A",
			"line1": "rjatirdb",
			"line2": "",
			"displayImageUrl": "https://dev.backend.irdb.com/v1/irdbMain/6AB73491F24E4C90A0F022012A05966A/image?apikey=42",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 0,
			"longitude": 0,
			"save": false,
			"timeArchived": 0,
			"campaignName": null,
			"campaignID": null,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 192805,
			"imageID": "6AB73491F24E4C90A0F022012A05966A",
			"imageUrl": "https://dev.backend.irdb.com/v1/irdbMain/6AB73491F24E4C90A0F022012A05966A/image?apikey=42",
			"imageUrlSmall": null,
			"imageUserID": 1200,
			"securedTill": null,
			"imageCreated": 1747416070,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": "57.0153",
			"stopTime": "57.0153",
			"duration": "0.0000",
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 1200,
				"fullName": "Robert Johnson",
				"userName": "rjatirdb",
				"userType": "Enterprise",
				"profileUrl": "https://lh3.googleusercontent.com/a-/ALV-UjVtoRefaGSRWFsGc-Vv0blN3j4gN1S_KLqmg6TKEtPx=s96-c"
			},
			"metaArray": [{
				"metaID": 170390,
				"imageID": "6AB73491F24E4C90A0F022012A05966A",
				"metaType": "CardType",
				"metaContent": {
					"cardType": "videoFrame"
				},
				"metaOrder": 1,
				"created": 1747416070,
				"imageInternalID": 192805,
				"MetaUser": {
					"userID": 1200,
					"fullName": "Robert Johnson",
					"userName": "rjatirdb",
					"profileUrl": "https://lh3.googleusercontent.com/a-/ALV-UjVtoRefaGSRWFsGc-Vv0blN3j4gN1S_KLqmg6TKEtPx=s96-c"
				}
			}],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-05-16 05:21:10 pm UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/6AD116E21A2C4B47A8B207493F6E290E",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/6AD116E21A2C4B47A8B207493F6E290E",
			"line1": "Bloomberg Technology - Bloomberg Technology",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/6AD116E21A2C4B47A8B207493F6E290E.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 41.2324,
			"longitude": -95.8751,
			"save": false,
			"timeArchived": 0,
			"campaignName": "Bloomberg Technology - Bloomberg Technology",
			"campaignID": 9213,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 295661,
			"imageID": "6AD116E21A2C4B47A8B207493F6E290E",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/6AD116E21A2C4B47A8B207493F6E290E.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 64320,
			"securedTill": null,
			"imageCreated": 1751989214,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 64320,
				"fullName": "",
				"userName": "",
				"userType": "Enterprise",
				"profileUrl": ""
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-07-08 03:40:14 pm UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/9946F7E62D54400393EBA918DCBF48CC",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/9946F7E62D54400393EBA918DCBF48CC",
			"line1": "Damon Wayans Show",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/9946F7E62D54400393EBA918DCBF48CC.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 38.00881,
			"longitude": -122.11746,
			"save": false,
			"timeArchived": 0,
			"campaignName": "Damon Wayans Show",
			"campaignID": 2354,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 104294,
			"imageID": "9946F7E62D54400393EBA918DCBF48CC",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/9946F7E62D54400393EBA918DCBF48CC.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 1200,
			"securedTill": null,
			"imageCreated": 1738070147,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 1200,
				"fullName": "Robert Johnson",
				"userName": "rjatirdb",
				"userType": "Enterprise",
				"profileUrl": "https://lh3.googleusercontent.com/a-/ALV-UjVtoRefaGSRWFsGc-Vv0blN3j4gN1S_KLqmg6TKEtPx=s96-c"
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-01-28 01:15:47 pm UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/ADDD2223A5B24222AA1194347122F01F",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/ADDD2223A5B24222AA1194347122F01F",
			"line1": "American Horror Story",
			"line2": "AMERICAN HORROR STORY - S12 E09",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd%2F8aaa63f9-562c-425e-a2c1-a6e52e5bc679.jpg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": null,
			"longitude": null,
			"save": false,
			"timeArchived": 0,
			"campaignName": "American Horror Story",
			"campaignID": 1959,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 22530,
			"imageID": "ADDD2223A5B24222AA1194347122F01F",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd%2F8aaa63f9-562c-425e-a2c1-a6e52e5bc679.jpg",
			"imageUrlSmall": null,
			"imageUserID": 27354,
			"securedTill": null,
			"imageCreated": 1723753946,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 33864,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 27354,
				"fullName": "R Murphy",
				"userName": "rmurphy",
				"userType": "Enterprise",
				"profileUrl": ""
			},
			"metaArray": [{
				"metaID": 56476,
				"imageID": "ADDD2223A5B24222AA1194347122F01F",
				"metaType": "Title",
				"metaContent": {
					"title": "AMERICAN HORROR STORY - S12 E09"
				},
				"metaOrder": null,
				"created": 1723753946,
				"imageInternalID": 22530,
				"MetaUser": {
					"userID": 27354,
					"fullName": "R Murphy",
					"userName": "rmurphy",
					"profileUrl": ""
				}
			}, {
				"metaID": 56477,
				"imageID": "ADDD2223A5B24222AA1194347122F01F",
				"metaType": "ArtistName",
				"metaContent": {
					"name": "R Murphy"
				},
				"metaOrder": null,
				"created": 1723753946,
				"imageInternalID": 22530,
				"MetaUser": {
					"userID": 27354,
					"fullName": "R Murphy",
					"userName": "rmurphy",
					"profileUrl": ""
				}
			}, {
				"metaID": 56478,
				"imageID": "ADDD2223A5B24222AA1194347122F01F",
				"metaType": "Link",
				"metaContent": {
					"links": [{
						"url": "https://www.fxnetworks.com/shows/american-horror-story",
						"title": "AHS FX",
						"onScanDisplay": false
					}]
				},
				"metaOrder": null,
				"created": 1723753946,
				"imageInternalID": 22530,
				"MetaUser": {
					"userID": 27354,
					"fullName": "R Murphy",
					"userName": "rmurphy",
					"profileUrl": ""
				}
			}, {
				"metaID": 58149,
				"imageID": "ADDD2223A5B24222AA1194347122F01F",
				"metaType": "ProductLink",
				"metaContent": {
					"links": [{
						"title": "Ambulance rooftop Strobe Lights",
						"linkToFollow": "https://a.co/d/hzzpzlj",
						"imageUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2F4aaeb39e-155c-4357-b313-ab830461663e.8c440ce6-5e94-4dd2-9921-478426dfb1ce?alt=media&token=c5c26810-df5c-4dfc-84e6-f77b155490d9"
					}, {
						"title": "Ambulance Red Flashing Strobe Lights",
						"linkToFollow": "https://a.co/d/iWVx5aL",
						"imageUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2Fe253e54a-e61a-4b31-b6c3-58183fc113cc.69a2bc52-4af9-472f-a067-9980b309d952?alt=media&token=bcd2ac13-93d5-4234-a6cd-5c7b64625f55"
					}, {
						"title": "Toy Ambulance",
						"linkToFollow": "https://a.co/d/7daDE2w",
						"imageUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2F71758e0b-f945-4771-88cd-83d84e2e5867.da8d0ecf-12d7-41d1-a520-6c19ba9c0fda?alt=media&token=85ed0634-dbf8-4c7b-a71c-90162b67a83a"
					}]
				},
				"metaOrder": null,
				"created": 1723844160,
				"imageInternalID": 22530,
				"MetaUser": {
					"userID": 27354,
					"fullName": "R Murphy",
					"userName": "rmurphy",
					"profileUrl": ""
				}
			}, {
				"metaID": 58148,
				"imageID": "ADDD2223A5B24222AA1194347122F01F",
				"metaType": "CardType",
				"metaContent": {
					"cardType": "artCard"
				},
				"metaOrder": -1,
				"created": 1723844160,
				"imageInternalID": 22530,
				"MetaUser": {
					"userID": 27354,
					"fullName": "R Murphy",
					"userName": "rmurphy",
					"profileUrl": ""
				}
			}],
			"productsArray": [{
				"productID": 8134,
				"imageUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2F4aaeb39e-155c-4357-b313-ab830461663e.8c440ce6-5e94-4dd2-9921-478426dfb1ce?alt=media&token=c5c26810-df5c-4dfc-84e6-f77b155490d9",
				"searchLink": null,
				"searchDescription": "Ambulance rooftop Strobe Lights",
				"orderBy": 0,
				"boundingX": 0,
				"boundingY": 0,
				"boundingW": 0,
				"boundingH": 0,
				"productLinks": [{
					"link": "https://a.co/d/hzzpzlj",
					"title": "Ambulance rooftop Strobe Lights",
					"amount": 0,
					"linkID": 146153,
					"source": null,
					"currency": null,
					"linkOrder": null,
					"thumbNailUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2F4aaeb39e-155c-4357-b313-ab830461663e.8c440ce6-5e94-4dd2-9921-478426dfb1ce?alt=media&token=c5c26810-df5c-4dfc-84e6-f77b155490d9",
					"thumbNailWidth": null,
					"thumbNailHeight": null
				}],
				"informationLinks": []
			}, {
				"productID": 8135,
				"imageUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2Fe253e54a-e61a-4b31-b6c3-58183fc113cc.69a2bc52-4af9-472f-a067-9980b309d952?alt=media&token=bcd2ac13-93d5-4234-a6cd-5c7b64625f55",
				"searchLink": null,
				"searchDescription": "Ambulance Red Flashing Strobe Lights",
				"orderBy": 0,
				"boundingX": 0,
				"boundingY": 0,
				"boundingW": 0,
				"boundingH": 0,
				"productLinks": [{
					"link": "https://a.co/d/iWVx5aL",
					"title": "Ambulance Red Flashing Strobe Lights",
					"amount": 0,
					"linkID": 146154,
					"source": null,
					"currency": null,
					"linkOrder": null,
					"thumbNailUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2Fe253e54a-e61a-4b31-b6c3-58183fc113cc.69a2bc52-4af9-472f-a067-9980b309d952?alt=media&token=bcd2ac13-93d5-4234-a6cd-5c7b64625f55",
					"thumbNailWidth": null,
					"thumbNailHeight": null
				}],
				"informationLinks": []
			}, {
				"productID": 8127,
				"imageUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2F71758e0b-f945-4771-88cd-83d84e2e5867.da8d0ecf-12d7-41d1-a520-6c19ba9c0fda?alt=media&token=85ed0634-dbf8-4c7b-a71c-90162b67a83a",
				"searchLink": null,
				"searchDescription": "Toy Ambulance",
				"orderBy": 0,
				"boundingX": 0,
				"boundingY": 0,
				"boundingW": 0,
				"boundingH": 0,
				"productLinks": [{
					"link": "https://a.co/d/7daDE2w",
					"title": "Toy Ambulance",
					"amount": 0,
					"linkID": 146143,
					"source": null,
					"currency": null,
					"linkOrder": null,
					"thumbNailUrl": "https://firebasestorage.googleapis.com/v0/b/ircode-1a662.appspot.com/o/products%2F71758e0b-f945-4771-88cd-83d84e2e5867.da8d0ecf-12d7-41d1-a520-6c19ba9c0fda?alt=media&token=85ed0634-dbf8-4c7b-a71c-90162b67a83a",
					"thumbNailWidth": null,
					"thumbNailHeight": null
				}],
				"informationLinks": []
			}],
			"masterTemplate": false,
			"imageCreatedReadable": "2024-08-15 08:32:26 pm UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/EA43CD8F092E4AA683A02CD70ED6BAF2",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/EA43CD8F092E4AA683A02CD70ED6BAF2",
			"line1": "The McBee Dynasty: Real American Cowboys - S02E02 - Ditched For Dallas",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/EA43CD8F092E4AA683A02CD70ED6BAF2.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 41.2324,
			"longitude": -95.8751,
			"save": false,
			"timeArchived": 0,
			"campaignName": "The McBee Dynasty: Real American Cowboys - S02E02 - Ditched For Dallas",
			"campaignID": 9137,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 290131,
			"imageID": "EA43CD8F092E4AA683A02CD70ED6BAF2",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/EA43CD8F092E4AA683A02CD70ED6BAF2.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 36337,
			"securedTill": null,
			"imageCreated": 1751936537,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 36337,
				"fullName": "Bravo Script",
				"userName": "BravoScript",
				"userType": "Enterprise",
				"profileUrl": ""
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-07-08 01:02:17 am UTC"
		}, {
			"webUrl": "https://development-ircode-1a662.web.app/image/EB8F42CB48984BC0ABAE533A9C5CB9B9",
			"nativeUrl": "https://development-ircode-1a662.web.app/image/info/EB8F42CB48984BC0ABAE533A9C5CB9B9",
			"line1": "The Real Housewives of Miami - S06E09 - Mamacita Madness Part 1",
			"line2": "",
			"displayImageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/EB8F42CB48984BC0ABAE533A9C5CB9B9.jpeg",
			"objectDetectionStatus": 0,
			"editingAllowed": false,
			"latitude": 41.2324,
			"longitude": -95.8751,
			"save": false,
			"timeArchived": 0,
			"campaignName": "The Real Housewives of Miami - S06E09 - Mamacita Madness Part 1",
			"campaignID": 8444,
			"parentName": null,
			"parentID": null,
			"title": "",
			"metaContent": null,
			"specialType": null,
			"fugacious": false,
			"imageStatus": "publish",
			"internalID": 220637,
			"imageID": "EB8F42CB48984BC0ABAE533A9C5CB9B9",
			"imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/specialAdd/EB8F42CB48984BC0ABAE533A9C5CB9B9.jpeg",
			"imageUrlSmall": null,
			"imageUserID": 36337,
			"securedTill": null,
			"imageCreated": 1751461204,
			"imageWidth": 0,
			"imageHeight": 0,
			"imageSize": 0,
			"sponsored": 0,
			"transferInProcess": 0,
			"removeAfter": 0,
			"startTime": null,
			"stopTime": null,
			"duration": null,
			"groupID": null,
			"jobID": null,
			"timeSaved": null,
			"timeSearched": null,
			"countSimilar": 0,
			"countSearches": 0,
			"countShares": 0,
			"countQueries": 0,
			"viewCount": 0,
			"timeScanned": null,
			"countViews": 0,
			"countSaved": 0,
			"countComments": 0,
			"ImageUser": {
				"userID": 36337,
				"fullName": "Bravo Script",
				"userName": "BravoScript",
				"userType": "Enterprise",
				"profileUrl": ""
			},
			"metaArray": [],
			"productsArray": [],
			"masterTemplate": false,
			"imageCreatedReadable": "2025-07-02 01:00:04 pm UTC"
		}]
	}
}
 */
