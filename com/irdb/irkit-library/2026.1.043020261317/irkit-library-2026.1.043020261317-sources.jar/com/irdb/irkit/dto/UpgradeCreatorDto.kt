package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

/**
 * Request body for upgrading user to Creator account
 */
data class UpgradeToCreatorRequest(
    @SerializedName("updateToCreator")
    val updateToCreator: Boolean = true
)

/**
 * Request body for updating user data with verification fields
 */
data class UpdateUserVerificationRequest(
    @SerializedName("phone")
    val phone: String? = null,

    @SerializedName("email")
    val email: String? = null,

    @SerializedName("emailVerified")
    val emailVerified: Boolean? = null,

    @SerializedName("phoneVerified")
    val phoneVerified: Boolean? = null
)

/**
 * Sealed class representing all possible upgrade errors
 */
sealed class UpgradeError {
    object EmailNotVerified : UpgradeError()
    object PhoneNotVerified : UpgradeError()
    object NotSignedIn : UpgradeError()
    object InvalidPhone : UpgradeError()
    object NetworkError : UpgradeError()
    object AlreadyUpgraded : UpgradeError()
    data class UnknownError(val message: String) : UpgradeError()
    
    val userMessage: String
        get() = when (this) {
            EmailNotVerified -> "Please verify your email address first"
            PhoneNotVerified -> "Please verify your phone number first"
            NotSignedIn -> "Session expired. Please sign in again"
            InvalidPhone -> "Phone number is not valid"
            NetworkError -> "Network error. Please check your connection"
            AlreadyUpgraded -> "Your account is already upgraded to Creator"
            is UnknownError -> "An unexpected error occurred: $message"
        }
    
    val canRetry: Boolean
        get() = when (this) {
            NetworkError -> true
            else -> false
        }
}