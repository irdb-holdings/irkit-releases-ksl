package com.irdb.irkit

import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

suspend fun BackendService.getMyIP(): String? = withContext(Dispatchers.IO) {
    val url = "${BackendService.getBaseUrl()}/myip"
    var connection: HttpURLConnection? = null

    return@withContext try {
        connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.doInput = true
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("sdkapikey", BackendService.getSubscriptionKey())

        val responseCode = connection.responseCode
        val responseBody =
            (if (responseCode in 200..299) connection.inputStream else connection.errorStream)
                ?.let { stream ->
                    BufferedReader(InputStreamReader(stream, "UTF-8")).use { reader ->
                        reader.readText()
                    }
                } ?: ""

        if (BackendService.isDebugMode()) {
            Log.d(BackendService.TAG, "getMyIP HTTP $responseCode: $responseBody")
        }

        if (responseCode in 200..299) {
            parseIpResponse(responseBody)
        } else {
            Log.w(BackendService.TAG, "getMyIP failed with HTTP $responseCode")
            null
        }
    } catch (e: Exception) {
        Log.e(BackendService.TAG, "getMyIP failed", e)
        null
    } finally {
        connection?.disconnect()
    }
}

private fun parseIpResponse(responseBody: String): String? {
    val trimmed = responseBody.trim()
    if (trimmed.isEmpty()) {
        return null
    }

    if (trimmed.startsWith("{")) {
        return try {
            val ipPattern = """"ip"\s*:\s*"([^"]+)"""".toRegex()
            val match = ipPattern.find(trimmed)
            match?.groupValues?.get(1)
        } catch (e: Exception) {
            Log.e(BackendService.TAG, "getMyIP failed to parse JSON response", e)
            null
        }
    }

    return trimmed
}
