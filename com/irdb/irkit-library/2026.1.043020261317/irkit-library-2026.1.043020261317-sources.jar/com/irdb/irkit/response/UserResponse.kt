package com.irdb.irkit.response

/*
{
    "Completed": true,
    "Time": "2025-5-9 12:33:02.829",
    "TimeUsed": 793,
    "GCRLog": "development-v1-43-3115501555-42",
    "NextOffset": 0,
    "Total": 0,
    "Count": 0,
    "Pages": 0,
    "Environment": "DEV",
    "GCFVersion": "development-v1-43-00353-wil",
    "Results": {
        "User": {
            "features": [],
            "enterpriseAccountID": 0,
            "enterpriseWebAccessAllowed": false,
            "projectID": 0,
            "privateAccount": false,
            "internalAdmin": 0,
            "removeAfter": 0,
            "phoneVerified": false,
            "emailVerified": false,
            "videoLimitSeconds": 0,
            "IRCodesMax": 1000,
            "seats": 0,
            "verificationType": "None",
            "analyticsAllowedType": "None",
            "campaignCreationAllowed": false,
            "IRCodesUsed": 0,
            "IRCodesSecured": 0,
            "totalImagesCount": 0,
            "totalArchivedCount": 0,
            "totalHistoryCount": 4,
            "totalSavedCount": 0,
            "email": "",
            "phone": "",
            "profileUrl": "",
            "userName": "",
            "fullName": "",
            "userTypeID": 1,
            "userType": "Anonymous",
            "userTypeDisplay": "Anonymous User",
            "accountLocked": 0,
            "userID": 58697,
            "FBuserID": "23qQWr0zJQN5tXUFcgBdB9AWuX23",
            "countRead": 0,
            "countUnRead": 0,
            "totalNotificationsCount": 0
        },
        "NewUser": false
    }
}
 */

import com.google.gson.annotations.SerializedName

data class UserResponse(
    @SerializedName("User")
    val user: UserData,

    @SerializedName("NewUser")
    val newUser: Boolean
)

data class UserData(

    @SerializedName("features")
    val features: List<String> = emptyList(),

    @SerializedName("enterpriseAccountID")
    val enterpriseAccountId: Int = 0,

    @SerializedName("enterpriseWebAccessAllowed")
    val enterpriseWebAccessAllowed: Boolean = false,

    @SerializedName("projectID")
    val projectId: Int = 0,

    @SerializedName("privateAccount")
    val privateAccount: Boolean = false,

    @SerializedName("internalAdmin")
    val internalAdmin: Int = 0,

    @SerializedName("removeAfter")
    val removeAfter: Int = 0,

    @SerializedName("phoneVerified")
    val phoneVerified: Boolean = false,

    @SerializedName("emailVerified")
    val emailVerified: Boolean = false,

    @SerializedName("videoLimitSeconds")
    val videoLimitSeconds: Int = 0,

    @SerializedName("IRCodesMax")
    val irCodesMax: Int = 1000,

    @SerializedName("seats")
    val seats: Int = 0,

    @SerializedName("verificationType")
    val verificationType: String = "None",

    @SerializedName("analyticsAllowedType")
    val analyticsAllowedType: String = "None",

    @SerializedName("campaignCreationAllowed")
    val campaignCreationAllowed: Boolean = false,

    @SerializedName("IRCodesUsed")
    val irCodesUsed: Int = 0,

    @SerializedName("IRCodesSecured")
    val irCodesSecured: Int = 0,

    @SerializedName("totalImagesCount")
    var totalImagesCount: Int = 0,

    @SerializedName("totalArchivedCount")
    val totalArchivedCount: Int = 0,

    @SerializedName("totalHistoryCount")
    var totalHistoryCount: Int = 0,

    @SerializedName("totalSavedCount")
    var totalSavedCount: Int = 0,

    @SerializedName("email")
    val email: String = "",

    @SerializedName("phone")
    val phone: String = "",

    @SerializedName("profileUrl")
    val profileUrl: String = "",

    @SerializedName("userName")
    val userName: String = "",

    @SerializedName("fullName")
    val fullName: String = "",

    @SerializedName("userTypeID")
    val userTypeId: Int = 0,

    @SerializedName("userType")
    val userType: String = "",

    @SerializedName("userTypeDisplay")
    val userTypeDisplay: String = "",

    @SerializedName("accountLocked")
    val accountLocked: Int = 0,

    @SerializedName("userID")
    val userId: Int = 0,

    @SerializedName("FBuserID")
    val fbUserId: String = "",

    @SerializedName("countRead")
    val countRead: Int = 0,

    @SerializedName("countUnRead")
    val countUnRead: Int = 0,

    @SerializedName("totalNotificationsCount")
    val totalNotificationsCount: Int = 0
) {

    fun describeContents(): String {
        return "UserResponse(" +
            "totalHistoryCount=$totalHistoryCount, " +
            "totalSavedCount=$totalSavedCount, " +
            "email='$email', " +
            "phone='$phone', " +
            "profileUrl='$profileUrl', " +
            "userName='$userName', " +
            "fullName='$fullName', " +
            "userTypeId=$userTypeId, " +
            "userType='$userType', " +
            "userTypeDisplay='$userTypeDisplay', " +
            "accountLocked=$accountLocked, " +
            "userId=$userId, " +
            "fbUserId='$fbUserId', " +
            "countRead=$countRead, " +
            "countUnRead=$countUnRead, " +
            "totalNotificationsCount=$totalNotificationsCount" +
            ")"
    }
}
