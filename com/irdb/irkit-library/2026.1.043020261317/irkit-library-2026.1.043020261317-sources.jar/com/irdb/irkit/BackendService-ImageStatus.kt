package com.irdb.irkit

import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.response.ImageStatusResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.irdb.irkit.enums.ImageStatus

/*
    https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/Images/status
 */

suspend fun BackendService.ImageSstatus(
    imageId: String,
    imageState: ImageStatus
): Boolean =
    withContext(Dispatchers.IO) {
        val endpoint = "/images/status"

        val requestBody = mapOf(
            "status" to imageState.toString(),
            "imageID" to imageId
        )

        if (BackendService.isDebugMode()) {
            Log.i(TAG, "Adding this image status $imageId")
        }

        val response = request<BaseResponse<ImageStatusResponse>>(
            endpoint = endpoint,
            method = HttpMethod.PUT,
            bodyParameters = requestBody,
            responseType = object : TypeToken<BaseResponse<ImageStatusResponse>>() {}.type
        )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        payload.results.updated
    }
