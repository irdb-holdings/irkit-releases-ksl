package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

/** Request model for ImageMeta API endpoint */
data class ImageMetaRequest(
        @SerializedName("imageID") val imageId: String,
        @SerializedName("metaArray") val metaArray: List<MetaRequestItem>
)

/** Individual meta item for the request */
data class MetaRequestItem(
        @SerializedName("metaID") val metaId: Int,
        @SerializedName("metaType") val metaType: String,
        @SerializedName("metaContent") val metaContent: String,
        @SerializedName("metaOrder") val metaOrder: Int? = null,
        @SerializedName("metaDelete") val metaDelete: Boolean = false
)
