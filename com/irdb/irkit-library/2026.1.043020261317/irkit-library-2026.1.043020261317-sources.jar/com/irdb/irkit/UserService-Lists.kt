package com.irdb.irkit

import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.UserService.TAG
import com.irdb.irkit.response.CountsDto
import com.irdb.irkit.response.CountsResponse
import com.irdb.irkit.response.TrashResponse
import com.irdb.irkit.response.UserHistoryResponse
import com.irdb.irkit.response.UserSavedResponse

suspend fun UserService.getUserHistory(offset: Int = 0): BaseResponse<UserHistoryResponse> {
    var endpoint = "/Images/history?offset=$offset"

    val response =
        BackendService.request<BaseResponse<UserHistoryResponse>>(
            endpoint = endpoint,
            method = HttpMethod.GET,
            responseType =
                object : TypeToken<BaseResponse<UserHistoryResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create anonymous user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    return payload
}

suspend fun UserService.getCounts(): CountsDto {
    val endpoint = "/User/counts"

    val response =
        BackendService.request<BaseResponse<CountsResponse>>(
            endpoint = endpoint,
            method = HttpMethod.GET,
            responseType = object : TypeToken<BaseResponse<CountsResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create anonymous user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    // Convert the response to a DTO
    val countsDto =
        CountsDto.fromCountsData(
            payload.results.counts
        )

    if (BackendService.isDebugMode()) {
        val countsData = payload.results.counts
        val historyCount = countsData.totalHistoryCount
        val savedCount = countsData.totalSavedCount
//        Log.d(TAG, "2 Number of images in the history: $historyCount")
//        Log.d(TAG, "Number of images in the saved: $savedCount")
//        Log.d(TAG, "-------")
    }
    return countsDto
}

suspend fun UserService.getUserSaved(offset: Int = 0): BaseResponse<UserSavedResponse> {
    // https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/Images/saved?offset=0

    val endpoint = "/Images/saved?offset=$offset"

    val response =
        BackendService.request<BaseResponse<UserSavedResponse>>(
            endpoint = endpoint,
            method = HttpMethod.GET,
            responseType = object : TypeToken<BaseResponse<UserSavedResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create anonymous user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    if (BackendService.isDebugMode()) {
        val history = payload.results
        Log.d(TAG, "Number of images in the history: $history.images.count()")
    }

    return payload
}

suspend fun UserService.getTrashCan(offset: Int = 0): BaseResponse<TrashResponse> {
    // https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/Removed/images?offset=0

    val endpoint = "/Removed/images?offset=$offset"

    val response =
        BackendService.request<BaseResponse<TrashResponse>>(
            endpoint = endpoint,
            method = HttpMethod.GET,
            responseType = object : TypeToken<BaseResponse<TrashResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create anonymous user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    if (BackendService.isDebugMode()) {
        val history = payload.results
        Log.d(TAG, "Number of images in the history: $history.images.count()")
    }

    return payload
}
