package com.irdb.irkit

import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.UserService.TAG
import com.irdb.irkit.dto.UserDataDTO
import com.irdb.irkit.response.CountsDto
import com.irdb.irkit.response.CountsResponse
import com.irdb.irkit.response.ImageHistoryDeleteResponse
import com.irdb.irkit.response.NameCheckResponse
import com.irdb.irkit.response.UserHistoryResponse
import com.irdb.irkit.response.UserResponse
import com.irdb.irkit.response.UserSavedResponse
import com.irdb.irkit.dto.NotificationItemDto
import com.irdb.irkit.response.NotificationResponse
import com.irdb.irkit.response.ImageStatusResponse


// user Service

object UserService {
    /**
     * Fetch notifications for the current user with pagination support
     * @param offset The offset for pagination (default: 0)
     * @param limit The number of notifications per page (default: 20)
     * @return BaseResponse containing NotificationResponse with pagination metadata
     */
    suspend fun getNotifications(offset: Int = 0, limit: Int = 20): BaseResponse<NotificationResponse> {
        val endpoint = "/Notifications?offset=$offset&limit=$limit"
        val response = BackendService.request<BaseResponse<NotificationResponse>>(
            endpoint = endpoint,
            method = HttpMethod.GET,
            responseType = object : TypeToken<BaseResponse<NotificationResponse>>() {}.type
        )
        if (!response.succeeded || response.payload == null) {
            Log.e(TAG, "Failed to fetch notifications: ${response.errorMessage}")
            throw BackendServiceError.ServerError(response.errorMessage)
        }
        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        return payload
    }

    /**
     * Mark a notification as read.
     * @param notificationId The ID of the notification to mark as read
     * @param markAll If true, marks all notifications as read (ignores notificationId)
     * @return true if the operation was successful
     */
    suspend fun markNotificationAsRead(notificationId: Int, markAll: Boolean = false): Boolean {
        Log.d(TAG, "markNotificationAsRead called: notificationId=$notificationId, markAll=$markAll")
        val endpoint = "/Notifications"
        
        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Marking notification as read: notificationId=$notificationId, markAll=$markAll")
        }

        val requestBody = mapOf(
            "notificationID" to notificationId,
            "markAll" to markAll
        )
        
        Log.d(TAG, "Request body: $requestBody")

        Log.d(TAG, "Calling BackendService.request with endpoint: $endpoint")
        val response = BackendService.request<BaseResponse<ImageStatusResponse>>(
            endpoint = endpoint,
            method = HttpMethod.PUT,
            bodyParameters = requestBody,
            responseType = object : TypeToken<BaseResponse<ImageStatusResponse>>() {}.type
        )
        
        Log.d(TAG, "BackendService.request returned: succeeded=${response.succeeded}")

        if (!response.succeeded || response.payload == null) {
            Log.e(TAG, "Failed to mark notification as read: ${response.errorMessage}")
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        val updated = payload.results.updated
        Log.d(TAG, "Response payload updated field: $updated")

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Successfully marked notification as read: updated=$updated")
        }

        return updated
    }
    internal const val TAG = "UserService"


    suspend fun deleteImageFromHistory(imageId: String): Boolean {
        val endpoint = "/Images/history/$imageId"

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Attempting to delete image from history: $imageId")
            Log.d(TAG, "Firebase token present: ${BackendService.firebaseToken != null}")
        }

        val response =
                BackendService.request<BaseResponse<ImageHistoryDeleteResponse>>(
                        endpoint = endpoint,
                        method = HttpMethod.DELETE,
                        responseType =
                                object : TypeToken<BaseResponse<ImageHistoryDeleteResponse>>() {}
                                        .type
                )

        if (!response.succeeded || response.payload == null) {
            Log.e(TAG, "Failed to delete image from history: ${response.errorMessage}")
            Log.e(TAG, "Response status code: ${response.httpStatusCode}")
            Log.e(TAG, "Response URL: ${response.url}")
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Successfully deleted image from history: $imageId")
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        return payload.results.removed
    }


    // https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/User/nameCheck/hdhdjd
    suspend fun userNameCheck(name: String): Boolean {
        val endpoint = "/User/nameCheck/$name"

        val response =
                BackendService.request<BaseResponse<NameCheckResponse>>(
                        endpoint = endpoint,
                        method = HttpMethod.GET,
                        responseType = object : TypeToken<BaseResponse<NameCheckResponse>>() {}.type
                )

        if (!response.succeeded || response.payload == null) {
            Log.e(TAG, "Failed to create anonymous user: ${response.errorMessage}")
            throw BackendServiceError.ServerError(response.errorMessage)
        }
        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        return payload.results.Available
    }

    /**
     * Get current user data from the backend
     * This endpoint should return the user's profile information
     */
    suspend fun getUserData(): UserDataDTO {
        val endpoint = "/User"

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "-- IRCode::getUserData --")
        }

        val response =
            BackendService.request<BaseResponse<UserResponse>>(
                endpoint = endpoint,
                method = HttpMethod.GET,
                responseType = object : TypeToken<BaseResponse<UserResponse>>() {}.type
            )

        if (!response.succeeded || response.payload == null) {
            Log.e(TAG, "Failed to get user data: ${response.errorMessage}")
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        if (BackendService.isDebugMode()) {
            val ur = payload.results
            Log.d(TAG, ur.user.describeContents())
        }

        val userDataDto =
            UserDataDTO.fromUserResponse(
                payload.results.user
            )
        return userDataDto
    }

    /**
     * Delete the current user's account
     * This will permanently delete the user and all associated data
     * @return true if deletion was successful
     */
    suspend fun deleteAccount(): Boolean {
        val endpoint = "/User"

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "-- IRCode::deleteAccount --")
            Log.d(TAG, "Attempting to delete user account")
        }

        val response =
            BackendService.request<BaseResponse<Any>>(
                endpoint = endpoint,
                method = HttpMethod.DELETE,
                responseType = object : TypeToken<BaseResponse<Any>>() {}.type
            )

        if (!response.succeeded || response.payload == null) {
            Log.e(TAG, "Failed to delete account: ${response.errorMessage}")
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        val completed = payload.completed

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Successfully deleted user account: completed=$completed")
        }

        return completed
    }

    /**
     * Remove the user's profile picture from the backend
     * This calls DELETE /User/profileUrl to remove the profile image
     * @return true if removal was successful
     */
    suspend fun removeProfileImage(): Boolean {
        val endpoint = "/User/profileUrl"

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "-- IRCode::removeProfileImage --")
            Log.d(TAG, "Attempting to remove user profile image")
        }

        val response =
            BackendService.request<BaseResponse<Any>>(
                endpoint = endpoint,
                method = HttpMethod.DELETE,
                responseType = object : TypeToken<BaseResponse<Any>>() {}.type
            )

        if (!response.succeeded || response.payload == null) {
            Log.e(TAG, "Failed to remove profile image: ${response.errorMessage}")
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        val completed = payload.completed

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Successfully removed profile image: completed=$completed")
        }

        return completed
    }
}

suspend fun UserService.deleteUsersHistory(): Boolean {
    val endpoint = "/Images/history"

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "Attempting to delete users history")
        Log.d(TAG, "Firebase token present: ${BackendService.firebaseToken != null}")
    }

    val response =
        BackendService.request<BaseResponse<ImageHistoryDeleteResponse>>(
            endpoint = endpoint,
            method = HttpMethod.DELETE,
            responseType =
                object : TypeToken<BaseResponse<ImageHistoryDeleteResponse>>() {}
                    .type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to delete image from history: ${response.errorMessage}")
        Log.e(TAG, "Response status code: ${response.httpStatusCode}")
        Log.e(TAG, "Response URL: ${response.url}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "Successfully deleted users history")
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    return payload.results.removed
}
