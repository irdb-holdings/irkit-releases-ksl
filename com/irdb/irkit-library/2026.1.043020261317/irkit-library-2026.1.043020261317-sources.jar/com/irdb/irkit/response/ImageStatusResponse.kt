package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.ImageDto


/*
{
	"Completed": true,
	"Time": "2025-8-13 08:15:08.702",
	"TimeUsed": 26,
	"GCRLog": "development-v1-43-2977739289-103",
	"NextOffset": 0,
	"Total": 0,
	"Count": 0,
	"Pages": 0,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00879-xoz",
	"Results": {
		"Updated": true
	}
}
 */

data class ImageStatusResponse(
    @SerializedName("Updated")
    val updated: Boolean = false,
)
