package com.irdb.irkit

interface BEDecodable {
    val completed: Boolean
    val timeUsed: Double
    val nextOffset: Int
    val count: Int
    val pages: Int
    val environment: String
    val gcfVersion: String
    val errorMessage: String
}
