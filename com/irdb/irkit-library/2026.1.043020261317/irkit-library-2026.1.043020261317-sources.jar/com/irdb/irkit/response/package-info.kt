/**
 * API response models and containers.
 * 
 * This package will contain:
 * - API response data classes
 * - Response containers and wrappers
 * - Error response models
 * - Response parsing utilities
 */
package com.irdb.irkit.response