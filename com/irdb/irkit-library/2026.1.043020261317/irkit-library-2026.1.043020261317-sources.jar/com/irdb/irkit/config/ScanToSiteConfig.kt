package com.irdb.irkit.config

/**
 * Runtime configuration for scan-to-site behavior.
 *
 * Master switch comes from the backend `getLens()` response
 * (characteristics.enableAutoLaunchSTS) and is refreshed on every lens load.
 *
 * A local override (userDisabledAutoLaunchSTS) lets an app turn the feature
 * OFF even when the backend has it enabled. The override can never turn the
 * feature ON when the backend has it disabled.
 */
object ScanToSiteConfig {

    /**
     * Master flag from the backend. Set by IRKit-UI's refreshLensConfig only.
     * Do not set this from app code.
     */
    @Volatile var backendEnableAutoLaunchSTS: Boolean = false

    /**
     * Local override. When true, suppresses auto-launch even if the backend
     * has it enabled. Has no effect when the backend flag is already false.
     */
    @Volatile var userDisabledAutoLaunchSTS: Boolean = false

    /**
     * Effective value read by IRKit-UI. True only when the backend has
     * enabled the feature AND the local override has not disabled it.
     */
    val enableAutoLaunchSTS: Boolean
        get() = backendEnableAutoLaunchSTS && !userDisabledAutoLaunchSTS
}
