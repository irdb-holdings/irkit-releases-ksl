package com.irdb.irkit.utils

import android.util.Log
import com.irdb.irkit.IRKitConfiguration
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Tracks the lifecycle of images from capture to recognition result.
 * Each image gets a unique tracking ID and timestamps are recorded at key stages.
 */
object ImageLifecycleTracker {
    private const val TAG = "ImageLifecycle"
    private const val HISTORY_SIZE = 1000

    // Configuration reference for logging control
    private var configuration: IRKitConfiguration? = null

    // Stores tracking data for each image
    private val activeTracking = ConcurrentHashMap<String, ImageLifecycleData>()
    private val recognitionCompleteTimes = ConcurrentHashMap<String, Long>()
    private val notificationDisplayedTimes = ConcurrentHashMap<String, Long>()

    // Stores completed tracking data for statistics
    private val completedHistory = mutableListOf<CompletedTracking>()
    private val historyLock = Any()

    // Frame statistics counters for live frame processing
    private val totalDroppedFrames = AtomicLong(0)
    private val totalCompletedFrames = AtomicLong(0)

    /**
     * Sets the configuration for logging control
     */
    fun setConfiguration(config: IRKitConfiguration) {
        this.configuration = config
    }

    /**
     * Checks if ImageLifecycle logging is enabled
     */
    private fun isLoggingEnabled(): Boolean {
        return configuration?.isImageLifecycleLoggingEnabled() ?: false
    }

    // Lifecycle stages
    enum class Stage {
        CAPTURE_START,
        CAPTURE_COMPLETE,
        COMPRESSION_START,
        COMPRESSION_COMPLETE,
        UPLOAD_START,
        UPLOAD_COMPLETE,
        RECOGNITION_START,
        RECOGNITION_COMPLETE,
        NOTIFICATION_DISPLAYED,
        RESULT_HANDLED,
        FRAME_DROPPED
    }

    data class CompletedTracking(
        val trackingId: String,
        val wasRecognized: Boolean,
        val imageId: String?,
        val totalTimeMs: Long,
        val compressionTimeMs: Long?,
        val uploadTimeMs: Long?,
        val recognitionTimeMs: Long?,
        val captureToRecognitionMs: Long?,
        val recognitionToNotificationMs: Long?,
        val timestamp: Long = System.currentTimeMillis()
    )

    data class ImageLifecycleData(
        val trackingId: String,
        val startTimestamp: Long = System.currentTimeMillis(),
        val stages: MutableMap<Stage, Long> = mutableMapOf()
    ) {
        init {
            stages[Stage.CAPTURE_START] = startTimestamp
        }

        fun recordStage(stage: Stage) {
            stages[stage] = System.currentTimeMillis()
            logStage(stage)
        }

        private fun logStage(stage: Stage) {
            if (!isLoggingEnabled()) return
            val elapsedMs = (System.currentTimeMillis() - startTimestamp)
            Log.d(TAG, "[$trackingId] $stage at ${elapsedMs}ms from capture")
        }

        fun getElapsedTime(fromStage: Stage = Stage.CAPTURE_START, toStage: Stage): Long? {
            val start = stages[fromStage] ?: return null
            val end = stages[toStage] ?: return null
            return end - start
        }

        fun getTotalElapsedMs(): Long {
            return System.currentTimeMillis() - startTimestamp
        }
    }

    /**
     * Starts tracking a new image with a unique ID
     * @return The tracking ID for this image
     */
    fun startTracking(): String {
        val trackingId = UUIDGenerator.generateSessionTrackingID()
        val data = ImageLifecycleData(trackingId)
        activeTracking[trackingId] = data
        if (isLoggingEnabled()) {
            Log.d(TAG, "Started tracking image: $trackingId")
        }
        return trackingId
    }

    /**
     * Records a stage for an image being tracked
     */
    fun recordStage(trackingId: String, stage: Stage) {
        val now = System.currentTimeMillis()
        when (stage) {
            Stage.RECOGNITION_COMPLETE -> recognitionCompleteTimes[trackingId] = now
            Stage.NOTIFICATION_DISPLAYED -> notificationDisplayedTimes[trackingId] = now
            else -> Unit
        }
        activeTracking[trackingId]?.recordStage(stage)
    }

    /**
     * Gets the lifecycle data for a tracked image
     */
    fun getLifecycleData(trackingId: String): ImageLifecycleData? {
        return activeTracking[trackingId]
    }

    /**
     * Records a dropped frame (frame cancelled because newer frame completed first)
     */
    fun recordFrameDropped() {
        totalDroppedFrames.incrementAndGet()
    }

    /**
     * Records a completed frame (frame successfully processed and delivered to UI)
     */
    fun recordFrameCompleted() {
        totalCompletedFrames.incrementAndGet()
    }

    /**
     * Gets frame processing statistics
     */
    fun getFrameStatistics(): FrameStatistics {
        return FrameStatistics(
            droppedFramesCount = totalDroppedFrames.get(),
            completedFramesCount = totalCompletedFrames.get()
        )
    }

    /**
     * Resets frame statistics counters
     */
    fun resetFrameStatistics() {
        totalDroppedFrames.set(0)
        totalCompletedFrames.set(0)
        if (isLoggingEnabled()) {
            Log.d(TAG, "Reset frame statistics")
        }
    }
    
    /**
     * Get time from recognition complete to notification displayed (timeToDisplay metric).
     * This is used by analytics to track how long it takes for the notification card
     * to appear after image recognition completes.
     * 
     * @param trackingId The tracking ID for the image
     * @return Time in milliseconds from RECOGNITION_COMPLETE to NOTIFICATION_DISPLAYED, or null if not available
     */
    fun getTimeToDisplay(trackingId: String): Long? {
        val data = activeTracking[trackingId]
        if (data != null) {
            // Check if both stages are recorded
            val hasRecognitionComplete = data.stages.containsKey(Stage.RECOGNITION_COMPLETE)
            val hasNotificationDisplayed = data.stages.containsKey(Stage.NOTIFICATION_DISPLAYED)

            if (!hasRecognitionComplete) {
                Log.w(TAG, "⚠️ [timeToDisplay] RECOGNITION_COMPLETE stage not recorded for trackingId: $trackingId")
            }
            if (!hasNotificationDisplayed) {
                Log.w(TAG, "⚠️ [timeToDisplay] NOTIFICATION_DISPLAYED stage not recorded for trackingId: $trackingId")
            }

            val timeToDisplay = data.getElapsedTime(
                fromStage = Stage.RECOGNITION_COMPLETE,
                toStage = Stage.NOTIFICATION_DISPLAYED
            )

            if (timeToDisplay != null) {
                val normalizedTimeToDisplay = if (timeToDisplay <= 0L) 1L else timeToDisplay
                Log.d(TAG, "✅ [$trackingId] timeToDisplay: $normalizedTimeToDisplay (RECOGNITION_COMPLETE → NOTIFICATION_DISPLAYED)")
                return normalizedTimeToDisplay
            }
        }

        val recognitionTime = recognitionCompleteTimes[trackingId]
        val notificationTime = notificationDisplayedTimes[trackingId]
        if (recognitionTime != null && notificationTime != null) {
            val timeToDisplay = maxOf(0L, notificationTime - recognitionTime)
            val normalizedTimeToDisplay = if (timeToDisplay <= 0L) 1L else timeToDisplay
            Log.d(TAG, "✅ [$trackingId] timeToDisplay: $normalizedTimeToDisplay (RECOGNITION_COMPLETE → NOTIFICATION_DISPLAYED)")
            return normalizedTimeToDisplay
        }

        Log.w(TAG, "⚠️ [timeToDisplay] No tracking data found for ID: $trackingId")
        return null
    }

    /**
     * Completes tracking for an image and logs the final summary
     */
    fun completeTracking(trackingId: String, wasRecognized: Boolean, imageId: String? = null, wasDropped: Boolean = false) {
        val data = activeTracking[trackingId] ?: run {
            if (isLoggingEnabled()) {
                Log.w(TAG, "No tracking data found for ID: $trackingId")
            }
            return
        }

        if (wasDropped) {
            data.recordStage(Stage.FRAME_DROPPED)
        } else {
            data.recordStage(Stage.RESULT_HANDLED)
        }

        val totalTimeMs = data.getTotalElapsedMs()
        val totalTimeSec = totalTimeMs / 1000.0

        // Build detailed timing breakdown
        val breakdown = buildString {
            appendLine("=" .repeat(70))
            appendLine("IMAGE LIFECYCLE SUMMARY - $trackingId")
            appendLine("=" .repeat(70))
            appendLine("Status: ${if (wasRecognized) "RECOGNIZED" else "NOT RECOGNIZED"}")
            imageId?.let { appendLine("Image ID: $it") }
            appendLine("Total Time: %.3f seconds (${totalTimeMs}ms)".format(totalTimeSec))
            appendLine()
            appendLine("Stage Breakdown:")

            val stages = listOf(
                Stage.CAPTURE_START to "Image Capture Started",
                Stage.CAPTURE_COMPLETE to "Image Capture Complete",
                Stage.COMPRESSION_START to "Compression Started",
                Stage.COMPRESSION_COMPLETE to "Compression Complete",
                Stage.UPLOAD_START to "Upload Started",
                Stage.UPLOAD_COMPLETE to "Upload Complete",
                Stage.RECOGNITION_START to "Recognition Started",
                Stage.RECOGNITION_COMPLETE to "Recognition Complete",
                Stage.NOTIFICATION_DISPLAYED to "Notification Displayed",
                Stage.RESULT_HANDLED to "Result Handled"
            )

            var previousStage: Stage? = null
            for ((stage, label) in stages) {
                data.stages[stage]?.let { timestamp ->
                    val elapsedFromStart = timestamp - data.startTimestamp
                    val stageDuration = if (previousStage != null) {
                        data.getElapsedTime(previousStage!!, stage) ?: 0
                    } else {
                        0
                    }

                    appendLine("  %-30s %6dms (+%dms)".format(
                        label,
                        elapsedFromStart,
                        stageDuration
                    ))
                    previousStage = stage
                }
            }

            appendLine()
            appendLine("Key Metrics:")
            data.getElapsedTime(Stage.COMPRESSION_START, Stage.COMPRESSION_COMPLETE)?.let {
                appendLine("  Compression Time: ${it}ms")
            }
            data.getElapsedTime(Stage.UPLOAD_START, Stage.UPLOAD_COMPLETE)?.let {
                appendLine("  Upload Time: ${it}ms")
            }
            data.getElapsedTime(Stage.RECOGNITION_START, Stage.RECOGNITION_COMPLETE)?.let {
                appendLine("  Recognition Time: ${it}ms")
            }
            data.getElapsedTime(Stage.CAPTURE_START, Stage.RECOGNITION_COMPLETE)?.let {
                appendLine("  Capture to Recognition: ${it}ms")
            }
            data.getElapsedTime(Stage.RECOGNITION_COMPLETE, Stage.NOTIFICATION_DISPLAYED)?.let {
                appendLine("  Recognition to Notification: ${it}ms")
            }

            appendLine("=" .repeat(70))
        }

        if (isLoggingEnabled()) {
            Log.i(TAG, breakdown)
        }

        // Save to history for statistics
        val completed = CompletedTracking(
            trackingId = trackingId,
            wasRecognized = wasRecognized,
            imageId = imageId,
            totalTimeMs = totalTimeMs,
            compressionTimeMs = data.getElapsedTime(Stage.COMPRESSION_START, Stage.COMPRESSION_COMPLETE),
            uploadTimeMs = data.getElapsedTime(Stage.UPLOAD_START, Stage.UPLOAD_COMPLETE),
            recognitionTimeMs = data.getElapsedTime(Stage.RECOGNITION_START, Stage.RECOGNITION_COMPLETE),
            captureToRecognitionMs = data.getElapsedTime(Stage.CAPTURE_START, Stage.RECOGNITION_COMPLETE),
            recognitionToNotificationMs = data.getElapsedTime(Stage.RECOGNITION_COMPLETE, Stage.NOTIFICATION_DISPLAYED)
        )

        synchronized(historyLock) {
            completedHistory.add(completed)
            // Keep only last HISTORY_SIZE entries
            if (completedHistory.size > HISTORY_SIZE) {
                completedHistory.removeAt(0)
            }
        }

        // Clean up to prevent memory leaks
        activeTracking.remove(trackingId)
    }

    /**
     * Clears all tracking data (useful for cleanup)
     */
    fun clearAll() {
        activeTracking.clear()
        recognitionCompleteTimes.clear()
        notificationDisplayedTimes.clear()
        if (isLoggingEnabled()) {
            Log.d(TAG, "Cleared all tracking data")
        }
    }

    /**
     * Gets count of currently tracked images
     */
    fun getActiveTrackingCount(): Int {
        return activeTracking.size
    }

    /**
     * Gets count of completed tracking entries in history
     */
    fun getHistoryCount(): Int {
        return synchronized(historyLock) { completedHistory.size }
    }

    /**
     * Clears the history of completed trackings
     */
    fun clearHistory() {
        synchronized(historyLock) {
            completedHistory.clear()
        }
        if (isLoggingEnabled()) {
            Log.d(TAG, "Cleared tracking history")
        }
    }

    /**
     * Gets statistics for the last N completed trackings
     * @param count Number of recent entries to analyze (default: all in history, max: HISTORY_SIZE)
     */
    fun getStatistics(count: Int = HISTORY_SIZE): TrackingStatistics? {
        val entries = synchronized(historyLock) {
            if (completedHistory.isEmpty()) return null
            val takeCount = minOf(count, completedHistory.size)
            completedHistory.takeLast(takeCount)
        }

        if (entries.isEmpty()) return null

        val recognized = entries.count { it.wasRecognized }
        val notRecognized = entries.size - recognized

        // Helper to safely average nullable values
        fun List<Long?>.safeAverage(): Double? {
            val nonNull = this.filterNotNull()
            return if (nonNull.isEmpty()) null else nonNull.average()
        }

        return TrackingStatistics(
            totalCount = entries.size,
            recognizedCount = recognized,
            notRecognizedCount = notRecognized,
            avgTotalTimeMs = entries.map { it.totalTimeMs }.average(),
            minTotalTimeMs = entries.minOfOrNull { it.totalTimeMs } ?: 0,
            maxTotalTimeMs = entries.maxOfOrNull { it.totalTimeMs } ?: 0,
            avgCompressionTimeMs = entries.map { it.compressionTimeMs }.safeAverage(),
            avgUploadTimeMs = entries.map { it.uploadTimeMs }.safeAverage(),
            avgRecognitionTimeMs = entries.map { it.recognitionTimeMs }.safeAverage(),
            avgCaptureToRecognitionMs = entries.map { it.captureToRecognitionMs }.safeAverage(),
            avgRecognitionToNotificationMs = entries.map { it.recognitionToNotificationMs }.safeAverage(),
            droppedFramesCount = totalDroppedFrames.get(),
            completedFramesCount = totalCompletedFrames.get()
        )
    }

    /**
     * Logs a statistics summary for the last N completed trackings
     * @param count Number of recent entries to analyze (default: all in history)
     */
    fun logStatistics(count: Int = HISTORY_SIZE) {
        val stats = getStatistics(count) ?: run {
            if (isLoggingEnabled()) {
                Log.i(TAG, "No tracking history available for statistics")
            }
            return
        }

        val summary = buildString {
            appendLine()
            appendLine("=" .repeat(70))
            appendLine("IMAGE LIFECYCLE STATISTICS")
            appendLine("Last ${stats.totalCount} images tracked")
            appendLine("=" .repeat(70))
            appendLine()
            appendLine("Recognition Results:")
            appendLine("  ✓ Recognized:     ${stats.recognizedCount} (${stats.recognitionRate}%)")
            appendLine("  ✗ Not Recognized: ${stats.notRecognizedCount}")
            appendLine()
            appendLine("Total Time:")
            appendLine("  Average: ${stats.avgTotalTimeMs.toInt()}ms (%.3fs)".format(stats.avgTotalTimeMs / 1000.0))
            appendLine("  Min:     ${stats.minTotalTimeMs}ms")
            appendLine("  Max:     ${stats.maxTotalTimeMs}ms")
            appendLine()
            appendLine("Stage Averages:")
            stats.avgCompressionTimeMs?.let {
                appendLine("  Compression:         ${it.toInt()}ms")
            }
            stats.avgUploadTimeMs?.let {
                appendLine("  Upload:              ${it.toInt()}ms")
            }
            stats.avgRecognitionTimeMs?.let {
                appendLine("  Recognition:         ${it.toInt()}ms")
            }
            stats.avgCaptureToRecognitionMs?.let {
                appendLine("  Capture→Recognition: ${it.toInt()}ms")
            }
            stats.avgRecognitionToNotificationMs?.let {
                appendLine("  Recognition→Notification: ${it.toInt()}ms")
            }
            appendLine("=" .repeat(70))
        }

        if (isLoggingEnabled()) {
            Log.i(TAG, summary)
        }
    }

    data class FrameStatistics(
        val droppedFramesCount: Long,
        val completedFramesCount: Long
    )

    data class TrackingStatistics(
        val totalCount: Int,
        val recognizedCount: Int,
        val notRecognizedCount: Int,
        val avgTotalTimeMs: Double,
        val minTotalTimeMs: Long,
        val maxTotalTimeMs: Long,
        val avgCompressionTimeMs: Double?,
        val avgUploadTimeMs: Double?,
        val avgRecognitionTimeMs: Double?,
        val avgCaptureToRecognitionMs: Double?,
        val avgRecognitionToNotificationMs: Double?,
        val droppedFramesCount: Long,
        val completedFramesCount: Long
    ) {
        val recognitionRate: Int
            get() = if (totalCount > 0) (recognizedCount * 100 / totalCount) else 0
    }
}
