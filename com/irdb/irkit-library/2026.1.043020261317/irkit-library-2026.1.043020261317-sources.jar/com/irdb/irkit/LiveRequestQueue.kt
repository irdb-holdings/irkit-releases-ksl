package com.irdb.irkit

import android.util.Log
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Manages concurrent network requests with queue overflow handling and stale request cancellation.
 * Matches iOS LiveVisualSearchProcessor behavior for optimal performance.
 *
 * Key features:
 * - Up to 10 concurrent requests (matches iOS)
 * - 5-second timeout (matches iOS URLSession.timeoutIntervalForRequest)
 * - Automatic stale request cancellation after 7 seconds (safety net for hung requests)
 * - Queue overflow management with priority-based drops
 * - Periodic cleanup of timed-out requests
 */
class LiveRequestQueue {
    companion object {
        private const val MAX_CONCURRENT_REQUESTS = 10
        private const val MAX_PENDING_LOW_PRIORITY = 8
        private const val MAX_PENDING_HIGH_PRIORITY = 15
        private const val REQUEST_TIMEOUT_MS = 5000L  // 5 seconds - matches iOS URLSession timeout
        private const val STALE_CHECK_INTERVAL_MS = 2000L  // Check every 2 seconds
        private const val STALE_THRESHOLD_MS = 7000L  // Cancel at 7 seconds (after normal timeout as safety net)
        private const val TAG = "LiveRequestQueue"
    }

    data class ActiveRequest(
        val trackingId: String,
        val connection: HttpURLConnection,
        val startTime: Long,
        val job: Job
    )

    private val activeRequests = ConcurrentHashMap<String, ActiveRequest>()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var staleCheckJob: Job? = null
    private var consecutiveFailures = 0
    private var consecutiveCancellations = 0

    init {
        startStaleRequestCancellation()
    }

    /**
     * Get the number of currently active requests.
     */
    fun getActiveRequestCount(): Int = activeRequests.size

    /**
     * Check if there's room for more requests.
     */
    fun hasCapacity(): Boolean = activeRequests.size < MAX_CONCURRENT_REQUESTS

    /**
     * Register an active request for tracking and potential stale cancellation.
     *
     * @param trackingId Unique identifier for this request
     * @param connection The HttpURLConnection to cancel if needed
     * @param job The coroutine job to cancel if needed
     */
    fun registerRequest(trackingId: String, connection: HttpURLConnection, job: Job) {
        val request = ActiveRequest(
            trackingId = trackingId,
            connection = connection,
            startTime = System.currentTimeMillis(),
            job = job
        )
        activeRequests[trackingId] = request

        if (BuildConfig.DEBUG) {
            Log.d(TAG, "Registered request $trackingId. Active: ${activeRequests.size}/$MAX_CONCURRENT_REQUESTS")
        }
    }

    /**
     * Unregister a request when it completes (success or failure).
     */
    fun unregisterRequest(trackingId: String) {
        activeRequests.remove(trackingId)?.let {
            if (BuildConfig.DEBUG) {
                val duration = System.currentTimeMillis() - it.startTime
                Log.d(TAG, "Unregistered request $trackingId after ${duration}ms. Active: ${activeRequests.size}")
            }
        }
    }

    /**
     * Start periodic timer to cancel stale requests that exceed threshold.
     * Checks every 2s, cancels requests older than 7s (safety net for hung connections).
     * Note: Normal timeouts (5s) should handle most cases - this is for stuck requests.
     */
    private fun startStaleRequestCancellation() {
        staleCheckJob = scope.launch {
            while (isActive) {
                delay(STALE_CHECK_INTERVAL_MS)
                cancelStaleRequests()
            }
        }
    }

    /**
     * Cancel requests that have been active longer than the stale threshold.
     */
    private fun cancelStaleRequests() {
        val now = System.currentTimeMillis()
        var cancelledCount = 0

        val iterator = activeRequests.entries.iterator()
        while (iterator.hasNext()) {
            val (trackingId, activeRequest) = iterator.next()
            val elapsed = now - activeRequest.startTime

            if (elapsed > STALE_THRESHOLD_MS) {
                // Cancel the request
                try {
                    activeRequest.connection.disconnect()
                    activeRequest.job.cancel()
                    iterator.remove()
                    cancelledCount++
                    consecutiveCancellations++

                    if (BuildConfig.DEBUG) {
                        Log.d(TAG, "Cancelled stale request $trackingId after ${elapsed}ms")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error cancelling stale request $trackingId: ${e.message}")
                }
            }
        }

        if (cancelledCount > 0) {
            Log.d(TAG, "Cancelled $cancelledCount stale requests. Active: ${activeRequests.size}")

            // Track network degradation if too many cancellations
            if (consecutiveCancellations >= 6) {
                Log.w(TAG, "Network may be degraded - $consecutiveCancellations consecutive cancellations")
            }
        } else {
            // Reset cancellation counter on successful cycle
            if (consecutiveCancellations > 0) {
                consecutiveCancellations = 0
            }
        }
    }

    /**
     * Clear all active requests (called when stopping session).
     */
    fun clearAll() {
        val count = activeRequests.size
        activeRequests.values.forEach { request ->
            try {
                request.connection.disconnect()
                request.job.cancel()
            } catch (e: Exception) {
                // Ignore errors during cleanup
            }
        }
        activeRequests.clear()
        consecutiveFailures = 0
        consecutiveCancellations = 0
        Log.d(TAG, "Cleared $count active requests")
    }

    /**
     * Cleanup resources when queue is no longer needed.
     */
    fun cleanup() {
        staleCheckJob?.cancel()
        clearAll()
        scope.cancel()
        Log.d(TAG, "LiveRequestQueue cleaned up")
    }

    /**
     * Get statistics about queue performance.
     */
    fun getStats(): String {
        return "Active: ${activeRequests.size}/$MAX_CONCURRENT_REQUESTS, " +
               "Consecutive Failures: $consecutiveFailures, " +
               "Consecutive Cancellations: $consecutiveCancellations"
    }
}
