package com.irdb.irkit

sealed class APIError : Exception() {
    data class NetworkError(override val message: String, val code: Int) : APIError()
    data class ServerError(override val message: String, val code: Int) : APIError()
    data class ParsingError(override val message: String, override val cause: Throwable? = null) : APIError()
    data class UnknownError(override val message: String, override val cause: Throwable? = null) : APIError()
}
