/**
 * API layer containing service classes for backend communication.
 * 
 * This package will contain:
 * - BackendService: Main REST API service
 * - UserService: User management APIs
 * - API client configurations
 * - Network interceptors and adapters
 */
package com.irdb.irkit.api