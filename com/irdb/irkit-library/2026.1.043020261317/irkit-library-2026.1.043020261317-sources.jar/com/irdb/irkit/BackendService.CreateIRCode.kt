package com.irdb.irkit

import com.google.gson.reflect.TypeToken
import com.irdb.irkit.response.CreateIRCodeResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Creates an IRCode from an uploaded image URL.
 * 
 * This function sends a PUT request to the IREngine endpoint to process an image
 * and create an IRCode entry in the system. The image must be previously uploaded
 * to Firebase Storage and accessible via the provided URL.
 * 
 * @param imageUrl The Firebase Storage URL of the uploaded image to process
 * @return CreateIRCodeResponse containing the creation status and image details
 * @throws BackendServiceError.ServerError if the request fails or server returns an error
 * 
 * ## Request Format
 * The function sends a JSON request body with the following structure:
 * ```json
 * {
 *   "imageUrl": "https://storage.googleapis.com/ircode-1a662.appspot.com/irdbAdd/E6FB0795EBB442E6A68383DFDA6AEDED.jpeg"
 * }
 * ```
 * 
 * ## Authentication
 * This function requires Firebase authentication. The Firebase token is automatically
 * included in the request headers if available. Anonymous users cannot create IRCodes
 * and will receive an authentication error.
 * 
 * ## Response Structure
 * Returns a [CreateIRCodeResponse] containing:
 * - `ImageAdded`: Boolean indicating if the image was successfully added
 * - `image`: [ImageDto] containing the processed image metadata and details
 * 
 * ## Error Handling
 * - Throws [BackendServiceError.ServerError] if the server request fails
 * - Throws [BackendServiceError.AccessDenied] if authentication fails
 * - Throws [BackendServiceError.InvalidResponse] if the response format is invalid
 * 
 * ## Usage Example
 * ```kotlin
 * try {
 *     val response = backendService.CreateIRCode("https://storage.googleapis.com/...")
 *     if (response.ImageAdded) {
 *         val imageId = response.image.imageId
 *         // Process the created IRCode
 *     }
 * } catch (e: BackendServiceError) {
 *     // Handle error appropriately
 * }
 * ```
 * 
 * ## Thread Safety
 * This function runs on the IO dispatcher to perform network operations
 * off the main thread, following Android best practices for background operations.
 * 
 * @see CreateIRCodeResponse
 * @see ImageDto
 * @see BackendServiceError
 */
suspend fun BackendService.CreateIRCode(imageUrl: String): CreateIRCodeResponse =
    withContext(Dispatchers.IO) {
        val endpoint = "/IREngine"

        val requestBody = mapOf("imageUrl" to imageUrl)

        val response = request<BaseResponse<CreateIRCodeResponse>>(
            endpoint = endpoint,
            method = HttpMethod.PUT,
            bodyParameters = requestBody,
            responseType = object : TypeToken<BaseResponse<CreateIRCodeResponse>>() {}.type,
            headerParameters = firebaseToken?.let { mapOf("auth" to it) }
        )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        payload.results
    }
