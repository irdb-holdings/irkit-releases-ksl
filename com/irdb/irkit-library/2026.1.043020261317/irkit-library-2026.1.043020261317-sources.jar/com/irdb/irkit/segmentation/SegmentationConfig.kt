package com.irdb.irkit.segmentation

/**
 * Runtime configuration for the ONNX segmentation pipeline.
 *
 * Values are initialized from IRKit-UI's ClientConfigBase during IRKitUI.initialize().
 * IRKit-UI is the authority for [segmentationEnabled] and [showBoundingBoxOverlay] —
 * they are set per-client in the configuration files (KslConfig, IrcodeConfig, etc.).
 *
 * Self-tuning (SegmentationManager) may override [segmentationEnabled] and
 * [inferenceIntervalMs] at runtime based on device benchmark results.
 *
 * All mutable fields are @Volatile for safe cross-thread access.
 */
object SegmentationConfig {

    // ── Master switch ────────────────────────────────────────────────────────
    // Controlled by IRKit-UI configuration. Self-tuning may disable at runtime
    // on devices too slow for real-time inference.
    @Volatile var segmentationEnabled: Boolean = true

    // ── Model name ────────────────────────────────────────────────────────────
    // Set by IRKitUI from getLens characteristics. SegmentationManager reads
    // this when creating a new SegmentationProcessor instance.
    @Volatile var modelName: String = SegmentationModelResolver.MODEL_GAZENET_TV

    // ── Bounding box overlay ─────────────────────────────────────────────────
    // Controlled by IRKit-UI configuration. Shows a yellow bounding box on the
    // camera preview where the model detected an object.
    @Volatile var showBoundingBoxOverlay: Boolean = false

    // ── Inference throttle ───────────────────────────────────────────────────
    // Minimum milliseconds between ONNX inference runs. Frames arriving faster
    // than this reuse the previous bounding box. Self-tuning adjusts this based
    // on device speed. Mirrors iOS Constants.segmentationInferenceInterval (0.3s).
    @Volatile var inferenceIntervalMs: Long = 300L

    // ── Stale bbox reuse ─────────────────────────────────────────────────────
    // If the current frame produces no bbox, reuse the previous one as long as
    // it is newer than this. Mirrors iOS Constants.segmentationMaxStaleBoundingBoxAge (1.0s).
    @Volatile var maxStaleBboxAgeMs: Long = 1_000L

    // ── Gaze point ───────────────────────────────────────────────────────────
    // Normalized 0–1; default = image center.
    // Mirrors iOS Constants.segmentationInitialGazeX/Y.
    @Volatile var gazeX: Float = 0.5f
    @Volatile var gazeY: Float = 0.5f

    // ── Debug frame saving ──────────────────────────────────────────────────
    // When true, the exact JPEG sent to the server is saved to device storage.
    // Debug builds only — toggled from IRKit Playground.
    @Volatile var saveDebugFrames: Boolean = false

    // ── Postprocess thresholds — MUST match iOS exactly ──────────────────────
    //
    // IMPORTANT: These 3 values ONLY affect the bounding box RectF computed by
    // SegmentationProcessor.postprocessMask(). That box is the crop rectangle
    // sent to the backend for image recognition.
    //
    // They do NOT change the red/green debug overlay — that overlay renders
    // the raw per-pixel model output and uses MASK_THRESHOLD independently
    // in buildMaskBitmap(). To change the overlay boundary, you would need
    // to change the model itself or its gaze inputs.

    // Confidence cutoff (0.0–1.0). Model outputs a score per pixel; pixels
    // above this value count as "object". Higher = tighter/smaller box,
    // lower = looser/larger box. Also used by buildMaskBitmap() to decide
    // red vs green pixels in the debug overlay.
    const val MASK_THRESHOLD: Float = 0.85f

    // What fraction of edge pixels to trim from each side of the histogram
    // when computing the bounding box. Removes stray noise at the margins.
    // 0.02 = trim the outermost 2% of detected pixels from each edge.
    // Only affects bounding box, not the debug overlay.
    const val TRIM_PERCENT: Double = 0.02

    // How much to expand the trimmed bounding box on each side.
    // 0.10 = add 10% padding so the crop isn't too tight around the object.
    // Only affects bounding box, not the debug overlay.
    const val PADDING_PERCENT: Double = 0.10
}
