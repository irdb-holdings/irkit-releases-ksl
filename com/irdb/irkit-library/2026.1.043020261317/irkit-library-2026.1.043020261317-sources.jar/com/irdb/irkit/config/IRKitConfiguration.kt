package com.irdb.irkit.config

/**
 * Configuration interface for IRKit library.
 * The consuming application must provide an implementation of this interface
 * to supply the necessary configuration values to the library.
 */
interface IRKitConfiguration {
    /**
     * Backend REST API base URL.
     * This must come from the client config file (not from BuildConfig).
     */
    fun getBackendUrl(): String

    /**
     * The URL to access the IREngine (not the REST API)
     */
    fun getUrlToIREngine(): String

    /**
     * The API key for the IREngine (not the REST API)
     */
    fun getAPIKeyForIREngine(): String

    /**
     * The current environment (Dev, Staging, Prod)
     */
    fun getEnvironment(): String

    /**
     * Unique installation identifier for this app instance
     */
    fun getInstallationId(): String

    /**
     * Store environment configuration received from backend
     */
    fun putEnvironment(value: String)

    /**
     * Store URL to IR Engine received from backend
     */
    fun putUrlToIREngine(value: String)

    /**
     * Store API key for IR Engine received from backend
     */
    fun putAPIKeyForIREngine(value: String)

    /**
     * Lens search string fetched from getLens
     */
    fun getLensSearchString(): String?

    /**
     * Store lens search string fetched from getLens
     */
    fun putLensSearchString(value: String?)

    /**
     * Whether IRCODE creation features are enabled
     * Default: false (disabled for security)
     */
    fun isIRCodeCreationEnabled(): Boolean = false

}
