package com.irdb.irkit

import android.util.Log
import com.google.gson.GsonBuilder
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.dto.UserDataDTO
import com.irdb.irkit.response.UserResponse

/**
 * Request body for updating device token only
 * CRITICAL: Only contains deviceToken field - backend will only update this field
 */
data class UpdateDeviceTokenRequest(
    @SerializedName("deviceToken") val deviceToken: String
)

/**
 * Update ONLY the device token for the current user
 * This is called whenever FCM token is received or refreshed
 *
 * CRITICAL: This endpoint only updates deviceToken, nothing else
 *
 * @param token The FCM device token (must not be null or empty)
 * @return Updated UserDataDTO with the new token
 */
suspend fun UserService.updateDeviceTokenOnServer(token: String): UserDataDTO {
    if (token.isEmpty()) {
        throw IllegalArgumentException("Device token cannot be empty")
    }

    val endpoint = "/User"

    val request = UpdateDeviceTokenRequest(deviceToken = token)

    val response = BackendService.request<BaseResponse<UserResponse>>(
        endpoint = endpoint,
        method = HttpMethod.PUT,
        bodyParameters = request,
        responseType = object : TypeToken<BaseResponse<UserResponse>>() {}.type
    )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to update device token: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val userDataDto = UserDataDTO.fromUserResponse(
        payload.results.user
    )

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "Device token successfully updated on server")
    }

    return userDataDto
}

