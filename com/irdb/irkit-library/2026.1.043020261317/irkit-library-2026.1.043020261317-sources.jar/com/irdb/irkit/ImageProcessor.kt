package com.irdb.irkit

import android.util.Log

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class ImageProcessor {
    private val TAG = "ImageProcessor"

    suspend fun getIrcodeIDFromImage(imageBytes: ByteArray): String? = withContext(Dispatchers.IO) {
        val extractedText = extractTextFromImage(imageBytes)
        if (extractedText.isEmpty()) return@withContext null
        return@withContext getIrcodeIDForText(extractedText, "brandweek")
    }

    private suspend fun extractTextFromImage(imageBytes: ByteArray): List<String> = withContext(Dispatchers.IO) {
        val url = URL(
            "https://irdb-poc-vision.cognitiveservices.azure.com/computervision/imageanalysis:analyze?features=caption%2Cread&model-version=latest&language=en&api-version=2024-02-01"
        )

        // Log endpoint for development debugging only
        if (BackendService.isDebugMode()) {
            Log.d("EndPoint", "url: $url")
        }

        var connection: HttpURLConnection? = null
        try {
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/octet-stream")
            connection.setRequestProperty("Ocp-Apim-Subscription-Key", "e188f9aceca14ca7a3954ec25581c396")
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            connection.outputStream.use { outputStream ->
                outputStream.write(imageBytes)
                outputStream.flush()
            }

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                return@withContext parseExtractedText(response)
            } else {
                Log.e(TAG, "HTTP error code: $responseCode")
                return@withContext emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in extractTextFromImage: ${e.message}", e)
            return@withContext emptyList()
        } finally {
            connection?.disconnect()
        }
    }

    private fun parseExtractedText(jsonResponse: String): List<String> {
        val extractedText = mutableListOf<String>()
        try {
            val jsonObject = JSONObject(jsonResponse)
            val readResult = jsonObject.optJSONObject("readResult")
            readResult?.optJSONArray("blocks")?.let { blocks ->
                for (i in 0 until blocks.length()) {
                    val block = blocks.getJSONObject(i)
                    block.optJSONArray("lines")?.let { lines ->
                        for (j in 0 until lines.length()) {
                            val line = lines.getJSONObject(j)
                            extractedText.add(line.optString("text", ""))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing JSON response: ${e.message}", e)
        }
        return extractedText
    }

    private suspend fun getIrcodeIDForText(queries: List<String>, index: String): String? = withContext(Dispatchers.IO) {
        val url = URL("https://irdb-poc-search.search.windows.net/indexes/$index/docs/search?api-version=2024-07-01")

        // Log endpoint for development debugging only
        if (BackendService.isDebugMode()) {
            Log.d("EndPoint", "url: $url")
        }

        var connection: HttpURLConnection? = null
        try {
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("api-key", "vp1WzWzDLqLTOAJ9TRVUUDnupo9nOuLc4Re0yZ5ZrQAzSeAAQ9Ix")
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            val searchWords = queries.flatMap { it.split("\\s+".toRegex()) }.filter { it.isNotEmpty() }
            val searchQuery = searchWords.joinToString(" ")

            val requestBody = JSONObject().apply {
                put("search", searchQuery)
                put("searchFields", "firstName,lastName")
                put("queryType", "full")
                put("searchMode", "any")
                put("select", "ircodeID")
                put("orderby", "search.score() desc")
                put("top", 1)
            }

            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(requestBody.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val response = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
                return@withContext parseIrcodeID(response)
            } else {
                Log.e(TAG, "HTTP error code: $responseCode")
                return@withContext null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getIrcodeIDForText: ${e.message}", e)
            return@withContext null
        } finally {
            connection?.disconnect()
        }
    }

    private fun parseIrcodeID(jsonResponse: String): String? {
        try {
            val jsonObject = JSONObject(jsonResponse)
            val valueArray = jsonObject.optJSONArray("value")
            if (valueArray != null && valueArray.length() > 0) {
                val firstResult = valueArray.getJSONObject(0)
                return firstResult.optString("ircodeID")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing JSON response for ircodeID: ${e.message}", e)
        }
        return null
    }
}
