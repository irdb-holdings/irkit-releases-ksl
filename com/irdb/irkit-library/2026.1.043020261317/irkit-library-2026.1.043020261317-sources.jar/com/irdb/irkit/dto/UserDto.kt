package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

data class UserDto(
    @SerializedName("email")
    val email: String = "",

    @SerializedName("phone")
    val phone: String = "",

    @SerializedName("userID")
    val userId: Int = 0,

    @SerializedName("fullName")
    val fullName: String = "",

    @SerializedName("userName")
    val userName: String = "",

    @SerializedName("profileUrl")
    val profileUrl: String? = null,

    // New fields for creator mode
    @SerializedName("userType")
    val userType: String = "Anonymous",

    @SerializedName("emailVerified")
    val emailVerified: Boolean = false,

    @SerializedName("phoneVerified")
    val phoneVerified: Boolean = false,

    @SerializedName("privateAccount")
    val privateAccount: Int = 0,

    @SerializedName("totalImagesCount")
    val totalImagesCount: Int = 0,

    @SerializedName("totalHistoryCount")
    val totalHistoryCount: Int = 0,

    @SerializedName("totalSavedCount")
    val totalSavedCount: Int = 0,

    @SerializedName("totalArchivedCount")
    val totalArchivedCount: Int = 0
)
