package com.irdb.irkit.enums

enum class CardTypes {
    General,
    ArtCard,
    Contact,
    ProductCard;

    val description: String
        get() = when (this) {
            General -> "General"
            ArtCard -> "Art card"
            Contact -> "Contact"
            ProductCard -> "Products"
        }

    val metaName: String
        get() = when (this) {
            General -> "general"
            ArtCard -> "artcard"
            Contact -> "contact"
            ProductCard -> "products"
        }
}