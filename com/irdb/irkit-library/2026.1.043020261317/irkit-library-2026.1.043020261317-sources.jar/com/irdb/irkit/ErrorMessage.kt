package com.irdb.irkit

import com.google.gson.annotations.SerializedName

data class ErrorMessage(
    @SerializedName("error")
    val error: String? = null,
    
    @SerializedName("msg")
    val msg: String? = null,
    
    @SerializedName("code")
    val code: String? = null
) {
    /**
     * Returns the error message as a JSON string if both msg and code are present,
     * otherwise returns the individual fields or empty string.
     * This format allows ErrorCodeTranslator to properly extract and translate the error.
     */
    fun getErrorMessage(): String {
        // If we have both msg and code, return as JSON for proper parsing
        if (!msg.isNullOrEmpty() && !code.isNullOrEmpty()) {
            return """{"msg":"$msg","code":"$code"}"""
        }
        
        // Fall back to individual fields
        return code ?: msg ?: error ?: ""
    }
}
