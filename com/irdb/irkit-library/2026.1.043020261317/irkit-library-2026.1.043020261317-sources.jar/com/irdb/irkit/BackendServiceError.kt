package com.irdb.irkit

sealed class BackendServiceError : Exception() {
    object InvalidURL : BackendServiceError()
    object InvalidResponse : BackendServiceError()
    object ParseError : BackendServiceError()
    object AccessDenied : BackendServiceError()
    object ImageNotFound : BackendServiceError()
    data class ServerError(override val message: String?) : BackendServiceError()

    override val message: String?
        get() = when (this) {
            is InvalidURL -> "Invalid URL provided"
            is InvalidResponse -> "Invalid response received from server"
            is ParseError -> "Failed to parse server response"
            is AccessDenied -> "Access denied. Please check your authentication"
            is ImageNotFound -> "Image not found"
            is ServerError -> message ?: "Unknown server error"
        }
}
