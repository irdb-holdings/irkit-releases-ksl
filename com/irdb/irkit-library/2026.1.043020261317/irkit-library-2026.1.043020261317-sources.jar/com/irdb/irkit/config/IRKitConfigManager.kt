package com.irdb.irkit.config

/**
 * Manager for IRKit configuration.
 * The consuming application must set the configuration before using the library.
 */
object IRKitConfigManager {
    private var configuration: IRKitConfiguration? = null

    /**
     * Set the configuration implementation from the consuming application
     */
    fun setConfiguration(config: IRKitConfiguration) {
        configuration = config
    }

    /**
     * Get the current configuration instance
     * @throws IllegalStateException if configuration hasn't been set
     */
    fun getConfiguration(): IRKitConfiguration {
        return configuration ?: throw IllegalStateException(
            "IRKit configuration not set. This usually means IRKit-UI library is not included " +
            "in your project dependencies. Make sure you have added IRKit-UI library, or manually " +
            "call IRKitConfigManager.setConfiguration() if using irkit-library standalone."
        )
    }

    /**
     * Check if configuration has been set
     */
    fun isConfigured(): Boolean = configuration != null
}