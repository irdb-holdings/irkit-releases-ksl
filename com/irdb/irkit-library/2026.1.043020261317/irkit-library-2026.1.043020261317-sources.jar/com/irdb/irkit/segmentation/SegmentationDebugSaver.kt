package com.irdb.irkit.segmentation

import android.content.Context
import android.util.Log
import com.irdb.irkit.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Saves the exact JPEG sent to the server to device storage for offline evaluation.
 *
 * Files are written to the app's private external directory (no permissions required):
 *   /sdcard/Android/data/<package>/files/segmentation_debug/session_<timestamp>/
 *
 * Debug builds only — guarded by [BuildConfig.DEBUG] and [SegmentationConfig.saveDebugFrames].
 */
object SegmentationDebugSaver {

    private const val TAG = "SegDebugSaver"
    private const val SAVE_THROTTLE_MS = 1_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var sessionDir: File? = null
    private var frameCounter = 0
    private var lastSaveTime = 0L

    fun startSession(context: Context) {
        if (!BuildConfig.DEBUG) return

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val baseDir = context.getExternalFilesDir("segmentation_debug") ?: return
        sessionDir = File(baseDir, "session_$timestamp").also { it.mkdirs() }
        frameCounter = 0
        lastSaveTime = 0L
        Log.d(TAG, "Session started: ${sessionDir?.absolutePath}")
    }

    fun saveFrame(imageData: ByteArray) {
        if (!BuildConfig.DEBUG) return
        val dir = sessionDir ?: return

        val now = System.currentTimeMillis()
        if (now - lastSaveTime < SAVE_THROTTLE_MS) return
        lastSaveTime = now

        val index = ++frameCounter
        scope.launch {
            try {
                val file = File(dir, "frame_%03d.jpg".format(index))
                file.writeBytes(imageData)
                Log.d(TAG, "Saved frame $index (${imageData.size / 1024}KB)")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to save frame $index: ${e.message}")
            }
        }
    }

    fun endSession() {
        if (!BuildConfig.DEBUG) return
        Log.d(TAG, "Session ended: $frameCounter frames saved to ${sessionDir?.absolutePath}")
        sessionDir = null
        frameCounter = 0
    }
}
