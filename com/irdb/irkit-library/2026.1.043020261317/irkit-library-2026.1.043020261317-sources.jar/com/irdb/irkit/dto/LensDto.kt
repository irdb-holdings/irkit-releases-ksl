package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

data class LensDto(
    @SerializedName("lensID")
    val lensId: Int? = null,

    @SerializedName("sdkID")
    val sdkId: Int? = null,

    @SerializedName("apikey")
    val apiKey: String? = null,

    @SerializedName("lensOwnerID")
    val lensOwnerId: Int? = null,

    @SerializedName("primaryCollection")
    val primaryCollection: String? = null,

    @SerializedName("originID")
    val originId: String? = null,

    @SerializedName("lensSearchList")
    val lensSearchList: List<Map<String, String?>>? = null,

    @SerializedName("characteristics")
    val characteristics: Map<String, Any?>? = null,

    @SerializedName("lensSearchString")
    val lensSearchString: String? = null
)
