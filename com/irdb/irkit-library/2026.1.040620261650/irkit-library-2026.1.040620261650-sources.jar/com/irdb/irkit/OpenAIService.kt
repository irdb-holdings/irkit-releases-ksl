package com.irdb.irkit

import android.util.Base64
import android.util.Log

import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class OpenAIService {
    companion object {
        private const val TAG = "OpenAIService"
        private const val BASE_URL = "https://api.openai.com/v1/chat/completions"
        private const val API_KEY = "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"
    }

    sealed class OpenAIResult {
        data class Success(
            val content: String,
            val isSuccess: Boolean
        ) : OpenAIResult()
        data class Error(val message: String) : OpenAIResult()
    }

    suspend fun analyzeImage(imageData: ByteArray): OpenAIResult = withContext(Dispatchers.IO) {
        try {
            val url = URL(BASE_URL)

            // Log endpoint for development debugging only
            if (BackendService.isDebugMode()) {
                Log.d("EndPoint", "url: $url")
            }

            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Authorization", "Bearer $API_KEY")
                setRequestProperty("Content-Type", "application/json")
                connectTimeout = 30000 // 30 seconds
                readTimeout = 30000 // 30 seconds
            }

            val requestBody = createRequestBody(imageData)

            try {
                OutputStreamWriter(connection.outputStream).use { writer ->
                    writer.write(requestBody.toString())
                    writer.flush()
                }

                return@withContext when (connection.responseCode) {
                    HttpURLConnection.HTTP_OK -> {
                        val response = connection.inputStream.bufferedReader().use { it.readText() }
                        parseResponse(response)
                    }
                    else -> {
                        val errorStream = connection.errorStream?.bufferedReader()?.use { it.readText() }
                        Log.e(TAG, "Error response: $errorStream")
                        OpenAIResult.Error("Error: ${connection.responseCode} - ${connection.responseMessage}")
                    }
                }
            } finally {
                connection.disconnect()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error analyzing image with GPT-4: ${e.message}")
            OpenAIResult.Error("Error: ${e.message}")
        }
    }

    private fun createRequestBody(imageData: ByteArray): JSONObject {
        // Convert image data to base64
        val base64Image = Base64.encodeToString(imageData, Base64.NO_WRAP)
        val base64Url = "data:image/jpeg;base64,$base64Image"

        val messageContent = JSONArray().apply {
            put(
                JSONObject().apply {
                    put("type", "text")
                    put(
                        "text",
                        "What is in this image? Respond in the JSON format with the message in a variable called content and a boolean variable called success to indicate whether you were able to recognize what is in this image."
                    )
                }
            )
            put(
                JSONObject().apply {
                    put("type", "image_url")
                    put(
                        "image_url",
                        JSONObject().apply {
                            put("url", base64Url)
                        }
                    )
                }
            )
        }

        val messages = JSONArray().apply {
            put(
                JSONObject().apply {
                    put("role", "user")
                    put("content", messageContent)
                }
            )
        }

        return JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", messages)
            put("max_tokens", 150)
            put("temperature", 0.7)
        }
    }

    private fun parseResponse(response: String): OpenAIResult {
        return try {
            val jsonResponse = JSONObject(response)
            val messageContent = jsonResponse
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")

            // Extract the JSON content from the markdown code block
            val jsonContentMatch = """```json\s*(\{.*?\})\s*```""".toRegex(RegexOption.DOT_MATCHES_ALL)
                .find(messageContent)
                ?.groupValues
                ?.get(1)
                ?: throw Exception("Could not extract JSON from response")

            // Parse the extracted JSON
            val contentJson = JSONObject(jsonContentMatch)
            val content = contentJson.getString("content")
            val success = contentJson.getBoolean("success")

            if (content.isNotBlank()) {
                OpenAIResult.Success(content = content, isSuccess = success)
            } else {
                OpenAIResult.Error("Empty response content")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing response: ${e.message}")
            OpenAIResult.Error("Failed to parse AI response")
        }
    }
}
