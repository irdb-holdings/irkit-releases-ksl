package com.irdb.irkit

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlin.jvm.Throws
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import com.irdb.irkit.ImageRecognitionObserver
import com.irdb.irkit.utils.ImageLifecycleTracker
// SecurityUtils moved to consuming application

/**
 * Main entry point for the IRKit Library.
 *
 * This class provides a centralized way to initialize and access all IRKit functionality
 * including backend services, image recognition, and data management.
 *
 * Usage:
 * ```kotlin
 * // Initialize in your Application class
 * IRKit.initialize(
 *     context = this,
 *     configuration = MyIRKitConfiguration()
 * )
 *
 * // Access services
 * val backendService = IRKit.getInstance().getBackendService()
 * val irEngine = IRKit.getInstance().getIREngine()
 * ```
 */
class IRKit private constructor(
    private val context: Context,
    private val configuration: IRKitConfiguration
) {
    // Application-scoped coroutine scope for background operations
    // Uses SupervisorJob to ensure one failure doesn't cancel other operations
    private val applicationScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        @Volatile
        private var INSTANCE: IRKit? = null

        /**
         * Initialize the IRKit library. This should be called once in your Application.onCreate()
         *
         * Required runtime permissions (camera, location, gallery) must be granted before calling
         * this method when [IRKitConfiguration.enforceRequiredPermissionsAtInit] is true. If any
         * are missing, [IRKitMissingPermissionsException] is thrown with the list of missing
         * permissions. The host app must declare INTERNET and ACCESS_NETWORK_STATE in its
         * manifest; no runtime check is performed for those.
         *
         * Note: Analytics tracking is handled internally by the library using AnalyticsClient.
         * If AnalyticsClient is initialized by your app, the library will automatically use it.
         * Client apps do not need to provide analytics implementations.
         *
         * Environment information is automatically fetched from the backend in the background.
         * This populates IR Engine URL and API key, which are required for image recognition.
         * The fetch is non-blocking and will not delay app startup.
         *
         * @throws IRKitMissingPermissionsException when [IRKitConfiguration.enforceRequiredPermissionsAtInit]
         *   is true and one or more of CAMERA, location (ACCESS_FINE_LOCATION or ACCESS_COARSE_LOCATION),
         *   or READ_MEDIA_IMAGES are not granted
         */
        @Throws(IRKitMissingPermissionsException::class)
        fun initialize(
            context: Context,
            configuration: IRKitConfiguration
        ): IRKit {
            val appContext = context.applicationContext
            if (configuration.enforceRequiredPermissionsAtInit()) {
                val missing = getMissingRequiredPermissions(appContext)
                if (missing.isNotEmpty()) {
                    throw IRKitMissingPermissionsException(missing)
                }
            }
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: IRKit(appContext, configuration).also { instance ->
                    // Initialize internal services
                    BackendService.setConfiguration(configuration)
                    ImageLifecycleTracker.setConfiguration(configuration)
                    // Security configuration is now handled by the consuming application

                    // Initialize IRKitUI (and analytics) if available
                    // IRKitUI handles all analytics config - we just trigger it
                    initializeIRKitUIIfAvailable(appContext)

                    // Automatically fetch environment information in background
                    // This populates IR Engine URL and API key from backend
                    // Non-blocking: runs in background and won't delay app startup
                    instance.applicationScope.launch {
                        try {
                            Log.d("LogEnv", "Starting environment information fetch...")
                            BackendService.getEnvironmentInformationAndStoreInPrefs()
                            Log.d("LogEnv", "Environment information fetched successfully")
                            if (configuration.isDebugMode()) {
                                Log.d("IRKit", "Environment information fetched successfully")
                            }
                        } catch (e: Exception) {
                            Log.e(
                                "LogEnv",
                                "Failed to fetch environment information: ${e.message}",
                                e
                            )
                            Log.e(
                                "IRKit",
                                "Failed to fetch environment information: ${e.message}",
                                e
                            )
                            // Don't throw - allow app to continue, but environment info won't be available
                            // IREngine will need to handle missing environment info gracefully
                            // Client apps can manually retry by calling getEnvironmentInformation() if needed
                        }
                    }

                    INSTANCE = instance
                }
            }
        }

        /**
         * Initialize the IRKit library with zero configuration required.
         *
         * This method automatically initializes IRKit-UI (which sets up all configuration
         * internally based on the selected client) if it's available and configuration
         * hasn't been set yet.
         *
         * @param context Application context
         * @throws IRKitMissingPermissionsException when enforceRequiredPermissionsAtInit is true
         *   and required permissions are not granted
         */
        @Throws(IRKitMissingPermissionsException::class)
        fun initialize(context: Context): IRKit {
            val appContext = context.applicationContext

            // If configuration not set, initialize IRKit-UI first to auto-configure
            if (!com.irdb.irkit.config.IRKitConfigManager.isConfigured()) {
                Log.d("IRKit", "Configuration not set - initializing IRKit-UI to auto-configure")
                initializeIRKitUIIfAvailable(appContext)
            }

            // Get configuration (should be set by IRKit-UI now, or throw if IRKit-UI not available)
            val config = com.irdb.irkit.config.IRKitConfigManager.getConfiguration()

            // Log configuration values for debugging
            Log.d("IRKit", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            Log.d("IRKit", "Configuration values from IRKitConfigManager:")
            Log.d("IRKit", "  → Environment: ${config.getEnvironment()}")
            Log.d("IRKit", "  → Backend URL: ${config.getBackendUrl()}")
            Log.d("IRKit", "  → IR Engine URL: ${config.getUrlToIREngine()}")
            Log.d("IRKit", "  → API Key for IR Engine: ${if (config.getAPIKeyForIREngine().isNotEmpty()) "[PRESENT]" else "[MISSING]"}")
            Log.d("IRKit", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

            // Capture the original subscription key BEFORE getEnvironmentInformationAndStoreInPrefs
            // can overwrite it. The REST API sdkapikey header must always use the original config key,
            // while the IR Engine API key can be updated from the backend.
            val originalSubscriptionKey = config.getAPIKeyForIREngine()

            // Create an IRKitConfiguration adapter that bridges config.IRKitConfiguration to IRKitConfiguration
            val irkitConfiguration = object : IRKitConfiguration {
                override fun getBackendUrl(): String {
                    val configuredUrl = config.getBackendUrl().trim()
                    if (configuredUrl.isNotEmpty()) {
                        return configuredUrl
                    }

                    Log.w(
                        "IRKit",
                        "Config backendUrl was blank; falling back to environment mapping."
                    )
                    return when (config.getEnvironment().lowercase()) {
                        "production" -> "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
                        "staging" -> "https://us-central1-ircode-1a662.cloudfunctions.net/staging-v1_44"
                        else -> "https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_44"
                    }
                }
                override fun getIREngineUrl(): String = config.getUrlToIREngine()
                override fun getAPIKey(): String = config.getAPIKeyForIREngine()
                override fun isDebugMode(): Boolean = config.getEnvironment().lowercase() == "development"
                override fun isImageLifecycleLoggingEnabled(): Boolean = false
                override fun getSubscriptionKey(): String = originalSubscriptionKey
                override fun getEnvironment(): String = config.getEnvironment()
                override fun getPreferencesEncryptionKey(): String = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
                override fun getPreferencesEncryptionSalt(): String = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
            }

            return initialize(context, irkitConfiguration)
        }

        /**
         * Get the initialized IRKit instance
         * @throws IllegalStateException if IRKit has not been initialized
         */
        fun getInstance(): IRKit {
            return INSTANCE ?: throw IllegalStateException(
                "IRKit has not been initialized. Call IRKit.initialize() first."
            )
        }

        /**
         * Check if IRKit has been initialized
         */
        fun isInitialized(): Boolean = INSTANCE != null

        private fun getMissingRequiredPermissions(context: Context): List<String> {
            val missing = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.CAMERA)
            }
            val fineLocation = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarseLocation = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fineLocation && !coarseLocation) {
                missing.add(Manifest.permission.ACCESS_FINE_LOCATION)
                missing.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
            val galleryPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Manifest.permission.READ_MEDIA_IMAGES
            } else {
                Manifest.permission.READ_EXTERNAL_STORAGE
            }
            if (ContextCompat.checkSelfPermission(context, galleryPermission) != PackageManager.PERMISSION_GRANTED) {
                missing.add(galleryPermission)
            }
            return missing
        }

        // ==================== INTERNAL CALLBACKS ====================
        // These are internal-only callbacks for the official IRKit app.
        // Not part of the public API and not documented for clients.
        
        /**
         * Internal callback for save/bookmark action.
         * Only used by official IRKit app (com.irdb.irkitdemo).
         */
        @JvmStatic
        internal var onSaveImageCallback: ((ImageModel) -> Unit)? = null
            private set

        /**
         * Internal callback for share action.
         * Only used by official IRKit app (com.irdb.irkitdemo).
         */
        @JvmStatic
        internal var onShareImageCallback: ((ImageModel) -> Unit)? = null
            private set

        /**
         * Internal method to register action button callbacks.
         * Only called by official IRKit app (com.irdb.irkitdemo).
         * Not part of the public API.
         */
        @JvmStatic
        fun registerActionCallbacks(
            onSave: (ImageModel) -> Unit,
            onShare: (ImageModel) -> Unit
        ) {
            onSaveImageCallback = onSave
            onShareImageCallback = onShare
        }
        
        /**
         * Internal accessor for save callback.
         * Used by IRKit-UI library to invoke the callback.
         * Not part of the public API documentation.
         */
        @JvmStatic
        fun invokeSaveCallback(image: ImageModel) {
            onSaveImageCallback?.invoke(image)
        }
        
        /**
         * Internal accessor for share callback.
         * Used by IRKit-UI library to invoke the callback.
         * Not part of the public API documentation.
         */
        @JvmStatic
        fun invokeShareCallback(image: ImageModel) {
            onShareImageCallback?.invoke(image)
        }
        
        /**
         * Initialize IRKitUI if available on the classpath.
         * IRKitUI handles all analytics configuration based on the selected client.
         * Uses reflection so irkit-library doesn't have a compile-time dependency on IRKit-UI.
         */
        private fun initializeIRKitUIIfAvailable(context: Context) {
            Log.d("IRKit", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            Log.d("IRKit", "initializeIRKitUIIfAvailable called")

            // Check if analytics is already initialized (should NOT be at this point)
            try {
                com.irdb.analytics.AnalyticsClient.getInstance()
                Log.w("IRKit", "⚠️ Analytics was ALREADY initialized BEFORE IRKitUI!")
                Log.w("IRKit", "   This is unexpected - something initialized it early!")
            } catch (e: IllegalStateException) {
                Log.d("IRKit", "✅ Analytics not yet initialized (correct)")
            }

            try {
                val irkitUIClass = Class.forName("com.irdb.irkitui.IRKitUI")
                Log.d("IRKit", "Found IRKitUI class, calling initialize...")
                // IRKitUI is a Kotlin object, get INSTANCE field
                val instanceField = irkitUIClass.getField("INSTANCE")
                val instance = instanceField.get(null)
                val initMethod = irkitUIClass.getMethod("initialize", Context::class.java)
                initMethod.invoke(instance, context)
                Log.d("IRKit", "✅ IRKitUI.initialize() completed successfully")

                // Verify analytics is now initialized with correct config
                try {
                    val analyticsClient = com.irdb.analytics.AnalyticsClient.getInstance()
                    Log.d("IRKit", "✅ Analytics now initialized after IRKitUI.initialize()")
                } catch (e: IllegalStateException) {
                    Log.e("IRKit", "❌ Analytics NOT initialized after IRKitUI - this is a bug!")
                }
            } catch (e: ClassNotFoundException) {
                Log.d("IRKit", "IRKitUI not available - analytics not initialized")
            } catch (e: Exception) {
                Log.e("IRKit", "Failed to initialize IRKitUI: ${e.message}", e)
            }
            Log.d("IRKit", "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        }

        /**
         * Auto-initialize analytics for session tracking.
         * NOTE: This is no longer called - IRKitUI handles analytics initialization.
         * Kept for reference/fallback.
         */
        private fun initializeAnalyticsInternal(context: Context, configuration: IRKitConfiguration) {
            try {
                // Check if already initialized
                try {
                    com.irdb.analytics.AnalyticsClient.getInstance()
                    Log.d("IRKit", "Analytics already initialized")
                    return
                } catch (e: IllegalStateException) {
                    // Not initialized yet - proceed with initialization
                }
                
                // Get backend URL and API key from configuration
                val backendUrl = configuration.getBackendUrl()
                val apiKey = configuration.getAPIKey()
                val analyticsEndpoint = "$backendUrl/Statistics"
                
                // Determine if this is a debug build
                val isDebugBuild = configuration.isDebugMode()
                
                // Auto-detect companyName and bucketName from package
                // NOTE: This function is no longer called - analytics is initialized by IRKitUI
                val packageName = context.packageName
                val (companyName, bucketName) = when {
                    packageName.contains("ksldemo") -> "ksl" to "ksldemo"
                    packageName.contains("irkitdemo") || packageName.contains("ircode") -> "irdb" to "irdbMain"
                    else -> packageName.substringAfterLast('.') to "irdbMain"
                }

                // Initialize analytics with sensible defaults
                val analyticsConfig = com.irdb.analytics.createAnalyticsConfig(
                    apiEndpoint = analyticsEndpoint,
                    apiKey = apiKey,
                    companyName = companyName,
                    bucketName = bucketName,
                    isDebugBuild = isDebugBuild
                )
                
                com.irdb.analytics.AnalyticsClient.initialize(context, analyticsConfig)
                Log.d("IRKit", "Analytics auto-initialized successfully")
            } catch (e: Exception) {
                Log.e("IRKit", "Failed to auto-initialize analytics: ${e.message}", e)
                // Don't throw - allow IRKit to continue without analytics
            }
        }
    }

    // ==================== PUBLIC API METHODS ====================

    /**
     * Get the image recognition observer for monitoring scan results
     */
    fun getImageRecognitionObserver(): IRKitImageRecognitionObserver {
        return IRKitImageRecognitionObserver()
    }

    /**
     * Start IR engine with context
     */
    fun startIREngine(context: Context) {
        val irEngine = IREngine(context)
        irEngine.setConfiguration(configuration)
    }

    // ==================== BACKEND API ====================

    /**
     * Get environment information and store in preferences
     */
    suspend fun getEnvironmentInformation() {
        return BackendService.getEnvironmentInformationAndStoreInPrefs()
    }

    /**
     * Create an IR Code
     */
    suspend fun createIRCode(imageUrl: String) = BackendService.CreateIRCode(imageUrl)

    /**
     * Get image metadata
     */
    suspend fun getImageMeta(
        imageId: String,
        userid: Int,
        editableImage: com.irdb.irkit.dto.EditableImageDto,
        localTest: Boolean = false
    ): Boolean {
        return BackendService.ImageMeta(imageId, userid, editableImage, localTest)
    }

    /**
     * Process raw image for recognition
     */
    suspend fun processRawImage(bitmap: Bitmap) = BackendService.Raw(bitmap)

    /**
     * Get similar images
     */
    suspend fun getSimilarImages(imageId: String) = BackendService.similar(imageID = imageId)

    /**
     * Get products for a campaign
     */
    suspend fun getProducts(campaignId: Int) = BackendService.getProducts(campaignId)

    /**
     * Add image to saved collection
     */
    suspend fun addImageToSaved(
        imageId: String,
        displayImageUrl: String,
        fbToken: String
    ): Boolean {
        return BackendService.addImageToSaved(imageId, displayImageUrl, fbToken)
    }

    /**
     * Remove image from saved collection
     */
    suspend fun removeImageFromSaved(
        imageId: String,
        displayImageUrl: String,
        fbToken: String
    ): Boolean {
        return BackendService.removeImageToSaved(imageId, displayImageUrl, fbToken)
    }

    /**
     * Get/Set Firebase token
     */
    var firebaseToken: String?
        get() = BackendService.firebaseToken
        set(value) { BackendService.firebaseToken = value }

    /**
     * Get the configuration used to initialize IRKit
     */
    fun getConfiguration(): IRKitConfiguration = configuration

    /**
     * Get the application context
     */
    fun getContext(): Context = context
}

/**
 * Configuration interface that must be implemented by the consuming application
 * to provide environment-specific settings.
 */
interface IRKitConfiguration {
    /**
     * Backend API base URL
     */
    fun getBackendUrl(): String

    /**
     * IR Engine API URL for image recognition
     */
    fun getIREngineUrl(): String

    /**
     * API key for IR Engine (same as subscription key)
     */
    fun getAPIKey(): String

    /**
     * Whether the app is in debug mode
     */
    fun isDebugMode(): Boolean

    /**
     * Whether ImageLifecycle logging is enabled
     * This is separate from general debug mode to allow fine-grained control
     */
    fun isImageLifecycleLoggingEnabled(): Boolean

    /**
     * Subscription key for IRKit services
     */
    fun getSubscriptionKey(): String

    /**
     * Environment name (e.g., "development", "staging", "production")
     */
    fun getEnvironment(): String

    /**
     * Encryption key for secure preferences storage
     */
    fun getPreferencesEncryptionKey(): String

        /**
         * Salt for preferences encryption
         */
        fun getPreferencesEncryptionSalt(): String

    /**
     * When true, [IRKit.initialize] checks that required runtime permissions (camera, location,
     * gallery) are granted and throws [IRKitMissingPermissionsException] if any are missing.
     * Default: false for backward compatibility. Set to true to enforce permissions at init.
     */
    fun enforceRequiredPermissionsAtInit(): Boolean = false
}

/**
 * Public wrapper for ImageRecognitionObserver to hide internal implementation
 */
class IRKitImageRecognitionObserver {
    private val observer = ImageRecognitionObserver.getInstance()

    /**
     * Observable last seen image
     */
    val lastSeenImage: StateFlow<ImageModel?> = observer.lastSeenImage

    /**
     * Observable loading state
     */
    val isLoadingDetails: StateFlow<Boolean> = observer.isLoadingDetails

    /**
     * Set content expanded state
     */
    fun setContentExpanded(expanded: Boolean) {
        observer.setContentExpanded(expanded)
    }

    /**
     * Clear the last seen image
     */
    fun clearLastSeenImage() {
        observer.clearLastSeenImage()
    }

    /**
     * Handle image seen event
     */
    fun handleImageSeen(imageId: String, trackingId: String, bucketName: String) {
        observer.handleImageSeen(imageId, trackingId, bucketName)
    }

    /**
     * Handle image recognized event
     */
    fun handleImageRecognized(imageSearchResult: ImageSearchResult) {
        observer.handleImageRecognized(imageSearchResult)
    }

    /**
     * Handle image not recognized event
     */
    fun handleImageNotRecognized(imageSearchResult: ImageSearchResult) {
        observer.handleImageNotRecognized(imageSearchResult)
    }
}
