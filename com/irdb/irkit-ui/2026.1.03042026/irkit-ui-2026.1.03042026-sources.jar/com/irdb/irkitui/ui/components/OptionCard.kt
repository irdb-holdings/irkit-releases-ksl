package com.irdb.irkitui.ui.components

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.R
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme

object OptionCardDimens {
    val cardCornerRadius = 24.dp
    val iconSize = 64.dp
    val iconInnerSize = 32.dp
    val chevronSize = 24.dp
    val cardPadding = 24.dp
    val textSpacing = 20.dp
    val soonTagPadding = 8.dp
    val soonTagCornerRadius = 12.dp
    val iconCornerRadius = 16.dp
}

@Composable
fun OptionCard(
    iconResId: Int,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    isEnabled: Boolean,
    showSoonTag: Boolean = false,
) {
    val colors = IRKitThemeAccessor.colors
    val typography = IRKitThemeAccessor.typography

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = isEnabled) { onClick() },
        shape = RoundedCornerShape(OptionCardDimens.cardCornerRadius),
        colors = CardDefaults.cardColors(
            containerColor = colors.surface
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(OptionCardDimens.cardPadding),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon with light gray rounded rectangle background
            Box(
                modifier = Modifier
                    .size(OptionCardDimens.iconSize)
                    .clip(RoundedCornerShape(OptionCardDimens.iconCornerRadius))
                    .background(colors.iconBackground),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(id = iconResId),
                    contentDescription = null,
                    tint = if (isEnabled) colors.textPrimary else colors.textDisabled,
                    modifier = Modifier.size(OptionCardDimens.iconInnerSize)
                )
            }

            // Text content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = OptionCardDimens.textSpacing)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = typography.titleMedium,
                        color = if (isEnabled) colors.textPrimary else colors.textDisabled
                    )

                    if (showSoonTag) {
                        Spacer(modifier = Modifier.padding(start = 8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(OptionCardDimens.soonTagCornerRadius))
                                .background(colors.tagBackground)
                                .padding(
                                    horizontal = OptionCardDimens.soonTagPadding,
                                    vertical = 1.dp
                                )
                        ) {
                            Text(
                                text = "Soon",
                                style = typography.labelMedium,
                                color = colors.tagText
                            )
                        }
                    }
                }

                Text(
                    text = subtitle,
                    style = typography.bodyMedium,
                    color = if (isEnabled) colors.textSecondary else colors.cardBackground,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Arrow icon
            Icon(
                painter = painterResource(id = R.drawable.baseline_chevron_right_24),
                contentDescription = null,
                tint = if (isEnabled) colors.textSecondary else colors.cardBackground,
                modifier = Modifier.size(OptionCardDimens.chevronSize)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewOptionCard() {
    IRKitUITheme {
        Surface {
            OptionCard(
                iconResId = R.drawable.baseline_camera_alt_24,
                title = "Take Photo",
                subtitle = "Capture a new IRCODE with your camera",
                onClick = {},
                isEnabled = true
            )
        }
    }
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun PreviewOptionCardDark() {
    IRKitUITheme(darkTheme = true) {
        Surface {
            OptionCard(
                iconResId = R.drawable.baseline_camera_alt_24,
                title = "Take Photo",
                subtitle = "Capture a new IRCODE with your camera",
                onClick = {},
                isEnabled = true
            )
        }
    }
}
