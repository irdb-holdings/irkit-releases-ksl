package com.irdb.irkitui.ui.dialogs.ircode

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkitui.ui.baseComponents.FormLabel
import com.irdb.irkitui.ui.baseComponents.ShadowButton
import com.irdb.irkitui.theme.ACTION_BUTTON_COLOR
import com.irdb.irkitui.theme.IRKitUITheme

object AddCustomFieldDialogDimens {
    val horizontalPadding = 16.dp
    val verticalPadding = 16.dp
    val titleBottomSpacing = 16.dp
    val fieldBottomSpacing = 24.dp
    val actionButtonVerticalPadding = 14.dp
    val actionButtonIconStartPadding = 8.dp
    val cancelTopSpacing = 16.dp
    val titleFontSize = 32.sp
    val buttonTextFontSize = 18.sp
}

@Composable
fun AddCustomFieldDialog(
    value: String,
    onValueChange: (String) -> Unit,
    onAdd: () -> Unit,
    onCancel: () -> Unit,
    titleText: String = "Add Custom Field",
    labelText: String = "Custom Field Label",
    placeholderText: String = "Enter your custom field",
    primaryButtonText: String = "Add Field",
    cancelButtonText: String = "Cancel",
    modifier: Modifier = Modifier
) {
    ComplexDialog(
        onDismiss = onCancel,
        topRoundedCorners = true,
        showTopBar = false,
        isDarkMode = true,
        topContent = {},
        middleContent = {},
        bottomContent = {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .padding(horizontal = AddCustomFieldDialogDimens.horizontalPadding)
                    .padding(bottom = AddCustomFieldDialogDimens.verticalPadding)
            ) {
                // Title
                Text(
                    text = titleText,
                    color = Color.White,
                    fontSize = AddCustomFieldDialogDimens.titleFontSize,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(bottom = AddCustomFieldDialogDimens.titleBottomSpacing)
                )

                // Label for the text field
                FormLabel(text = labelText)

                // Text input
                OutlinedTextField(
                    value = value,
                    onValueChange = { newValue -> onValueChange(newValue) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = AddCustomFieldDialogDimens.fieldBottomSpacing),
                    placeholder = {
                        Text(text = placeholderText, color = Color.Gray)
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.White,
                        unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color.White
                    )
                )

                // Add metadata button
                ShadowButton(
                    modifier = Modifier
                        .fillMaxWidth(),
                    onClick = onAdd,
                    backgroundColor = ACTION_BUTTON_COLOR
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = AddCustomFieldDialogDimens.actionButtonVerticalPadding)
                    ) {
                        Text(
                            text = primaryButtonText,
                            color = Color.White,
                            fontSize = AddCustomFieldDialogDimens.buttonTextFontSize,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.padding(start = AddCustomFieldDialogDimens.actionButtonIconStartPadding)
                        )
                    }
                }

                // Cancel section
                Spacer(modifier = Modifier.height(AddCustomFieldDialogDimens.cancelTopSpacing))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onCancel() },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = cancelButtonText,
                        tint = Color.White
                    )
                    Text(
                        text = cancelButtonText.uppercase(),
                        color = Color.White,
                        modifier = Modifier.padding(start = 8.dp),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    )
}

@Preview(showBackground = true, backgroundColor = 0xFF000000, widthDp = 393, heightDp = 852)
@Composable
fun AddCustomFieldDialogPreview() {
    IRKitUITheme(darkTheme = true) {
        var field by remember { mutableStateOf("") }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AddCustomFieldDialog(
                value = field,
                onValueChange = { field = it },
                onAdd = {},
                onCancel = {}
            )
        }
    }
}
