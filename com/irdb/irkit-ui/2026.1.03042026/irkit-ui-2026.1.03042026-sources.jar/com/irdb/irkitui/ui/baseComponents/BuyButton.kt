package com.irdb.irkitui.ui.baseComponents

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.irdb.irkit.dto.ProductInCampaignDto
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun BuyButton(
    product: ProductInCampaignDto,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val imageLoader = rememberImageLoader()
    val colors = IRKitThemeAccessor.colors
    val typography = IRKitThemeAccessor.typography

    Box(
        modifier = modifier.padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        // For now, use a generic buy button since we don't have access to ProductUtils
        // This could be enhanced to include dynamic buttons from ProductUtils if needed
        Box(
            modifier = Modifier
                .width(72.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(colors.primary)
                .clickable { onClick() }
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "BUY",
                color = colors.onPrimary,
                style = typography.bodyLarge
            )
        }
    }
}

@Preview(
    name = "Light Mode",
    showBackground = true,
    backgroundColor = 0xFFFFFFFF
)
@Preview(
    name = "Dark Mode",
    showBackground = true,
    backgroundColor = 0xFF2C2C2C
)
@Composable
fun BuyButtonPreview() {
    val mockProduct = ProductInCampaignDto(
        id = "test",
        title = "Test Product",
        imageUrl = "https://example.com/image.jpg",
        linkToFollow = "https://example.com"
    )

    IRKitUITheme {
        BuyButton(product = mockProduct)
    }
}
