package com.irdb.irkitui.ui.internal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import com.irdb.irkit.ImageModel
import com.irdb.irkitui.R
import com.irdb.irkitui.ui.baseComponents.SaveButton
import com.irdb.irkitui.ui.baseComponents.ShareButton

/**
 * INTERNAL ONLY - Action buttons shown below notification cards.
 * Only visible in official IRKit app (package name = com.irdb.irkitdemo).
 * 
 * This component is NOT part of the public API and should not be used by library clients.
 */
@Composable
internal fun NotificationActionButtons(
    image: ImageModel,
    onSaveClick: (ImageModel) -> Unit,
    onShareClick: (ImageModel) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.End
    ) {
        SaveButton(
            onSaveButtonClick = { onSaveClick(image) },
            added = image.save,
            addedIcon = ImageVector.vectorResource(id = R.drawable.outline_bookmark_added_24),
            outlineIcon = ImageVector.vectorResource(id = R.drawable.outline_bookmark_add_24)
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        ShareButton(
            image = image,
            onShare = { onShareClick(image) }
        )
    }
}
