package com.irdb.irkitui.ui.baseComponents

import android.annotation.SuppressLint
import android.content.Intent
import android.util.Log
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.net.toUri
import com.irdb.irkit.extensions.extractDomain

/**
 * A composable wrapper around Android's WebView that provides a consistent web viewing experience
 * across the app.
 *
 * @param url The URL to load in the WebView
 * @param modifier Additional modifier to be applied to the WebView
 * @param enableJavaScript Whether JavaScript should be enabled in the WebView. Defaults to true
 * @param enableDomStorage Whether DOM storage should be enabled. Defaults to true
 * @param loadWithOverviewMode Whether the WebView should enable overview mode loading. Defaults to true
 * @param useWideViewPort Whether the WebView should enable wide viewport. Defaults to true
 * @param onExternalNavigationRequest Optional callback for handling external navigation requests
 * @param onLoadingChanged Optional callback that reports when the loading state changes (true when loading starts, false when finished)
 * @param backgroundColor Background color for permission dialogs
 * @param primaryColor Primary color for permission dialog buttons
 * @param secondaryColor Secondary color for permission dialog buttons
 * @param debugLogging Whether to enable debug logging
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AppWebView(
    url: String,
    modifier: Modifier = Modifier,
    enableJavaScript: Boolean = true,
    enableDomStorage: Boolean = true,
    loadWithOverviewMode: Boolean = true,
    useWideViewPort: Boolean = true,
    onExternalNavigationRequest: ((String) -> Unit)? = null,
    onLoadingChanged: ((Boolean) -> Unit)? = null,
    backgroundColor: Color = Color.DarkGray,
    primaryColor: Color = Color.Blue,
    secondaryColor: Color = Color.Gray,
    debugLogging: Boolean = false
) {
    val context = LocalContext.current

    // State for permission dialogs
    var permissionDialogData by remember { mutableStateOf<PermissionDialogData?>(null) }

    val rootDomain = url.extractDomain()

    if (debugLogging) {
        Log.d("AppWebView", "base URL: $url")
    }

    AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.apply {
                            javaScriptEnabled = enableJavaScript
                            domStorageEnabled = enableDomStorage
                            this.loadWithOverviewMode = loadWithOverviewMode
                            this.useWideViewPort = useWideViewPort
                        }

                        webViewClient = object : WebViewClient() {
                            private var isInitialLoad = true

                            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                onLoadingChanged?.invoke(true)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                onLoadingChanged?.invoke(false)
                            }

                            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                // Allow all non-main frame requests (resources, iframes, etc.)
                                if (!request.isForMainFrame) {
                                    return false
                                }

                                // Allow initial page load and server-side redirects
                                if (isInitialLoad) {
                                    isInitialLoad = false
                                    return false
                                }

                                val requestUrl = request.url.toString()
                                val requestDomain = requestUrl.extractDomain()

                                val target = request.url.getQueryParameter("target")

                                if (debugLogging) {
                                    Log.d("AppWebView", "Loading URL: $requestUrl")
                                    Log.d("AppWebView", "Target: $target")
                                    Log.d("AppWebView", "requestDomain: $requestDomain")
                                    Log.d("AppWebView", "rootDomain   : $rootDomain")
                                }

                                // Check if this is a user-initiated navigation
                                val isUserInitiated = request.hasGesture() || request.method == "GET"

                                // Check if the link should open in a new window
                                val shouldOpenInNewWindow =
                                    target == "_blank" || target == null ||
                                        request.url.getQueryParameter("new_window") == "true" ||
                                        requestDomain != rootDomain

                                if (debugLogging) {
                                    Log.d("AppWebView", "shouldOpenInNewWindow: $shouldOpenInNewWindow")
                                    Log.d("AppWebView", "isUserInitiated: $isUserInitiated")
                                }

                                // If this is a user navigation that should open externally
                                if (isUserInitiated && shouldOpenInNewWindow) {
                                    onExternalNavigationRequest?.invoke(requestUrl) ?: run {
                                        // Default handling if no callback provided
                                        val intent = Intent(Intent.ACTION_VIEW, requestUrl.toUri())
                                        context.startActivity(intent)
                                    }
                                    return true
                                }

                                // By default, allow navigation within the WebView
                                return false
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onGeolocationPermissionsShowPrompt(
                                origin: String,
                                callback: GeolocationPermissions.Callback
                            ) {
                                permissionDialogData = PermissionDialogData(
                                    title = "Location Permission",
                                    message = "$origin wants to access your location.",
                                    onAllow = {
                                        callback.invoke(origin, true, false)
                                        permissionDialogData = null
                                    },
                                    onDeny = {
                                        callback.invoke(origin, false, false)
                                        permissionDialogData = null
                                    }
                                )
                            }

                            override fun onPermissionRequest(request: PermissionRequest) {
                                val requestedResources = request.resources
                                val permissionType = when {
                                    requestedResources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) -> "Camera"
                                    requestedResources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) -> "Microphone"
                                    requestedResources.contains(PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID) -> "Protected Media"
                                    else -> "Device Access"
                                }

                                permissionDialogData = PermissionDialogData(
                                    title = "$permissionType Permission",
                                    message = "This site wants to access your ${permissionType.lowercase()}.",
                                    onAllow = {
                                        request.grant(requestedResources)
                                        permissionDialogData = null
                                    },
                                    onDeny = {
                                        request.deny()
                                        permissionDialogData = null
                                    }
                                )
                            }
                        }

                        loadUrl(url)
                    }
                },
                modifier = modifier.fillMaxWidth().fillMaxHeight()
    )

    // Show permission dialog when needed
    permissionDialogData?.let { dialogData ->
        PermissionDialog(
            title = dialogData.title,
            message = dialogData.message,
            onAllow = dialogData.onAllow,
            onDeny = dialogData.onDeny,
            backgroundColor = backgroundColor,
            primaryColor = primaryColor,
            secondaryColor = secondaryColor
        )
    }
}

/**
 * Data class to hold permission dialog information
 */
private data class PermissionDialogData(
    val title: String,
    val message: String,
    val onAllow: () -> Unit,
    val onDeny: () -> Unit
)

/**
 * A styled permission dialog using Compose that matches the app's theme
 */
@Composable
private fun PermissionDialog(
    title: String,
    message: String,
    onAllow: () -> Unit,
    onDeny: () -> Unit,
    backgroundColor: Color,
    primaryColor: Color,
    secondaryColor: Color
) {
    AlertDialog(
        onDismissRequest = onDeny,
        title = {
            Text(
                text = title,
                color = Color.White
            )
        },
        text = {
            Text(
                text = message,
                color = Color.White
            )
        },
        confirmButton = {
            TextButton(onClick = onAllow) {
                Text(
                    text = "Allow",
                    color = primaryColor
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDeny) {
                Text(
                    text = "Deny",
                    color = secondaryColor
                )
            }
        },
        containerColor = backgroundColor
    )
}
