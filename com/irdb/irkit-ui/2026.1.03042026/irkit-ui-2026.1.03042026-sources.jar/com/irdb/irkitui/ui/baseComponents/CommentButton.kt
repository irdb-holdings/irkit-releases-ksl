package com.irdb.irkitui.ui.baseComponents

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun CommentButton(
    modifier: Modifier = Modifier,
    onCommentClick: () -> Unit,
    added: Boolean = true,
    count: Int = 0,
    // We'll need to provide resource IDs or image vectors externally since this is a library
    addedIcon: ImageVector? = null,
    outlineIcon: ImageVector? = null
) {
    ShadowButton(
        modifier = modifier,
        onClick = onCommentClick
    ) {
        if (addedIcon != null && outlineIcon != null) {
            Icon(
                imageVector = if (added) addedIcon else outlineIcon,
                contentDescription = "Comment",
                tint = Color.White,
                modifier = Modifier.padding(8.dp)
            )
        }

        ButtonCountText(
            count = count
        )
    }
}

@Preview(showBackground = false)
@Composable
fun CommentButtonPreview() {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(8.dp)
    ) {
        // Light theme preview
        MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(background = Color.White)) {
            CommentButton(
                onCommentClick = { },
                added = true,
                count = 2,
                addedIcon = null, // Would need actual icons for real usage
                outlineIcon = null
            )
        }

        // Dark theme preview
        MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(background = Color.Black)) {
            CommentButton(
                onCommentClick = { },
                added = false,
                addedIcon = null,
                outlineIcon = null
            )
        }
    }
}
