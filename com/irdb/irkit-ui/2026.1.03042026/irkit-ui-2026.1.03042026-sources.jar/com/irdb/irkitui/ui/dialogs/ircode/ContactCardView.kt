package com.irdb.irkitui.ui.dialogs.ircode

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.analytics.ViewSource
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.ParsedMetaItem
import com.irdb.irkit.enums.ImageStatus
import com.irdb.irkit.enums.MetaTypes
import com.irdb.irkit.extensions.extractValueFromParentheses
import com.irdb.irkit.getLinks
import com.irdb.irkit.getMetaContent
import com.irdb.irkitui.trackLinkClick
import com.irdb.irkitui.ui.baseComponents.ContentDescription
import com.irdb.irkitui.ui.baseComponents.EmailLink
import com.irdb.irkitui.ui.baseComponents.PhoneLink
import com.irdb.irkitui.ui.components.ContentMetaLinksView
import com.irdb.irkitui.ui.dialogs.ircode.panels.CustomContentPanel
import com.irdb.irkitui.ui.dialogs.ircode.panels.TagsDisplayPanel
import com.irdb.irkitui.ui.dimens.ExpandedContentDimens

// Shared gray used for subtitles (job title, company) and table label column
private val contactGray = Color.White.copy(alpha = 0.45f)

// Fields shown as heading/subtitle — excluded from the meta table
private val contactTableExcludedTypes = setOf(
    MetaTypes.FirstName,
    MetaTypes.LastName,
    MetaTypes.Company,
    MetaTypes.JobTitle,
    MetaTypes.CardType,
    MetaTypes.Description,
    MetaTypes.Title,
    MetaTypes.Link,
    MetaTypes.Tags,
    MetaTypes.Custom,
    MetaTypes.Year,
    MetaTypes.Medium,
    MetaTypes.Size,
    MetaTypes.ProductLink,
    MetaTypes.EmbeddedVideo,
    MetaTypes.ContactInfo
)

@Composable
private fun ContactMetaRow(label: String, data: ParsedMetaItem?) {
    data ?: return
    val value = data.content.toString().extractValueFromParentheses()
    if (value.isEmpty()) return

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(0.35f),
            color = contactGray,
            fontWeight = FontWeight.Normal,
            fontSize = 14.sp
        )
        when (data.metaTypeEnum()) {
            MetaTypes.Phone -> PhoneLink(value, modifier = Modifier.weight(0.65f), fontSize = 14.sp)
            MetaTypes.Email -> EmailLink(value, modifier = Modifier.weight(0.65f), fontSize = 14.sp)
            else -> Text(
                text = value,
                modifier = Modifier.weight(0.65f),
                color = Color.White,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun ContactCardMetaTable(image: ImageModel) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(ExpandedContentDimens.metaTablePadding)
    ) {
        image.metaItems
            .filter { !contactTableExcludedTypes.contains(it.metaTypeEnum()) }
            .sortedBy { it.order }
            .forEach { item ->
                ContactMetaRow(
                    label = item.metaTypeEnum().title,
                    data = image.getMetaItemForType(item.metaType)
                )
            }
    }
}

@Composable
fun ContactCardView(
    stateHolder: ImageDetailsStateHolder,
    onContentMetaLinksClicked: (ImageModel, MetaContent.Link) -> Unit,
    viewSource: ViewSource? = null,
    modifier: Modifier = Modifier
) {
    val image = stateHolder.currentImage

    val firstName = image.getMetaContent<MetaContent.FirstName>("FirstName")?.firstName
    val lastName = image.getMetaContent<MetaContent.LastName>("LastName")?.lastName
    val fullName = listOfNotNull(
        firstName?.takeIf { it.isNotBlank() },
        lastName?.takeIf { it.isNotBlank() }
    ).joinToString(" ").takeIf { it.isNotBlank() }

    val jobTitle = image.getMetaContent<MetaContent.JobTitle>("JobTitle")?.jobTitle
        ?.takeIf { it.isNotBlank() }
    val company = image.getMetaContent<MetaContent.Company>("Company")?.company
        ?.takeIf { it.isNotBlank() }

    LazyColumn(
        modifier = modifier
            .fillMaxHeight()
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 80.dp),
        userScrollEnabled = true
    ) {
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Full name — line 1 heading
        fullName?.let { name ->
            item {
                Text(
                    text = name,
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 34.sp
                )
            }
        }

        // Job title — line 2 (same gray as table labels)
        jobTitle?.let { title ->
            item {
                Spacer(modifier = Modifier.height(4.dp))
            }
            item {
                Text(
                    text = title,
                    color = contactGray,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Company — line 3 (same gray)
        company?.let { co ->
            item {
                Text(
                    text = co,
                    color = contactGray,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        if (image.status == ImageStatus.DRAFT) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
            item {
                DraftPrivacyBanner()
            }
        }

        if (image.description.isNotBlank()) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
            item {
                ContentDescription(
                    description = image.description,
                    color = Color.White,
                    maxLines = 99,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        image.getLinks()?.let {
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
            item {
                Row(
                    horizontalArrangement = Arrangement.Start,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ContentMetaLinksView(
                        image = image,
                        onClick = { link ->
                            trackLinkClick(
                                link = link,
                                image = image,
                                viewSource = viewSource,
                                viewType = "full",
                                cameraMode = null
                            )
                            onContentMetaLinksClicked(image, link)
                        }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Filtered meta table — gray labels, excludes name/title/company
        item {
            ContactCardMetaTable(image = image)
        }

        if (stateHolder.hasTags) {
            item {
                TagsDisplayPanel(stateHolder.getTags())
            }
            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        if (stateHolder.hasCustomFields) {
            item {
                CustomContentPanel(stateHolder.getCustomFieldsArray())
            }
            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
