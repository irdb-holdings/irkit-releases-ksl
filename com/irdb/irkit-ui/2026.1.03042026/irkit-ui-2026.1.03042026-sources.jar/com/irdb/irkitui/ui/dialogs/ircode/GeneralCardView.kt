package com.irdb.irkitui.ui.dialogs.ircode

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.analytics.ViewSource
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.enums.ImageStatus
import com.irdb.irkit.getLinks
import com.irdb.irkitui.trackLinkClick
import com.irdb.irkitui.ui.baseComponents.ContentDescription
import com.irdb.irkitui.ui.baseComponents.ContentTitle
import com.irdb.irkitui.ui.components.ContentMetaLinksView
import com.irdb.irkitui.ui.dialogs.ircode.panels.CustomContentPanel
import com.irdb.irkitui.ui.dialogs.ircode.panels.TagsDisplayPanel

@Composable
fun GeneralCardView(
    stateHolder: ImageDetailsStateHolder,
    onContentMetaLinksClicked: (ImageModel, MetaContent.Link) -> Unit,
    viewSource: ViewSource? = null,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxHeight()
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 80.dp),
        userScrollEnabled = true
    ) {
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            ContentTitle(
                title = stateHolder.currentImage.title,
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            )
        }

        val yearMediumSize = stateHolder.getYearGallerySizeArray()
            .filter { it.isNotEmpty() }
            .joinToString(" • ")
        if (yearMediumSize.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
            }
            item {
                Text(
                    text = yearMediumSize,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        if (stateHolder.currentImage.status == ImageStatus.DRAFT) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
            }
            item {
                DraftPrivacyBanner()
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
        }

        item {
            ContentDescription(
                description = stateHolder.currentImage.description,
                color = Color.White,
                maxLines = 99,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            stateHolder.currentImage.getLinks()?.let {
                Row(
                    horizontalArrangement = Arrangement.Start,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ContentMetaLinksView(
                        image = stateHolder.currentImage,
                        onClick = { link ->
                            trackLinkClick(
                                link = link,
                                image = stateHolder.currentImage,
                                viewSource = viewSource,
                                viewType = "full",
                                cameraMode = null
                            )
                            onContentMetaLinksClicked(stateHolder.currentImage, link)
                        }
                    )
                }
            }
        }

        if (stateHolder.hasTags) {
            item {
                TagsDisplayPanel(stateHolder.getTags())
            }
            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        if (stateHolder.hasCustomFields) {
            item {
                CustomContentPanel(stateHolder.getCustomFieldsArray())
            }
            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
