package com.irdb.irkitui.components

import android.util.Log
import android.view.ViewGroup
import androidx.camera.core.Camera
import androidx.camera.core.FocusMeteringAction
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.irdb.irkitui.CameraMode
import com.irdb.irkitui.components.GuidingRectangle
import com.irdb.irkitui.components.scanningEffect
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun CameraPreview(
    previewView: PreviewView,
    isSearching: Boolean,
    isBlurred: Boolean,
    shouldShowGuidingRectangle: Boolean,
    isDeviceStable: Boolean = false,
    lastSeenImage: Boolean = false,
    camera: Camera? = null,
    cameraMode: CameraMode,
    modifier: Modifier = Modifier,
    useFitScaleType: Boolean = false
) {
    var focusPoint by remember { mutableStateOf<Offset?>(null) }
    var showFocusAnimation by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val animationSize = with(density) { 100.dp.toPx() }
    val halfSize = animationSize / 2
    var scale by remember { mutableStateOf(1f) }

    Box(
        modifier = modifier.fillMaxSize()
    ) {
        AndroidView(
            factory = {
                previewView.apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = if (useFitScaleType) PreviewView.ScaleType.FIT_CENTER else PreviewView.ScaleType.FILL_CENTER
                }
            },
            update = { view ->
                view.scaleType = if (useFitScaleType) PreviewView.ScaleType.FIT_CENTER else PreviewView.ScaleType.FILL_CENTER
            },
            modifier = Modifier
                .fillMaxSize()
                .scanningEffect(isActive = isSearching)
                .graphicsLayer {
                    if (isBlurred) {
                        renderEffect = BlurEffect(radiusX = 40f, radiusY = 40f)
                    }
                }
                // Handle double tap for focus
                .pointerInput(camera) {
                    detectTapGestures(
                        onDoubleTap = { offset ->
                            Log.d("CameraPreview", "Double tap detected at x: ${offset.x}, y: ${offset.y}")

                            camera?.let {
                                focusPoint = offset
                                showFocusAnimation = true

                                val meteringPoint = previewView.meteringPointFactory
                                    .createPoint(offset.x, offset.y)

                                val action = FocusMeteringAction.Builder(meteringPoint)
                                    .setAutoCancelDuration(3, TimeUnit.SECONDS)
                                    .build()

                                it.cameraControl.startFocusAndMetering(action)

                                MainScope().launch {
                                    delay(1400)
                                    showFocusAnimation = false
                                }
                            }
                        }
                    )
                }
                // Handle pinch to zoom
                .pointerInput(camera) {
                    detectTransformGestures { centroid, pan, zoom, rotation ->
                        camera?.cameraInfo?.zoomState?.value?.let { zoomState ->
                            val currentZoomRatio = zoomState.zoomRatio
                            val newZoom = (currentZoomRatio * zoom).coerceIn(
                                zoomState.minZoomRatio,
                                zoomState.maxZoomRatio
                            )
                            camera.cameraControl.setZoomRatio(newZoom)
                            scale = newZoom
                        }
                    }
                }
        )

        // Focus Animation
        focusPoint?.let { point ->
            Box(
                modifier = Modifier.offset {
                    IntOffset(
                        (point.x - halfSize).toInt(),
                        (point.y - halfSize).toInt()
                    )
                }
            ) {
                FocusAnimation(
                    center = Offset(halfSize, halfSize),
                    isVisible = showFocusAnimation
                )
            }
        }

        // Guiding rectangle is visible in all camera modes (Live+, Snapshot, Creator)
        // to help users frame objects properly regardless of the mode they're using
        GuidingRectangle(
            shouldUseYellowColor = !isSearching && lastSeenImage,
            cameraMode = cameraMode
        )
    }
}

@Composable
private fun FocusAnimation(
    center: Offset,
    isVisible: Boolean,
    modifier: Modifier = Modifier
) {
    val animatedProgress = remember { Animatable(0f) }
    val density = LocalDensity.current
    val strokeWidth = with(density) { 5.dp.toPx() }

    LaunchedEffect(isVisible) {
        if (isVisible) {
            animatedProgress.snapTo(0f)
            animatedProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = 1400,
                    easing = FastOutSlowInEasing
                )
            )
        }
    }

    if (isVisible) {
        Canvas(
            modifier = modifier.size(200.dp)
        ) {
            val progress = animatedProgress.value
            val radius = size.minDimension / 4 * progress
            val alpha = 1f - progress

            // Draw outer circle
            drawCircle(
                color = Color.Yellow.copy(alpha = alpha),
                radius = radius,
                center = center,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
    }
}
