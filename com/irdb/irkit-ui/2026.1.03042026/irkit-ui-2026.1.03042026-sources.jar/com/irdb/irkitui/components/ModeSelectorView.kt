package com.irdb.irkitui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.CameraMode
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme

object ModeSelectorViewDimens {
    val height = 38.dp
    val cornerRadius = 24.dp
    val padding = 3.dp
    val textPadding = 12.dp
    val backgroundAlpha = 0.4f // Default transparency level
}

/**
 * ModeSelectorView component for IRKit-UI.
 * Provides a segmented control to switch between camera modes.
 *
 * @param currentMode The currently selected camera mode
 * @param onModeChanged Callback when mode selection changes
 * @param modifier Modifier for styling
 * @param backgroundAlpha Alpha value for background transparency
 */
@Composable
fun ModeSelectorView(
    currentMode: CameraMode,
    onModeChanged: (CameraMode) -> Unit,
    modifier: Modifier = Modifier,
    backgroundAlpha: Float = ModeSelectorViewDimens.backgroundAlpha
) {
    // Filter out CREATOR mode for cleaner UI
    val availableModes = listOf(CameraMode.LIVE, CameraMode.SNAPSHOT)

    // Access theme colors
    val colors = IRKitThemeAccessor.colors
    val typography = IRKitThemeAccessor.typography

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(ModeSelectorViewDimens.height)
            .clip(RoundedCornerShape(ModeSelectorViewDimens.cornerRadius))
            .background(colors.selectorBackground.copy(alpha = backgroundAlpha))
            .padding(ModeSelectorViewDimens.padding)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            availableModes.forEach { mode ->
                val isSelected = mode == currentMode

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(ModeSelectorViewDimens.height - (ModeSelectorViewDimens.padding * 2))
                        .clip(RoundedCornerShape(ModeSelectorViewDimens.cornerRadius - ModeSelectorViewDimens.padding))
                        .background(
                            if (isSelected) colors.selectorSelected
                            else Color.Transparent
                        )
                        .clickable { onModeChanged(mode) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mode.displayName,
                        style = typography.bodyLarge,
                        color = if (isSelected) colors.onSelectorSelected else colors.selectorUnselectedText,
                        modifier = Modifier.padding(horizontal = ModeSelectorViewDimens.textPadding),
                        softWrap = false
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF000000)
@Composable
fun ModeSelectorViewLivePreview() {
    IRKitUITheme {
        ModeSelectorView(
            currentMode = CameraMode.LIVE,
            onModeChanged = { }
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF000000)
@Composable
fun ModeSelectorViewSnapshotPreview() {
    IRKitUITheme {
        ModeSelectorView(
            currentMode = CameraMode.SNAPSHOT,
            onModeChanged = { }
        )
    }
}
