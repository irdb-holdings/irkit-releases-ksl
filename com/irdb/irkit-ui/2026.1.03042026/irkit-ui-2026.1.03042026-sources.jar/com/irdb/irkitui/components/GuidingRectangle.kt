package com.irdb.irkitui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.CameraMode
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun GuidingRectangle(
    shouldUseYellowColor: Boolean = false,
    cameraMode: CameraMode,
    modifier: Modifier = Modifier
) {
    // Access theme colors
    val colors = IRKitThemeAccessor.colors

    val strokeColor = if (shouldUseYellowColor) {
        colors.guidingRectangleActive
    } else {
        colors.guidingRectangle
    }

    val overlayColor = colors.cameraOverlay

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Calculate dimensions similar to iOS implementation
            val horizontalPadding = 60.dp.toPx()
            val aspectRatioWidth = 133f
            val aspectRatioHeight = 150f

            // Calculate bars height
            val bottomBarHeight = size.width * (160f / 393f)
            val topBarHeight = size.width * (110f / 393f)

            // Calculate available vertical space
            val availableVerticalSpace = size.height - bottomBarHeight - topBarHeight

            // Calculate maximum possible width and height
            val maxWidth = size.width - (horizontalPadding * 2)
            val maxHeight = availableVerticalSpace

            // Calculate the rectangle dimensions while maintaining the aspect ratio
            var finalRectangleWidth = maxWidth
            var finalRectangleHeight = finalRectangleWidth * (aspectRatioHeight / aspectRatioWidth)

            if (finalRectangleHeight > maxHeight) {
                finalRectangleHeight = maxHeight
                finalRectangleWidth = finalRectangleHeight * (aspectRatioWidth / aspectRatioHeight)
            }

            // Calculate the y-position to center the rectangle between the top and bottom bars
            val yOffset = topBarHeight + (availableVerticalSpace - finalRectangleHeight) / 2
            val xOffset = (size.width - finalRectangleWidth) / 2

            // Make the transparent center 7% larger than the corner edges
            val scaleFactor = 1.07f
            val enlargedWidth = finalRectangleWidth * scaleFactor
            val enlargedHeight = finalRectangleHeight * scaleFactor

            // Center the enlarged rectangle
            val enlargedXOffset = (size.width - enlargedWidth) / 2
            val enlargedYOffset = yOffset - (enlargedHeight - finalRectangleHeight) / 2

            // live mode is the only mode with semi-transparent outline

            // Draw semi-transparent overlay with transparent center
            val overlayPath = Path().apply {
                addRect(Rect(Offset.Zero, size))
                addRoundRect(
                    RoundRect(
                        left = enlargedXOffset,
                        top = enlargedYOffset,
                        right = enlargedXOffset + enlargedWidth,
                        bottom = enlargedYOffset + enlargedHeight,
                        cornerRadius = CornerRadius(20.dp.toPx())
                    )
                )
                fillType = PathFillType.EvenOdd
            }

            if (cameraMode == CameraMode.LIVE) {
                drawPath(
                    path = overlayPath,
                    color = overlayColor
                )
            }

            // Draw each corner separately with scaling
            val edgeLength = 50.dp.toPx()
            val cornerRadius = 20.dp.toPx()

            // Function to draw a single corner with scaling
            fun drawCorner(startX: Float, startY: Float, isTopCorner: Boolean, isLeftCorner: Boolean) {
                val cornerPath = Path()
                val scaledEdgeLength = edgeLength
                val scaledCornerRadius = cornerRadius

                // Calculate scaled position to maintain corner position while scaling
                val scaledX = if (isLeftCorner) {
                    startX
                } else {
                    startX - (scaledEdgeLength - edgeLength)
                }
                val scaledY = if (isTopCorner) {
                    startY
                } else {
                    startY - (scaledEdgeLength - edgeLength)
                }

                if (isTopCorner) {
                    if (isLeftCorner) {
                        // Top left corner
                        cornerPath.moveTo(scaledX, scaledY + scaledEdgeLength)
                        cornerPath.arcTo(
                            rect = Rect(
                                left = scaledX,
                                top = scaledY,
                                right = scaledX + scaledCornerRadius * 2,
                                bottom = scaledY + scaledCornerRadius * 2
                            ),
                            startAngleDegrees = 180f,
                            sweepAngleDegrees = 90f,
                            forceMoveTo = false
                        )
                        cornerPath.lineTo(scaledX + scaledEdgeLength, scaledY)
                    } else {
                        // Top right corner
                        cornerPath.moveTo(scaledX - scaledEdgeLength, scaledY)
                        cornerPath.arcTo(
                            rect = Rect(
                                left = scaledX - scaledCornerRadius * 2,
                                top = scaledY,
                                right = scaledX,
                                bottom = scaledY + scaledCornerRadius * 2
                            ),
                            startAngleDegrees = 270f,
                            sweepAngleDegrees = 90f,
                            forceMoveTo = false
                        )
                        cornerPath.lineTo(scaledX, scaledY + scaledEdgeLength)
                    }
                } else {
                    if (isLeftCorner) {
                        // Bottom left corner
                        cornerPath.moveTo(scaledX, scaledY - scaledEdgeLength)
                        cornerPath.arcTo(
                            rect = Rect(
                                left = scaledX,
                                top = scaledY - scaledCornerRadius * 2,
                                right = scaledX + scaledCornerRadius * 2,
                                bottom = scaledY
                            ),
                            startAngleDegrees = 180f,
                            sweepAngleDegrees = -90f,
                            forceMoveTo = false
                        )
                        cornerPath.lineTo(scaledX + scaledEdgeLength, scaledY)
                    } else {
                        // Bottom right corner
                        cornerPath.moveTo(scaledX - scaledEdgeLength, scaledY)
                        cornerPath.arcTo(
                            rect = Rect(
                                left = scaledX - scaledCornerRadius * 2,
                                top = scaledY - scaledCornerRadius * 2,
                                right = scaledX,
                                bottom = scaledY
                            ),
                            startAngleDegrees = 90f,
                            sweepAngleDegrees = -90f,
                            forceMoveTo = false
                        )
                        cornerPath.lineTo(scaledX, scaledY - scaledEdgeLength)
                    }
                }

                // Draw shadow first
                drawPath(
                    path = cornerPath,
                    color = Color.Black.copy(alpha = 0.5f),
                    style = Stroke(
                        width = 4.dp.toPx(),
                        cap = StrokeCap.Round
                    ),
                    blendMode = BlendMode.SrcOver
                )

                // Draw corner
                drawPath(
                    path = cornerPath,
                    color = strokeColor,
                    style = Stroke(
                        width = 4.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                )
            }

            // Draw all corners
            drawCorner(xOffset, yOffset, true, true) // Top left
            drawCorner(xOffset + finalRectangleWidth, yOffset, true, false) // Top right
            drawCorner(xOffset, yOffset + finalRectangleHeight, false, true) // Bottom left
            drawCorner(xOffset + finalRectangleWidth, yOffset + finalRectangleHeight, false, false) // Bottom right
        }
    }
}

private fun DrawScope.drawOverlay(
    size: Size,
    rectSize: Size,
    rectOffset: Offset
) {
    // Draw full screen semi-transparent black background
    drawRect(
        color = Color.Black.copy(alpha = 0.2f),
        size = size
    )

    // Create path for transparent center
    val path = Path().apply {
        // Add outer rectangle (full screen)
        addRect(Rect(Offset.Zero, size))

        // Subtract inner rectangle (scanning area)
        addRoundRect(
            RoundRect(
                left = rectOffset.x,
                top = rectOffset.y,
                right = rectOffset.x + rectSize.width,
                bottom = rectOffset.y + rectSize.height,
                cornerRadius = CornerRadius(20.dp.toPx())
            )
        )

        // Use EvenOdd fill type to create the cutout effect
        fillType = PathFillType.EvenOdd
    }

    drawPath(
        path = path,
        color = Color.Black.copy(alpha = 0.2f)
    )
}

private fun DrawScope.drawCornerEdges(
    rectSize: Size,
    rectOffset: Offset,
    strokeColor: Color,
    edgeLength: Float,
    cornerRadius: Float
) {
    val path = Path()

    // Top left corner
    path.moveTo(rectOffset.x, rectOffset.y + edgeLength)
    path.arcTo(
        rect = Rect(
            left = rectOffset.x,
            top = rectOffset.y,
            right = rectOffset.x + cornerRadius * 2,
            bottom = rectOffset.y + cornerRadius * 2
        ),
        startAngleDegrees = 180f,
        sweepAngleDegrees = 90f,
        forceMoveTo = false
    )
    path.lineTo(rectOffset.x + edgeLength, rectOffset.y)

    // Top right corner
    path.moveTo(rectOffset.x + rectSize.width - edgeLength, rectOffset.y)
    path.arcTo(
        rect = Rect(
            left = rectOffset.x + rectSize.width - cornerRadius * 2,
            top = rectOffset.y,
            right = rectOffset.x + rectSize.width,
            bottom = rectOffset.y + cornerRadius * 2
        ),
        startAngleDegrees = 270f,
        sweepAngleDegrees = 90f,
        forceMoveTo = false
    )
    path.lineTo(rectOffset.x + rectSize.width, rectOffset.y + edgeLength)

    // Bottom left corner
    path.moveTo(rectOffset.x, rectOffset.y + rectSize.height - edgeLength)
    path.arcTo(
        rect = Rect(
            left = rectOffset.x,
            top = rectOffset.y + rectSize.height - cornerRadius * 2,
            right = rectOffset.x + cornerRadius * 2,
            bottom = rectOffset.y + rectSize.height
        ),
        startAngleDegrees = 180f,
        sweepAngleDegrees = -90f,
        forceMoveTo = false
    )
    path.lineTo(rectOffset.x + edgeLength, rectOffset.y + rectSize.height)

    // Bottom right corner
    path.moveTo(rectOffset.x + rectSize.width, rectOffset.y + rectSize.height - edgeLength)
    path.arcTo(
        rect = Rect(
            left = rectOffset.x + rectSize.width - cornerRadius * 2,
            top = rectOffset.y + rectSize.height - cornerRadius * 2,
            right = rectOffset.x + rectSize.width,
            bottom = rectOffset.y + rectSize.height
        ),
        startAngleDegrees = 0f,
        sweepAngleDegrees = 90f,
        forceMoveTo = false
    )
    path.lineTo(rectOffset.x + rectSize.width - edgeLength, rectOffset.y + rectSize.height)

    // Draw shadow first
    drawPath(
        path = path,
        color = Color.Black.copy(alpha = 0.5f),
        style = Stroke(
            width = 4.dp.toPx(),
            cap = StrokeCap.Round
        ),
        blendMode = BlendMode.SrcOver
    )

    // Draw corners
    drawPath(
        path = path,
        color = strokeColor,
        style = Stroke(
            width = 4.dp.toPx(),
            cap = StrokeCap.Round
        )
    )
}

@Preview(
    name = "Default State",
    showBackground = true,
    backgroundColor = 0xFF000000,
    widthDp = 393,
    heightDp = 852
)
@Composable
private fun GuidingRectanglePreview() {
    IRKitUITheme {
        GuidingRectangle(cameraMode = CameraMode.LIVE)
    }
}

@Preview(
    name = "With Image Recognized",
    showBackground = true,
    backgroundColor = 0xFF000000,
    widthDp = 393,
    heightDp = 852
)
@Composable
private fun GuidingRectangleWithImagePreview() {
    IRKitUITheme {
        GuidingRectangle(shouldUseYellowColor = true, cameraMode = CameraMode.LIVE)
    }
}

@Preview(
    name = "All Features",
    showBackground = true,
    backgroundColor = 0xFF000000,
    widthDp = 393,
    heightDp = 852
)
@Composable
private fun GuidingRectangleAllFeaturesPreview() {
    IRKitUITheme {
        GuidingRectangle(
            shouldUseYellowColor = true,
            cameraMode = CameraMode.LIVE
        )
    }
}
