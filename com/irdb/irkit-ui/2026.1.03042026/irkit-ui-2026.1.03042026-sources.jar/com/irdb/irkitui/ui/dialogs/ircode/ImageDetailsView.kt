package com.irdb.irkitui.ui.dialogs.ircode

import android.util.Log
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.BottomSheetScaffold
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberBottomSheetScaffoldState
import androidx.compose.material3.rememberStandardBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.irdb.analytics.AnalyticsClient
import com.irdb.analytics.ViewSource
import com.irdb.analytics.ViewType
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.enums.CardTypes.ArtCard
import com.irdb.irkit.enums.CardTypes.Contact
import com.irdb.irkit.enums.CardTypes.ProductCard
import com.irdb.irkit.enums.MetaTypes
import com.irdb.irkit.getCardTypeEmum
import com.irdb.irkit.getCustomContent
import com.irdb.irkit.getTags
import com.irdb.irkitui.ui.components.FullSizeImage
import kotlinx.coroutines.launch

object ImageDetailsDimens {
    val imageHeightPercentage = 0.45f
    val backgroundImageScale = 1.5f
    val backgroundImageBlur = 20.dp
    val vignetteIntensity = 0.8f
    val vignetteRadius = 99f
    val vintageBorderRadius = 1.dp
    val imagePadding = 16.dp
}

@Composable
fun VintageVignette(
    modifier: Modifier = Modifier,
    intensity: Float = ImageDetailsDimens.vignetteIntensity,
    radius: Float = ImageDetailsDimens.vignetteRadius
) {
    Canvas(modifier = modifier) {
        val centerX = size.width / 2f
        val centerY = size.height / 2f
        val maxRadius = kotlin.math.min(size.width, size.height) / 2f * radius

        val brush = Brush.radialGradient(
            colors = listOf(
                Color.Transparent,
                Color.Black.copy(alpha = intensity)
            ),
            center = Offset(centerX, centerY),
            radius = maxRadius
        )

        drawRect(brush = brush)
    }
}

object DraftPrivacyBannerDimens {
    val padding = 12.dp
    val cornerRadius = 8.dp
    val iconSize = 20.dp
    val iconTextSpacing = 12.dp
    val fontSize = 14.sp
}

@Composable
fun DraftPrivacyBanner(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DraftPrivacyBannerDimens.cornerRadius))
            .background(Color(0xFF2D2D2D))
            .padding(DraftPrivacyBannerDimens.padding)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = "Private",
                tint = Color.White,
                modifier = Modifier.size(DraftPrivacyBannerDimens.iconSize)
            )
            Spacer(modifier = Modifier.width(DraftPrivacyBannerDimens.iconTextSpacing))
            Text(
                text = "This IRCODE is private and visible only to you.",
                color = Color.White,
                fontSize = DraftPrivacyBannerDimens.fontSize,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

class ImageDetailsStateHolder(
    initialImage: ImageModel
) {
    var currentImage: ImageModel = initialImage
        private set

    fun updateImage(image: ImageModel) {
        currentImage = image
    }

    fun getCardType() = currentImage.getCardTypeEmum()

    val hasTags: Boolean
        get() = currentImage.getTags().isNotEmpty()

    fun getTags(): List<String> = currentImage.getTags()

    val hasCustomFields: Boolean
        get() = currentImage.getCustomContent()?.isNotEmpty() ?: false

    fun getCustomFieldsArray(): List<Pair<String, String>> {
        val customContent = currentImage.getCustomContent() ?: return emptyList()
        return customContent.map { (k, v) -> k to v.toString() }
    }

    fun getMetaTypeValues(): List<Pair<MetaTypes, String>> {
        return MetaTypes.values().map { metaType ->
            metaType to currentImage.getMetaTypeValue(metaType)
        }.filter { (_, value) -> !value.isNullOrEmpty() }
            .filterNot { (metaType, _) ->
                metaType in listOf(
                    MetaTypes.Year, MetaTypes.Size, MetaTypes.Description,
                    MetaTypes.Title, MetaTypes.CardType, MetaTypes.Medium,
                    MetaTypes.Tags, MetaTypes.Custom, MetaTypes.ContactInfo,
                    MetaTypes.Link, MetaTypes.Address, MetaTypes.ProductLink
                )
            }
    }

    fun getYearGallerySizeArray(): List<String> {
        val year = currentImage.getMetaTypeValue(MetaTypes.Year)
        val galleryName = currentImage.getMetaTypeValue(MetaTypes.Medium)
        val size = currentImage.getMetaTypeValue(MetaTypes.Size)

        return listOfNotNull(
            year.takeIf { it.isNotEmpty() },
            galleryName.takeIf { it.isNotEmpty() },
            size.takeIf { it.isNotEmpty() }
        )
    }

    fun getArtistName(): String = currentImage.getMetaTypeValue(MetaTypes.ArtistName)
}

@Composable
private fun ImageDetailsBottomSheetContent(
    stateHolder: ImageDetailsStateHolder,
    onBuyProductClicked: (ImageModel, MetaContent.Link) -> Unit,
    onContentMetaLinksClicked: (ImageModel, MetaContent.Link) -> Unit,
    viewSource: ViewSource? = null,
    modifier: Modifier = Modifier
) {
    when (stateHolder.getCardType()) {
        Contact -> ContactCardView(
            stateHolder = stateHolder,
            onContentMetaLinksClicked = onContentMetaLinksClicked,
            viewSource = viewSource,
            modifier = modifier
        )
        ArtCard -> ArtCardView(
            stateHolder = stateHolder,
            onContentMetaLinksClicked = onContentMetaLinksClicked,
            viewSource = viewSource,
            modifier = modifier
        )
        ProductCard -> ProductCardView(
            stateHolder = stateHolder,
            onBuyProductClicked = onBuyProductClicked,
            onContentMetaLinksClicked = onContentMetaLinksClicked,
            viewSource = viewSource,
            modifier = modifier
        )
        else -> GeneralCardView(
            stateHolder = stateHolder,
            onContentMetaLinksClicked = onContentMetaLinksClicked,
            viewSource = viewSource,
            modifier = modifier
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageDetailsView(
    currentImage: ImageModel,
    onClose: () -> Unit = {},
    onBuyProductClicked: (ImageModel, MetaContent.Link) -> Unit = { _, _ -> },
    onContentMetaLinksClicked: (ImageModel, MetaContent.Link) -> Unit = { _, _ -> },
    viewSource: ViewSource = ViewSource.UNDEFINED,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(currentImage.imageId) {
        if (viewSource != ViewSource.UNDEFINED && currentImage.imageId.isNotEmpty()) {
            Log.d("ImageDetailsView", "Tracking FULL view: viewSource=$viewSource, imageId=${currentImage.imageId}")
            try {
                AnalyticsClient.getInstance().trackViewEvent(
                    viewType = ViewType.FULL,
                    viewSource = viewSource,
                    imageId = currentImage.imageId,
                    campaignId = currentImage.campaignId.takeIf { it > 0 }?.toString(),
                    campaignName = currentImage.campaignName?.takeIf { it.isNotEmpty() },
                    additionalParams = emptyMap()
                )
                Log.d("ImageDetailsView", "Successfully tracked FULL view entry")
            } catch (e: Exception) {
                Log.e("ImageDetailsView", "Error tracking full view analytics", e)
            }
        } else {
            Log.w("ImageDetailsView", "Skipping analytics: viewSource=${viewSource}, imageId=${currentImage.imageId}")
        }
    }

    val coroutineScope = rememberCoroutineScope()

    DisposableEffect(currentImage.imageId) {
        onDispose {
            if (viewSource != ViewSource.UNDEFINED && currentImage.imageId.isNotEmpty()) {
                Log.d("ImageDetailsView", "Full view dismissed - stopping FULL_VIEW timer")
                try {
                    coroutineScope.launch {
                        val duration = AnalyticsClient.getInstance().stopViewTimer(ViewType.FULL)
                        Log.d("ImageDetailsView", "Stopped FULL_VIEW timer, final duration: ${duration}ms")
                    }
                } catch (e: Exception) {
                    Log.e("ImageDetailsView", "Error stopping full view timer", e)
                }
            }
        }
    }

    val stateHolder = remember(currentImage) {
        ImageDetailsStateHolder(currentImage)
    }

    LaunchedEffect(currentImage) {
        stateHolder.updateImage(currentImage)
    }

    BoxWithConstraints(
        modifier = modifier.fillMaxSize()
    ) {
        val screenHeight = maxHeight
        val imageHeight = screenHeight * ImageDetailsDimens.imageHeightPercentage
        val headerHeight = 56.dp + 32.dp

        val sheetPeekHeight = (screenHeight - (headerHeight + imageHeight + 24.dp)).coerceAtLeast(0.dp)

        val scaffoldState = rememberBottomSheetScaffoldState(
            bottomSheetState = rememberStandardBottomSheetState(
                initialValue = SheetValue.PartiallyExpanded,
                skipHiddenState = true
            )
        )

        BottomSheetScaffold(
            scaffoldState = scaffoldState,
            sheetPeekHeight = sheetPeekHeight,
            sheetShape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            sheetContainerColor = Color.Black,
            sheetDragHandle = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .padding(top = 8.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Box(
                        modifier = Modifier
                            .width(32.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.White.copy(alpha = 0.3f))
                    )
                }
            },
            sheetContent = {
                ImageDetailsBottomSheetContent(
                    stateHolder = stateHolder,
                    onBuyProductClicked = onBuyProductClicked,
                    onContentMetaLinksClicked = onContentMetaLinksClicked,
                    viewSource = viewSource
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .systemBarsPadding()
            ) {
                Spacer(modifier = Modifier.height(headerHeight))

                val containerHeight = imageHeight - 20.dp

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(imageHeight)
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(containerHeight)
                            .clip(RoundedCornerShape(ImageDetailsDimens.vintageBorderRadius))
                            .background(Color(0xFF2A2A2A))
                    ) {
                        stateHolder.currentImage.displayImageUrl.ifEmpty { null }?.let {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                FullSizeImage(
                                    image = stateHolder.currentImage,
                                    isExpanded = true
                                )
                            }

                            VintageVignette(
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(ImageDetailsDimens.imagePadding),
                            contentAlignment = Alignment.Center
                        ) {
                            FullSizeImage(
                                image = stateHolder.currentImage,
                                isExpanded = true
                            )
                        }
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .zIndex(1000f)
                .fillMaxWidth()
                .systemBarsPadding()
                .padding(16.dp)
        ) {
            androidx.compose.material3.IconButton(
                onClick = onClose,
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Close",
                    tint = Color.White
                )
            }
        }
    }
}
