package com.irdb.irkitui.ui.baseComponents

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkit.ImageModel
import com.irdb.irkitui.theme.IRKitUITheme

/**
 * Share button component for IRKit-UI library.
 * Accepts a callback that handles the actual sharing logic (Branch.io, etc.)
 * in the parent app.
 */
@Composable
fun ShareButton(
    modifier: Modifier = Modifier,
    image: ImageModel,
    onShare: (ImageModel) -> Unit
) {
    ShadowButton(
        modifier = modifier,
        onClick = { onShare(image) }
    ) {
        Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share",
            tint = Color.White,
            modifier = Modifier.padding(8.dp)
        )
    }
}

@Preview(showBackground = false)
@Composable
fun ShareButtonPreview() {
    // Create a minimal mock image for preview
    val mockImage = ImageModel.Placeholder(imageId = "preview")
    
    IRKitUITheme {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(8.dp)
        ) {
            // Light theme preview
            Surface(color = Color.White) {
                ShareButton(
                    onShare = { },
                    image = mockImage
                )
            }

            // Dark theme preview
            Surface(color = Color.Black) {
                ShareButton(
                    onShare = { },
                    image = mockImage
                )
            }
        }
    }
}

@Preview(showBackground = false, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun ShareButtonDarkPreview() {
    // Create a minimal mock image for preview
    val mockImage = ImageModel.Placeholder(imageId = "preview")
    
    IRKitUITheme(darkTheme = true) {
        Surface(color = Color.Black) {
            ShareButton(
                onShare = { },
                image = mockImage
            )
        }
    }
}
