package com.irdb.irkitui.ui.baseComponents

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

@Composable
fun PhoneLink(phone: String, modifier: Modifier = Modifier, fontSize: TextUnit = 16.sp) {
    val context = LocalContext.current
    Text(
        text = phone,
        color = Color.White,
        fontSize = fontSize,
        textDecoration = TextDecoration.Underline,
        modifier = modifier.clickable {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phone")
            }
            context.startActivity(intent)
        }
    )
}

@Preview(showBackground = true)
@Composable
fun PhoneLinkPreview() {
    PhoneLink(phone = "1234567890")
}
