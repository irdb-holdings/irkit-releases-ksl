package com.irdb.irkitui.theme

import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Defines the typography styles for IRKit-UI components.
 *
 * Uses system fonts with configurable TextStyle properties (size, weight, spacing).
 * No custom font file loading required.
 *
 * Usage in components:
 * ```kotlin
 * Text(
 *     text = "Title",
 *     style = IRKitTheme.typography.titleLarge
 * )
 * ```
 */
data class IRKitTypography(
    /** Large display text - 32.sp, Bold. Used for main screen titles */
    val displayLarge: TextStyle,

    /** Medium display text - 28.sp, Bold. Used for section headings */
    val displayMedium: TextStyle,

    /** Large title - 22.sp, Bold. Used for content titles */
    val titleLarge: TextStyle,

    /** Medium title - 20.sp, SemiBold. Used for card titles */
    val titleMedium: TextStyle,

    /** Large body text - 16.sp, Bold. Used for buttons and important body text */
    val bodyLarge: TextStyle,

    /** Medium body text - 14.sp, Medium. Used for subtitles and standard body */
    val bodyMedium: TextStyle,

    /** Small body text - 13.sp, Medium. Used for labels and captions */
    val bodySmall: TextStyle,

    /** Medium label - 12.sp, Medium. Used for badges and small labels */
    val labelMedium: TextStyle,

    /** Small label - 11.sp, Regular. Used for very small annotations */
    val labelSmall: TextStyle
) {
    companion object {
        /**
         * Creates the default typography with system fonts.
         * These values match the current hardcoded sizes in components.
         */
        fun default(): IRKitTypography = IRKitTypography(
            displayLarge = TextStyle(
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 40.sp
            ),
            displayMedium = TextStyle(
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 36.sp
            ),
            titleLarge = TextStyle(
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 28.sp
            ),
            titleMedium = TextStyle(
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                lineHeight = 26.sp
            ),
            bodyLarge = TextStyle(
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 24.sp
            ),
            bodyMedium = TextStyle(
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 20.sp
            ),
            bodySmall = TextStyle(
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 18.sp
            ),
            labelMedium = TextStyle(
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 16.sp
            ),
            labelSmall = TextStyle(
                fontSize = 11.sp,
                fontWeight = FontWeight.Normal,
                lineHeight = 14.sp
            )
        )
    }
}
