package com.irdb.irkitui.ui.components

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.getMetaContent
import com.irdb.irkitui.ui.baseComponents.ContentTitleForCollapsed

/**
 * Collapsed notification content for Contact card type.
 * Shows: full name (bold), job title, and company — matching iOS layout.
 */
@Composable
fun CollapsedContactContent(image: ImageModel) {
    val firstName = image.getMetaContent<MetaContent.FirstName>("FirstName")?.firstName
    val lastName = image.getMetaContent<MetaContent.LastName>("LastName")?.lastName
    val fullName = listOfNotNull(
        firstName?.takeIf { it.isNotBlank() },
        lastName?.takeIf { it.isNotBlank() }
    ).joinToString(" ").takeIf { it.isNotBlank() }

    val jobTitle = image.getMetaContent<MetaContent.JobTitle>("JobTitle")?.jobTitle
        ?.takeIf { it.isNotBlank() }
    val company = image.getMetaContent<MetaContent.Company>("Company")?.company
        ?.takeIf { it.isNotBlank() }

    // Line 1: Contact full name (bold, white)
    ContentTitleForCollapsed(title = fullName ?: image.getImageTitle())

    // Line 2: Job title (gray subtitle)
    jobTitle?.let { CollapsedSubtitleText(it) }

    // Line 3: Company (gray subtitle)
    company?.let { CollapsedSubtitleText(it) }
}

@Composable
private fun CollapsedSubtitleText(text: String) {
    Text(
        text = text,
        style = TextStyle(
            fontSize = 14.sp,
            fontWeight = FontWeight.Normal,
            color = Color.White.copy(alpha = 0.6f)
        ),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}
