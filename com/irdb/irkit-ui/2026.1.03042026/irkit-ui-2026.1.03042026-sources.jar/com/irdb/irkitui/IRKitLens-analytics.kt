package com.irdb.irkitui

import android.util.Log
import com.irdb.analytics.AnalyticsClient
import com.irdb.analytics.ButtonSource
import com.irdb.analytics.ButtonType
import com.irdb.analytics.ScanType
import com.irdb.analytics.ViewSource
import com.irdb.irkit.ImageModel
import com.irdb.irkit.ImageSearchResult
import com.irdb.irkit.dto.MetaContent

/**
 * Extension functions for IRKitLens analytics tracking.
 * Keeps analytics code separate from main IRKitLens.kt file.
 */

private const val TAG = "IRKitLens-analytics"

/**
 * Extract campaign ID from ImageModel for analytics.
 * Returns null if campaignId is 0 or invalid (to avoid sending default values).
 */
private fun ImageModel?.getCampaignIdForAnalytics(): String? {
    return this?.campaignId?.takeIf { it > 0 }?.toString()
}

/**
 * Extract campaign name from ImageModel for analytics.
 * Returns null if campaignName is null or empty (to avoid sending empty strings).
 */
private fun ImageModel?.getCampaignNameForAnalytics(): String? {
    return this?.campaignName?.takeIf { it.isNotEmpty() }
}

/**
 * Construct imageUrlOfScan from trackingId and bucketName.
 *
 * The imageUrlOfScan is the URL of the image submitted by the user to make the match.
 * Delegates to AnalyticsClient which uses the configured IR Engine base URL.
 *
 * @param trackingId The tracking ID from the image search result
 * @param bucketName The bucket name (default: "irdbMain")
 * @return The URL for the scanned image, or empty string if trackingId is empty
 */
internal fun getQueryImageUrlForTrackingId(trackingId: String, bucketName: String = "irdbMain"): String {
    return try {
        AnalyticsClient.getInstance().getQueryImageUrlForTrackingId(trackingId, bucketName)
    } catch (e: IllegalStateException) {
        // AnalyticsClient not initialized - return empty string
        ""
    }
}

/**
 * Track snapshot scan submission analytics event.
 * 
 * This function emits the "Scan Submitted — Snapshot/Camera Roll" analytics event
 * when a user takes a picture in SNAPSHOT mode (NOT CREATOR mode) for identification.
 * 
 * @param imageSearchResult The result from irEngine.processImageData()
 * @param cameraMode Current camera mode (must be SNAPSHOT for this to emit)
 */
internal fun trackSnapshotScanSubmission(
    imageSearchResult: ImageSearchResult,
    cameraMode: CameraMode
) {
    // Only emit for SNAPSHOT mode (NOT CREATOR mode)
    if (cameraMode != CameraMode.SNAPSHOT) {
        return
    }
    
    IRKitUI.getAnalyticsClient()?.let { analytics ->
        val trackingId = imageSearchResult.trackingId
        val bucketName = imageSearchResult.bucketName
        val imageUrlOfScan = getQueryImageUrlForTrackingId(trackingId, bucketName)
        
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Tracking snapshot scan submission: trackingId=$trackingId, bucketName=$bucketName")
        }
        
        analytics.trackScanEvent(
            scanType = ScanType.SNAPSHOT,
            matched = false, // We don't know match status at submission time
            imageUrlOfScan = imageUrlOfScan,
            additionalParams = mapOf(
                "buttonSource" to ButtonSource.HOME_VIEW.value,
                "buttonType" to ButtonType.SHUTTER.value,
                "viewSource" to ViewSource.SNAPSHOT.value
            )
        )
    } ?: run {
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Analytics client not available, skipping snapshot scan submission tracking")
        }
    }
}

/**
 * Track "Scan Result — No Match" analytics event.
 * 
 * This function emits the "Scan Result — No Match" event when a scan completes without a match.
 * 
 * **CRITICAL**: This event is ONLY emitted for SNAPSHOT and GALLERY modes (NOT LIVE mode).
 * This restriction is critical to avoid excessive calls from Live Visual Search.
 * 
 * @param imageSearchResult The result from irEngine.processImageData() (must have isSuccess == false)
 * @param cameraMode Current camera mode (must be SNAPSHOT for snapshot, or can be any mode for gallery)
 * @param isFromGallery Whether this scan is from gallery/camera roll (default false)
 */
internal fun trackNoMatchScanResult(
    imageSearchResult: ImageSearchResult,
    cameraMode: CameraMode,
    isFromGallery: Boolean = false
) {
    // CRITICAL: Only emit for SNAPSHOT/GALLERY modes, NOT LIVE mode
    // Check both camera mode and isFromLiveVisualSearch flag
    val isSnapshotMode = cameraMode == CameraMode.SNAPSHOT
    val isGalleryMode = isFromGallery
    val isLiveMode = imageSearchResult.isFromLiveVisualSearch
    
    // Do NOT emit if:
    // 1. It's from LIVE visual search (critical requirement)
    // 2. It's CREATOR mode (different flow)
    // 3. It's not SNAPSHOT and not GALLERY
    if (isLiveMode || cameraMode == CameraMode.CREATOR || (!isSnapshotMode && !isGalleryMode)) {
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Skipping no-match event: isLiveMode=$isLiveMode, cameraMode=${cameraMode.name}, isFromGallery=$isFromGallery")
        }
        return
    }
    
    // Only emit if scan was not successful (no match)
    if (imageSearchResult.isSuccess) {
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Skipping no-match event: scan was successful (matched)")
        }
        return
    }
    
    IRKitUI.getAnalyticsClient()?.let { analytics ->
        val trackingId = imageSearchResult.trackingId
        
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Tracking no-match scan result: trackingId=$trackingId, cameraMode=${cameraMode.name}, isFromGallery=$isFromGallery")
        }
        
        // Determine viewSource: use SNAPSHOT for both snapshot and gallery (ViewSource enum doesn't have GALLERY yet)
        val viewSource = if (isFromGallery) {
            ViewSource.SNAPSHOT.value // TODO: Add ViewSource.GALLERY to enum if needed
        } else {
            ViewSource.SNAPSHOT.value
        }
        
        analytics.trackScanEvent(
            scanType = ScanType.SNAPSHOT, // Use SNAPSHOT for both snapshot and gallery scans
            matched = false,
            scanTrackingId = trackingId,
            similarCount = 0, // Always 0 for no-match events
            additionalParams = mapOf(
                "viewSource" to viewSource
            )
        )
    } ?: run {
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Analytics client not available, skipping no-match scan result tracking")
        }
    }
}

/**
 * Determine buttonSource from context (viewSource, viewType, cameraMode).
 * 
 * @param viewSource The view source (e.g., LIVE_SCAN, SNAPSHOT, PROFILE)
 * @param viewType The view type (e.g., "full", "expanded", "compressed")
 * @param cameraMode The current camera mode (LIVE, SNAPSHOT, CREATOR)
 * @return The appropriate ButtonSource enum value
 */
internal fun determineButtonSource(
    viewSource: ViewSource? = null,
    viewType: String? = null,
    cameraMode: CameraMode? = null
): ButtonSource {
    // Priority 1: If viewType is "full" or "expanded", it's IRCODE_VIEW (ImageDetailsView or expanded notification)
    if (viewType == "full" || viewType == "expanded") {
        return ButtonSource.IRCODE_VIEW
    }
    
    // Priority 2: If viewSource is PROFILE, it's PROFILE_VIEW
    if (viewSource == ViewSource.PROFILE) {
        return ButtonSource.PROFILE_VIEW
    }
    
    // Priority 3: If cameraMode is LIVE, SNAPSHOT, or CREATOR, it's HOME_VIEW
    if (cameraMode == CameraMode.LIVE || cameraMode == CameraMode.SNAPSHOT || cameraMode == CameraMode.CREATOR) {
        return ButtonSource.HOME_VIEW
    }
    
    // Default: IRCODE_VIEW (maintains current behavior)
    return ButtonSource.IRCODE_VIEW
}

/**
 * Track link click analytics event.
 * 
 * This function emits the "Button Press — Link / LinkToSite" analytics event
 * when a user clicks on a link (Facebook, BBC News, etc.).
 * 
 * @param link The MetaContent.Link that was clicked
 * @param image The ImageModel associated with the link
 * @param viewSource The view source (e.g., LIVE_SCAN, SNAPSHOT, PROFILE)
 * @param viewType The view type (e.g., "full", "expanded", "compressed")
 * @param cameraMode The current camera mode (LIVE, SNAPSHOT, CREATOR)
 * @return A function to call if navigation fails (for error tracking)
 */
internal fun trackLinkClick(
    link: MetaContent.Link,
    image: ImageModel,
    viewSource: ViewSource? = null,
    viewType: String? = null,
    cameraMode: CameraMode? = null
): (() -> Unit) {
    IRKitUI.getAnalyticsClient()?.let { analytics ->
        // Determine buttonSource from context
        val buttonSource = determineButtonSource(viewSource, viewType, cameraMode)
        
        // Determine buttonType from link.onScanDisplay
        val buttonType = if (link.onScanDisplay) {
            ButtonType.LINK_TO_SITE
        } else {
            ButtonType.LINK
        }
        
        // Build additional parameters
        val additionalParams = mutableMapOf<String, Any>()
        viewSource?.let { additionalParams["viewSource"] = it.value }
        viewType?.let { additionalParams["viewType"] = it }
        
        // Get buttonLink from link.url
        val buttonLink = link.url.takeIf { it.isNotEmpty() }
        
        // Track button press event - duration is automatically determined from active timer
        analytics.trackButtonPressedEvent(
            buttonType = buttonType,
            buttonSource = buttonSource,
            buttonTitle = link.title.takeIf { it.isNotEmpty() },
            buttonLink = buttonLink,
            linkToFollow = null, // MetaContent.Link doesn't have linkToFollow (that's on ProductInCampaignDto)
            imageId = image.imageId.takeIf { it.isNotEmpty() },
            campaignId = image.getCampaignIdForAnalytics(),
            campaignName = image.getCampaignNameForAnalytics(),
            failed = false,
            additionalParams = additionalParams
        )
        
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Tracking link click: buttonType=${buttonType.value}, buttonSource=${buttonSource.value}, linkTitle=${link.title}, url=${link.url}")
        }
        
        // Return function to track failed navigation
        return {
            val failedParams = additionalParams.toMutableMap()
            failedParams["category"] = "deeplinkError"
            
            analytics.trackButtonPressedEvent(
                buttonType = buttonType,
                buttonSource = buttonSource,
                buttonTitle = link.title.takeIf { it.isNotEmpty() },
                buttonLink = buttonLink,
                linkToFollow = null,
                imageId = image.imageId.takeIf { it.isNotEmpty() },
                campaignId = image.getCampaignIdForAnalytics(),
                campaignName = image.getCampaignNameForAnalytics(),
                failed = true,
                additionalParams = failedParams
            )
            
            if (Log.isLoggable(TAG, Log.DEBUG)) {
                Log.d(TAG, "Tracking failed link navigation: buttonType=${buttonType.value}, buttonSource=${buttonSource.value}, linkTitle=${link.title}")
            }
        }
    } ?: run {
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "Analytics client not available, skipping link click tracking")
        }
        // Return no-op function if analytics not available
        return {}
    }
}

