package com.irdb.irkitui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.irdb.irkitui.IRKitUI

/**
 * Material3 color schemes for compatibility with Material components.
 * These are derived from the IRKit theme colors.
 */
private val DarkColorScheme = darkColorScheme(
    primary = IRKitThemePresets.Dark.colors.primary,
    secondary = IRKitThemePresets.Dark.colors.accent,
    tertiary = IRKitThemePresets.Dark.colors.badgeBackground,
    background = IRKitThemePresets.Dark.colors.background,
    surface = IRKitThemePresets.Dark.colors.surface,
    onPrimary = IRKitThemePresets.Dark.colors.onPrimary,
    onSecondary = IRKitThemePresets.Dark.colors.onAccent,
    onBackground = IRKitThemePresets.Dark.colors.textPrimary,
    onSurface = IRKitThemePresets.Dark.colors.textPrimary
)

private val LightColorScheme = lightColorScheme(
    primary = IRKitThemePresets.Light.colors.primary,
    secondary = IRKitThemePresets.Light.colors.accent,
    tertiary = IRKitThemePresets.Light.colors.badgeBackground,
    background = IRKitThemePresets.Light.colors.background,
    surface = IRKitThemePresets.Light.colors.surface,
    onPrimary = IRKitThemePresets.Light.colors.onPrimary,
    onSecondary = IRKitThemePresets.Light.colors.onAccent,
    onBackground = IRKitThemePresets.Light.colors.textPrimary,
    onSurface = IRKitThemePresets.Light.colors.textPrimary
)

/**
 * Main theme composable for IRKit-UI components.
 *
 * Provides both the IRKit theme (via [IRKitThemeProvider]) and Material3 theme
 * (via [MaterialTheme]) for compatibility with Material components.
 *
 * The theme is determined by:
 * 1. The client's configuration (from [IRKitUI.getConfig().theme])
 * 2. Falls back to [IRKitThemePresets.Dark] if configuration is unavailable
 *
 * Usage:
 * ```kotlin
 * IRKitUITheme {
 *     // Your composables can access theme via:
 *     // IRKitTheme.colors.primary
 *     // IRKitTheme.typography.bodyLarge
 *     MyComponent()
 * }
 * ```
 *
 * @param darkTheme Whether to use dark theme for Material components (defaults to system setting)
 * @param theme Override theme (optional, defaults to client config or Dark preset)
 * @param content The composable content that will have access to the theme
 */
@Composable
fun IRKitUITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    theme: IRKitTheme? = null,
    content: @Composable () -> Unit
) {
    // Determine which theme to use:
    // 1. Explicit override if provided
    // 2. Client config theme (resolved from LibraryClient without requiring full initialization)
    // 3. Default Dark theme as fallback
    val resolvedTheme = theme ?: try {
        IRKitUI.getTheme()
    } catch (e: Exception) {
        IRKitThemePresets.Dark
    }

    // Create Material3 color scheme from IRKit colors
    val materialColorScheme = if (darkTheme) {
        darkColorScheme(
            primary = resolvedTheme.colors.primary,
            secondary = resolvedTheme.colors.accent,
            tertiary = resolvedTheme.colors.badgeBackground,
            background = resolvedTheme.colors.background,
            surface = resolvedTheme.colors.surface,
            onPrimary = resolvedTheme.colors.onPrimary,
            onSecondary = resolvedTheme.colors.onAccent,
            onBackground = resolvedTheme.colors.textPrimary,
            onSurface = resolvedTheme.colors.textPrimary
        )
    } else {
        lightColorScheme(
            primary = resolvedTheme.colors.primary,
            secondary = resolvedTheme.colors.accent,
            tertiary = resolvedTheme.colors.badgeBackground,
            background = resolvedTheme.colors.background,
            surface = resolvedTheme.colors.surface,
            onPrimary = resolvedTheme.colors.onPrimary,
            onSecondary = resolvedTheme.colors.onAccent,
            onBackground = resolvedTheme.colors.textPrimary,
            onSurface = resolvedTheme.colors.textPrimary
        )
    }

    // Provide both IRKit theme and Material theme
    IRKitThemeProvider(theme = resolvedTheme) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content
        )
    }
}
