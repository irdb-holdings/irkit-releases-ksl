package com.irdb.irkitui.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.irdb.irkit.dto.ProductInCampaignDto
import com.irdb.irkitui.ui.baseComponents.BuyButton
import com.irdb.irkitui.ui.baseComponents.rememberImageLoader

@Composable
fun ProductItemView(
    product: ProductInCampaignDto,
    onBuyTapped: (ProductInCampaignDto) -> Unit,
    modifier: Modifier = Modifier
) {
    val imageLoader = rememberImageLoader()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 1.dp, top = 2.dp, end = 1.dp, bottom = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Product image
        Box(
            modifier = Modifier
                .size(96.dp)
                .background(
                    color = Color.White,
                    shape = MaterialTheme.shapes.medium
                )
        ) {
            if (product.imageUrl.isNotEmpty()) {
                android.util.Log.d("ProductItemView", "Loading product image: ${product.imageUrl} for product: ${product.title}")
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = null,
                    imageLoader = imageLoader,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .size(93.dp)
                        .padding(5.dp)
                        .align(Alignment.Center)
                )
            } else {
                android.util.Log.w("ProductItemView", "Product imageUrl is empty for product: ${product.title}")
            }
        }

        // Product title
        Text(
            text = product.title,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
            maxLines = 4
        )

        // Buy button
        BuyButton(
            product = product,
            onClick = { onBuyTapped(product) }
        )
    }
}
