package com.irdb.irkitui.ui.resultCards

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkit.IRKit
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.UserDto
import com.irdb.irkit.enums.ImageStatus
import com.irdb.irkitui.internal.AppDetection
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme
import com.irdb.irkitui.ui.baseComponents.GripView
import com.irdb.irkitui.ui.components.CollapsedContent
import com.irdb.irkitui.ui.internal.NotificationActionButtons

// This is what is shown when the AI recognizes something

// Constants for positioning the expanded content
private const val X_BUTTON_SIZE_DP = 80
private const val X_BUTTON_TO_EXPANDED_CONTENT_GAP_DP = 10 // Gap between expanded content bottom and X button top

/**
 * Default top padding for expanded notification to ensure proper spacing from the top of the view.
 * Lower value = notification starts higher (closer to top), allowing it to stretch down more
 * Higher value = notification starts lower (farther from top), reducing vertical space
 * Can be overridden via topContentPadding parameter for flexibility.
 */
private const val EXPANDED_NOTIFICATION_STARTING_POSITION_DP = 40

/**
 * Distance in dp that the notification should be positioned from the bottom of the screen.
 * This constant makes it easy to adjust the notification positioning.
 * Adjust this value to move the notification up (higher value) or down (lower value).
 */
private const val NOTIFICATION_BOTTOM_OFFSET_DP = 110

/**
 * Vertical spacing between the notification card and the action buttons (share/bookmark).
 * This constant makes it easy to adjust the gap between the card and buttons.
 */
private const val NOTIFICATION_CARD_TO_BUTTONS_SPACING_DP = 5

@Composable
fun RecognitionNotification(
    image: ImageModel,
    isLoading: Boolean,
    isExpanded: Boolean = false,
    onExpandChange: (Boolean) -> Unit = {},
    expandedContent: (@Composable () -> Unit)? = null,
    modifier: Modifier = Modifier,
    topContentPadding: Dp = EXPANDED_NOTIFICATION_STARTING_POSITION_DP.dp // Default to legacy value for backward compatibility
) {
    // Calculate available screen height
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val navigationBarHeight = with(density) {
        WindowInsets.navigationBars.getBottom(density).toDp()
    }

    // Check if running in official app (internal feature)
    val context = LocalContext.current
    val showActionButtons = remember { AppDetection.isOfficialApp(context) }

    // Calculate max height for expanded notification
    // Must reserve space for action buttons and spacer to ensure buttons remain visible when expanded
    // Uses percentage-based calculation to scale across all screen sizes (phones, tablets, 4K TVs)
    val ActionButtonsHeight = if (showActionButtons) 58.dp else 0.dp // Height for bookmark/share buttons (48dp) + spacer (10dp)
    val NotificationBottomOffset = NOTIFICATION_BOTTOM_OFFSET_DP.dp // Distance from bottom of view
    val CardToButtonsSpacing = if (showActionButtons) NOTIFICATION_CARD_TO_BUTTONS_SPACING_DP.dp else 0.dp // Spacer between card and buttons

    val maxExpandedHeight = with(density) {
        val screenHeight = configuration.screenHeightDp.dp
        
        // Responsive calculation based on screen size:
        // - Reserve space for top padding, navigation bar, spacer, and action buttons (fixed)
        // - Reserve percentage-based bottom margin to ensure buttons remain visible on all screen sizes
        // - Cap expanded height at 60% of screen height to ensure proper spacing
        val fixedReservedSpace = topContentPadding + navigationBarHeight + CardToButtonsSpacing + ActionButtonsHeight
        val bottomMarginPercentage = 0.15f // Reserve 15% of screen height for bottom margin (scales with screen size)
        val bottomMargin = screenHeight * bottomMarginPercentage
        
        val totalReservedSpace = fixedReservedSpace + bottomMargin
        val availableHeight = screenHeight - totalReservedSpace
        
        // Cap at 60% of screen height to ensure proper proportions on all devices
        // This line sets an upper limit (cap) on how tall the expanded notification card is allowed to be,
        // regardless of how much vertical space is available on the screen.
        // 
        // Explanation:
        // - `screenHeight` is the height of the available screen in dp.
        // - Multiplying by 0.10f (10%) means the max card height CANNOT exceed 10% of the screen's height.
        // - So, if your screen is 2000dp tall, maxHeightCap = 200dp.
        // - Later, availableHeight.coerceAtMost(maxHeightCap) ensures the card never gets taller than this cap.
        // 
        // Why does changing this sometimes not seem to affect the visible UI?
        // - If your `availableHeight` (the space after accounting for nav bar, top padding, etc) is LESS THAN `maxHeightCap`,
        //   then the actual card height is limited by availableHeight, NOT by the cap.
        // - Example: If availableHeight = 150.dp and maxHeightCap = 200.dp, your card max is 150.dp.
        //   Tweaking maxHeightCap to 200 or 1000 has no visible effect until availableHeight exceeds the cap.
        // - Only when availableHeight > maxHeightCap does the cap become the limiting factor for card height.
        // 
        // If you want to test the effect, try lowering the percentage to something smaller (like 0.05f for 5%).
        val maxHeightCap = screenHeight * 0.80f 
        
        availableHeight.coerceAtMost(maxHeightCap).coerceAtLeast(300.dp)
    }

    val previewCardVerticalSize = 130.dp // Taller to fit 2 lines of description like iOS

    // Position the entire Column (card + buttons) consistently within the IRKitLens view rectangle
    // Consumer apps are responsible for positioning IRKitLens to avoid overlapping with their UI elements
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = NotificationBottomOffset)
    ) {
        // When expanded, add a flexible spacer that pushes content to bottom when small
        // but allows content to grow from bottom up when larger
        if (isExpanded) {
            Spacer(modifier = Modifier.weight(1f, fill = false))
        }
        
        Card(
            modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = 16.dp,
                end = 16.dp,
                top = if (isExpanded) 0.dp else 0.dp // No top padding when expanded - let spacer handle positioning
            )
            .then(
                if (isExpanded) {
                    // When expanded, wrap content height but constrain to max height
                    // This allows small content to size naturally while large content scrolls
                    Modifier.wrapContentHeight().heightIn(max = maxExpandedHeight)
                } else {
                    // When collapsed, use fixed height
                    Modifier.heightIn(max = previewCardVerticalSize)
                }
            )
            .then(
                // Only make clickable when collapsed - when expanded, don't allow closing by tapping
                if (!isExpanded) {
                    Modifier.clickable {
                        android.util.Log.d("RecognitionNotification", "Card clicked. isExpanded=$isExpanded, hasExpandedContent=${expandedContent != null}")
                        onExpandChange(!isExpanded)
                    }
                } else {
                    Modifier
                }
            ),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2C2C2E)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = if (isExpanded) {
                Modifier.padding(vertical = 0.dp)
            } else {
                Modifier
            }
        ) {
            // Only show drag indicator if expandedContent is available and not expanded
            if (!isExpanded && expandedContent != null) {
                GripView(
                    onClick = {
                        onExpandChange(!isExpanded)
                    }
                )
            }

            if (!isExpanded) {
                CollapsedContent(
                    image = image
                )
            }

            // Expanded content if available and expanded
            if (isExpanded && expandedContent != null) {
                expandedContent()
            }
        }
    }

        // Automatically show action buttons if official app (internal feature)
        // Buttons are positioned at the bottom of the Column with consistent spacing
        if (showActionButtons) {
            Spacer(modifier = Modifier.height(CardToButtonsSpacing))
            NotificationActionButtons(
                image = image,
                onSaveClick = { IRKit.invokeSaveCallback(it) },
                onShareClick = { IRKit.invokeShareCallback(it) }
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun RecognitionNotificationPreview() {
    val previewImage = ImageModel.FullImage(
        title = "Mock Recognition Result",
        description = "Mock description that is long enough to show multiple lines of text and demonstrate the ellipsis behavior",
        imageId = "",
        displayImageUrl = "https://upload.wikimedia.org/wikipedia/en/f/f7/Inside_Out_2_poster.jpg",
        campaignId = 1,
        campaignName = "1",
        products = emptyList(),
        metaItems = emptyList(),
        location = null,
        imageSize = 0,
        imageHeight = 0,
        imageWidth = 0,
        bucketName = "",
        trackingId = "",
        imageUser = UserDto(
            email = "",
            phone = "",
            userId = 2,
            fullName = "",
            userName = "",
            profileUrl = ""
        ),
        isFromManualCapture = false,
        imageStatus = ImageStatus.PUBLISH
    )

    var isExpanded by remember { mutableStateOf(false) }

    RecognitionNotification(
        image = previewImage,
        isLoading = false,
        isExpanded = isExpanded,
        onExpandChange = { isExpanded = it },
        expandedContent = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Expanded Content",
                    style = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = "This is some sample expanded content to show how it looks.",
                    modifier = Modifier.padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
private fun RecognitionNotificationExpandedPreview() {
    val previewImage = ImageModel.FullImage(
        title = "Mock Recognition Result",
        description = "Mock description that is long enough to show multiple lines of text and demonstrate the ellipsis behavior",
        imageId = "",
        displayImageUrl = "https://upload.wikimedia.org/wikipedia/en/f/f7/Inside_Out_2_poster.jpg",
        campaignId = 1,
        campaignName = "1",
        products = emptyList(),
        metaItems = emptyList(),
        location = null,
        imageSize = 0,
        imageHeight = 0,
        imageWidth = 0,
        bucketName = "",
        trackingId = "",
        imageUser = UserDto(
            email = "",
            phone = "",
            userId = 2,
            fullName = "",
            userName = "",
            profileUrl = ""
        ),
        isFromManualCapture = false,
        imageStatus = ImageStatus.PUBLISH
    )

    var isExpanded by remember { mutableStateOf(true) }

    RecognitionNotification(
        image = previewImage,
        isLoading = false,
        isExpanded = isExpanded,
        onExpandChange = { isExpanded = it },
        expandedContent = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Expanded Content",
                    style = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = "This is some sample expanded content to show how it looks.",
                    modifier = Modifier.padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    )
}
