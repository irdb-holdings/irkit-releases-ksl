/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.irdb.irkitui;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.irdb.irkitui";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "production";
  // Field from default config.
  public static final String LIBRARY_CLIENT = "KSL";
  // Field from default config.
  public static final String LIBRARY_VERSION = "1.0.0";
}
