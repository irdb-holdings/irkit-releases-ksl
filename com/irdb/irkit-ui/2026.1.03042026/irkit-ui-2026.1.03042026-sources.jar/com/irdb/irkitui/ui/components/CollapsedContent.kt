package com.irdb.irkitui.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.irdb.irkit.ImageModel
import com.irdb.irkit.enums.CardTypes
import com.irdb.irkit.getCardTypeEmum
import com.irdb.irkitui.ui.baseComponents.ContentDescription
import com.irdb.irkitui.ui.baseComponents.ContentTitleForCollapsed

@Composable
fun CollapsedContent(
    image: ImageModel,
    isExpanded: Boolean = true,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .padding(horizontal = 5.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ThumbNail(image, isExpanded)

        // Text content
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            when (image.getCardTypeEmum()) {
                CardTypes.Contact -> CollapsedContactContent(image)
                else -> {
                    UserNameRow(image)
                    ContentTitleForCollapsed(image.getImageTitle())
                    ContentDescription(image.description)
                }
            }
        }
    }
}
