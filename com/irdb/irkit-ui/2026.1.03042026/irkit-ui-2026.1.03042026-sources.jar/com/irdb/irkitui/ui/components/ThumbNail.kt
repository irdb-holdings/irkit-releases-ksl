package com.irdb.irkitui.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.irdb.irkit.ImageModel
import com.irdb.irkitui.ui.baseComponents.rememberImageLoader

@Composable
fun ThumbNail(image: ImageModel, isExpanded: Boolean) {
    val imageLoader = rememberImageLoader()

    Box(
        modifier = Modifier
            .size(96.dp)
            .background(
                color = Color.White,
                shape = RoundedCornerShape(
                    topStart = 15.dp,
                    bottomStart = 15.dp,
                    topEnd = if (isExpanded) 15.dp else 8.dp,
                    bottomEnd = if (isExpanded) 15.dp else 8.dp
                )
            )
    ) {
        AsyncImage(
            model = image.displayImageUrl,
            contentDescription = null,
            imageLoader = imageLoader,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(
                    RoundedCornerShape(
                        topStart = 15.dp,
                        bottomStart = 15.dp,
                        topEnd = if (isExpanded) 15.dp else 8.dp,
                        bottomEnd = if (isExpanded) 15.dp else 8.dp
                    )
                )
                .align(Alignment.Center)
        )
    }
}
