package com.irdb.irkitui.ui.baseComponents

import coil.ImageLoader

/**
 * Entry point interface for accessing the configured ImageLoader.
 * 
 * The app should provide an implementation of this interface via Hilt
 * to ensure all image loading uses the properly configured ImageLoader
 * (with SSL handling, proxy support, etc.).
 * 
 * Usage in the app:
 * ```kotlin
 * @EntryPoint
 * @InstallIn(SingletonComponent::class)
 * interface ImageLoaderEntryPoint : com.irdb.irkitui.ui.baseComponents.ImageLoaderEntryPoint {
 *     override fun imageLoader(): ImageLoader
 * }
 * ```
 */
interface ImageLoaderEntryPoint {
    fun imageLoader(): ImageLoader
}

