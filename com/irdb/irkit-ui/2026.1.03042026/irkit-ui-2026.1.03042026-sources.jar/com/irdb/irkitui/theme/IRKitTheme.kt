package com.irdb.irkitui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * Combined theme data class containing colors and typography.
 *
 * This is the main theme object that clients configure in their
 * ClientConfigBase implementation.
 */
data class IRKitTheme(
    val colors: IRKitColorScheme,
    val typography: IRKitTypography
)

/**
 * CompositionLocal for providing IRKitColorScheme through the composition tree.
 * Falls back to Dark preset if no provider is found (prevents crashes during recomposition).
 */
val LocalIRKitColors = staticCompositionLocalOf<IRKitColorScheme> {
    IRKitThemePresets.Dark.colors
}

/**
 * CompositionLocal for providing IRKitTypography through the composition tree.
 * Falls back to default typography if no provider is found (prevents crashes during recomposition).
 */
val LocalIRKitTypography = staticCompositionLocalOf<IRKitTypography> {
    IRKitThemePresets.Dark.typography
}

/**
 * Object for accessing the current theme values in composables.
 *
 * Usage:
 * ```kotlin
 * @Composable
 * fun MyComponent() {
 *     Box(modifier = Modifier.background(IRKitTheme.colors.primary)) {
 *         Text(
 *             text = "Hello",
 *             color = IRKitTheme.colors.textPrimary,
 *             style = IRKitTheme.typography.bodyLarge
 *         )
 *     }
 * }
 * ```
 */
object IRKitThemeAccessor {
    /**
     * Current color scheme from the composition.
     */
    val colors: IRKitColorScheme
        @Composable
        @ReadOnlyComposable
        get() = LocalIRKitColors.current

    /**
     * Current typography from the composition.
     */
    val typography: IRKitTypography
        @Composable
        @ReadOnlyComposable
        get() = LocalIRKitTypography.current
}

/**
 * Provides the IRKit theme to the composition tree.
 *
 * This is typically called internally by IRKitUITheme, but can be used
 * directly for testing or custom setups.
 *
 * @param theme The IRKitTheme to provide
 * @param content The composable content that will have access to the theme
 */
@Composable
fun IRKitThemeProvider(
    theme: IRKitTheme,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalIRKitColors provides theme.colors,
        LocalIRKitTypography provides theme.typography,
        content = content
    )
}

/**
 * Provides the IRKit theme using separate color scheme and typography.
 *
 * @param colors The color scheme to provide
 * @param typography The typography to provide
 * @param content The composable content that will have access to the theme
 */
@Composable
fun IRKitThemeProvider(
    colors: IRKitColorScheme,
    typography: IRKitTypography,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalIRKitColors provides colors,
        LocalIRKitTypography provides typography,
        content = content
    )
}
