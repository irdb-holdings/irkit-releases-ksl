package com.irdb.irkitui.ui.baseComponents

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun ContentTitle(
    title: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    Text(
        text = title,
        style = TextStyle(
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = color
        ),
        modifier = modifier
    )
}

@Composable
fun ContentTitleForCollapsed(
    title: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    Text(
        text = title,
        style = TextStyle(
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = color
        ),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun ContentTitlePreview() {
    IRKitUITheme {
        ContentTitle(title = "Sample Image Title")
    }
}

@Preview(showBackground = true)
@Composable
fun ContentTitleCollapsedPreview() {
    IRKitUITheme {
        ContentTitleForCollapsed(
            title = "A Very Long Preview Title That Should Demonstrate Text Overflow Handling in Various Components"
        )
    }
}
