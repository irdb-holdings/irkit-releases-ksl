package com.irdb.irkitui.theme

import androidx.compose.ui.graphics.Color

// SaveButton Colors
val SaveButtonIconColor = Color.White
val SaveButtonTextColor = Color.White

// ButtonCountText Colors
val ButtonCountTextColor = Color.White

// Unified action button color used for chips, dropdowns, and action buttons
val ACTION_BUTTON_COLOR = Color(0xFF3A3A3A)

// AddCustomFieldButton Colors
val AddCustomFieldButtonIconColor = Color.White
val AddCustomFieldButtonTextColor = Color.White
val AddCustomFieldButtonBackgroundColor = ACTION_BUTTON_COLOR

// EditCustomField Colors
val EditCustomFieldBackgroundColor = Color(0xFF3A3A3A)
val EditCustomFieldTextColor = Color.White
val EditCustomFieldLabelColor = Color(0xFF8E8E93)

// Tag related colors
val TagChipBackgroundColor = ACTION_BUTTON_COLOR
val TagChipTextColor = Color.White
