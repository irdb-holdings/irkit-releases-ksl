package com.irdb.irkitui

import android.content.Intent
import kotlinx.coroutines.delay
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.irdb.analytics.AnalyticsClient
import com.irdb.analytics.ButtonSource
import com.irdb.analytics.ButtonType
import com.irdb.analytics.StatusType
import com.irdb.analytics.ViewSource
import com.irdb.analytics.ViewType
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.irdb.irkit.IREngine
import com.irdb.irkit.IRKit
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.ProductInCampaignDto
import com.irdb.irkit.enums.CardTypes
import com.irdb.irkit.getCardTypeEmum
import com.irdb.irkitui.components.BottomBar
import com.irdb.irkitui.components.CameraPreview
import com.irdb.irkitui.components.ModeSelectorView
import com.irdb.irkitui.components.ScanningEffect
import com.irdb.irkitui.theme.IRKitUITheme
import com.irdb.irkitui.ui.baseComponents.ContentDescription
import com.irdb.irkitui.ui.baseComponents.ContentTitle
import com.irdb.irkitui.configuration.ExpandedCloseButtonPlacement
import com.irdb.irkitui.ui.baseComponents.ShadowButton
import com.irdb.irkitui.ui.bottomsheets.CreateIRCodeBottomSheet
import com.irdb.irkitui.ui.components.ContentMetaLinksView
import com.irdb.irkitui.ui.components.ExpandedContentMetaTable
import com.irdb.irkitui.ui.components.FullSizeImage
import com.irdb.irkitui.ui.components.ProductItemView
import com.irdb.irkitui.ui.dialogs.ircode.ImageDetailsView
import com.irdb.irkitui.ui.resultCards.RecognitionNotification
import com.irdb.irkitui.ui.resultCards.ResultCardProductView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream

/**
 * IRKitLens - Enhanced camera component for IRKit-UI library with integrated controls.
 *
 * This implementation matches the main app's behavior:
 * - LIVE mode: Shows mode selector, continuous processing via IREngine, NO bottom bar
 * - SNAPSHOT mode: Shows mode selector AND bottom bar for manual capture
 * - Mode selector appears at top, bottom bar (when visible) at bottom
 * - Handles torch state internally
 * - Integrates with IREngine for automatic image processing in LIVE mode
 *
 * @param irEngine The IR recognition engine instance
 * @param initialCameraMode Initial camera mode (default LIVE)
 * @param modifier Modifier for the camera container
 * @param useFitScaleType Whether to use FIT scale type (default FILL)
 * @param onImageCaptured Callback when an image is captured with the bitmap (optional)
 * @param onSelectImage Callback when gallery/select image is pressed (optional, uses internal picker if null)
 * @param onTorchToggle Callback when torch is toggled (optional)
 * @param showGalleryButton Whether to show gallery button (default true)
 * @param showAddButton Whether to show the + button for creator mode (default true)
 * @param enableIRCodeCreation Whether to enable IRCODE creation features (default false)
 * @param topContentPadding Top padding for mode selector and + button (default 4.dp)
 * @param onImageRecognized Callback when an image is recognized with the ImageModel (optional)
 * @param onImageNotRecognized Callback when an image is not recognized with the Bitmap (optional)
 * @param onProductClicked Callback when a product item is clicked in result views (optional)
 * @param onCreatorModeRequested Callback when user requests creator mode (optional, default switches to CREATOR mode)
 * @param onChoosePhotoForCreation Callback when user chooses photo from gallery for IRCODE creation (optional, uses default recognition flow if null)
 * @param onTakePhotoForCreation Callback when user selects "Take Photo" for IRCODE creation (optional, uses default CREATOR mode if null)
 * @param externalCapturedBitmap External bitmap to display (optional, overrides internal capturedBitmap if provided)
 * @param externalIsSearching External searching state (optional, overrides internal isSearching if provided)
 * @param analyticsCompanyName Company name for analytics (e.g., "ircode")
 *                              Default: "ircode" if not provided
 * @param analyticsAppName App/collection name for analytics (e.g., "irdbMain", "testapp")
 *                         Default: "irdbMain" if not provided
 *                         Session source is built as: "ANDROID-{companyName}-{appName}"
 *
 * Drop-in Features:
 * - Gallery image picker is integrated - no need to implement onSelectImage callback
 * - ImageDetailsDialog shows automatically for recognized images
 * - All image processing and recognition happens internally
 */
@Composable
fun IRKitLens(
    irEngine: IREngine,
    initialCameraMode: CameraMode = CameraMode.LIVE,
    modifier: Modifier = Modifier,
    useFitScaleType: Boolean = false,
    onImageCaptured: ((Bitmap) -> Unit)? = null,
    onSelectImage: (() -> Unit)? = null,
    onTorchToggle: ((Boolean) -> Unit)? = null,
    showGalleryButton: Boolean = true,
    showAddButton: Boolean = true,
    enableIRCodeCreation: Boolean = false,
    topContentPadding: Dp = 4.dp,
    onImageRecognized: ((ImageModel) -> Unit)? = null,
    onImageNotRecognized: ((Bitmap) -> Unit)? = null,
    onProductClicked: ((ImageModel, ProductInCampaignDto) -> Unit)? = null,
    onCreatorModeRequested: (() -> Unit)? = null,
    onChoosePhotoForCreation: (() -> Unit)? = null,
    onTakePhotoForCreation: (() -> Unit)? = null,
    externalCapturedBitmap: Bitmap? = null,
    externalIsSearching: Boolean? = null,
    analyticsCompanyName: String = "ircode",
    analyticsAppName: String = "irdbMain",
    onImageTapForFullDetails: ((ImageModel) -> Unit)? = null,
    showModeSelector: Boolean = false
) {
    val enableModeSelector = showModeSelector
    val context = LocalContext.current
    var currentCameraMode by remember { mutableStateOf(initialCameraMode) }
    var previousCameraMode by remember { mutableStateOf(CameraMode.LIVE) }
    var torchState by remember { mutableStateOf(false) }
    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isSearching by remember { mutableStateOf(false) }
    var isCapturingForCreation by remember { mutableStateOf(false) }

    // Use external bitmap/searching state if provided, otherwise use internal
    val displayBitmap = externalCapturedBitmap ?: capturedBitmap
    val displayIsSearching = externalIsSearching ?: isSearching
    var isExpanded by remember { mutableStateOf(false) }
    var showCreateIRCodeBottomSheet by remember { mutableStateOf(false) }
    var showIRCodeNotFoundTopSheet by remember { mutableStateOf(false) }
    var showImageDetailsDialog by remember { mutableStateOf<ImageModel?>(null) }
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    var isLandscape by remember { mutableStateOf(false) }

    // Detect physical device rotation via accelerometer sensor.
    // OrientationEventListener works even when the Activity is locked to portrait mode,
    // unlike LocalConfiguration which never reports landscape when orientation is locked.
    DisposableEffect(context) {
        val orientationListener = object : android.view.OrientationEventListener(context) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                // Landscape ranges: 60-120° (rotated left) and 240-300° (rotated right)
                val newIsLandscape = (orientation in 60..120) || (orientation in 240..300)
                if (newIsLandscape != isLandscape) {
                    isLandscape = newIsLandscape
                }
            }
        }
        orientationListener.enable()
        onDispose { orientationListener.disable() }
    }

    // Timer state variables for timeToDisplay tracking
    var compressedNotificationStartTime by remember { mutableStateOf<Long?>(null) }
    var expandedNotificationStartTime by remember { mutableStateOf<Long?>(null) }
    var fullNotificationStartTime by remember { mutableStateOf<Long?>(null) }
    var currentTimedImageId by remember { mutableStateOf<String?>(null) }
    var currentScanTrackingId by remember { mutableStateOf<String?>(null) } // scanTrackingID from spec - links all events within a scanned asset

    // Initialize analytics automatically on first composition (hidden from client)
    LaunchedEffect(Unit) {
        IRKitUI.initialize(context, analyticsCompanyName, analyticsAppName)
    }

    // Lens-scoped analytics session + lens-visibility flag.
    //
    // Session boundaries for this product are "lens open" and "lens close".
    // Every time the user opens the lens (FAB tap), we open a fresh analytics
    // session (new sessionTrackingID, emit SESSION_STARTED). When the lens is
    // disposed (back button, host finishes the hosting activity, composition
    // removed), we sync-emit SESSION_STOPPED and flush so the session_ended
    // event is the last thing that goes out — or, if the network is down,
    // it's sitting in the SQLite cache ready to drain on the next lens open.
    //
    // IRKitUI.initialize is called synchronously here (idempotent) so we
    // never hit AnalyticsClient.getInstance() before it's ready.
    DisposableEffect(Unit) {
        IRKitUI.isLensVisible = true
        IRKitUI.hasLensEverBeenOpened = true

        try {
            IRKitUI.initialize(context, analyticsCompanyName, analyticsAppName)
            val analytics = AnalyticsClient.getInstance()

            // Drain any SQLite-cached events from previous sessions in the background.
            // Fire-and-forget on the composition scope: flush() is unbounded and can
            // sit on a slow network for seconds — blocking the main thread on lens
            // open would risk an ANR. Cached events carry their own timestamps, so
            // late delivery doesn't affect server-side ordering.
            scope.launch(Dispatchers.IO) {
                try {
                    analytics.flush()
                    Log.d("IRKitLens", "Cached events from previous sessions flushed")
                } catch (e: Exception) {
                    Log.w("IRKitLens", "Pre-session cache flush failed: ${e.message}")
                }
            }

            analytics.onSessionStarted()
            analytics.trackStatusEvent(
                statusType = StatusType.SESSION_STARTED,
                additionalParams = mapOf(
                    "timestamp" to System.currentTimeMillis(),
                    "appSource" to AnalyticsClient.APP_SOURCE,
                    "duration" to 0L
                )
            )
            Log.d("IRKitLens", "📊 SESSION_STARTED emitted for lens open")
        } catch (e: Exception) {
            Log.w("IRKitLens", "Failed to open analytics session on lens enter: ${e.message}", e)
        }

        onDispose {
            IRKitUI.isLensVisible = false
            try {
                val analytics = AnalyticsClient.getInstance()
                // Bounded sync emit + flush. 2 s cap protects the Main thread
                // if the network is slow — the event is already in the SQLite
                // cache from trackStatusEventSync and will drain on next open
                // if the flush times out here.
                runBlocking(Dispatchers.IO) {
                    analytics.trackStatusEventSync(
                        statusType = StatusType.SESSION_STOPPED,
                        additionalParams = mapOf(
                            "duration" to analytics.getGlobalSessionDuration(),
                            "sessionEndTime" to System.currentTimeMillis()
                        )
                    )
                    val flushed = analytics.flushSync(timeoutMs = 2000L)
                    Log.d("IRKitLens", "📊 SESSION_STOPPED persisted; flushed=$flushed")
                }
            } catch (e: Exception) {
                Log.w("IRKitLens", "Failed to close analytics session on lens dispose: ${e.message}", e)
            }
        }
    }

    // Fetch environment info (IR Engine URL + API key) and lens config (search string, model)
    // every time the lens becomes visible. Both calls were previously made at Application
    // startup via IRKit.initialize() / IRKitUI.initialize(); they are deferred here so that
    // no REST API calls are made before the lens opens. Running them in parallel minimises
    // the latency hit on first scan. The 401-retry path in IREngine handles the rare case
    // where a scan fires before either call completes.
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            Log.d("IRKitLens", "Lens visible — refreshing environment and lens config")
            coroutineScope {
                // Must use IO: getEnvironmentInformation performs HTTP on the caller's dispatcher;
                // this block inherits the Main dispatcher from the composition coroutine context.
                launch(Dispatchers.IO) {
                    try {
                        if (IRKit.isInitialized()) {
                            IRKit.getInstance().getEnvironmentInformation()
                            Log.d("IRKitLens", "Environment information refreshed")
                        }
                    } catch (e: Exception) {
                        Log.w("IRKitLens", "getEnvironmentInformation failed: ${e.message}")
                    }
                }
                launch {
                    IRKitUI.refreshLensConfig()
                }
            }
            irEngine.reloadSegmentationModelIfChanged()
        }
    }

    // CRITICAL: Initialize camera on first composition
    LaunchedEffect(irEngine) {
        Log.d("IRKitLens", "Initializing camera with lifecycle owner")
        irEngine.initializeCamera(lifecycleOwner, irEngine.previewView)
    }

    // Image picker launcher - integrated inside IRKitLens for drop-in functionality
    // Note: No permissions needed - ActivityResultContracts.GetContent() uses scoped storage
    val selectImageLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { selectedUri ->
            scope.launch {
                try {
                    // Load bitmap from URI
                    val selectedBitmap = withContext(Dispatchers.IO) {
                        try {
                            context.contentResolver.openInputStream(selectedUri)?.use { inputStream ->
                                BitmapFactory.decodeStream(inputStream)
                            }
                        } catch (e: Exception) {
                            Log.e("IRKitLens", "Failed to load image from URI", e)
                            null
                        }
                    }

                    selectedBitmap?.let { bitmap ->
                        // Process the selected image through IREngine
                        try {
                            isSearching = true

                            // Transform the bitmap (scale down slightly like captured images)
                            val matrix = android.graphics.Matrix().apply {
                                postScale(0.8f, 0.8f)
                                val tx = (bitmap.width * 0.1f)
                                val ty = (bitmap.height * 0.1f)
                                postTranslate(tx, ty)
                            }

                            val transformedBitmap = Bitmap.createBitmap(
                                bitmap,
                                0,
                                0,
                                bitmap.width,
                                bitmap.height,
                                matrix,
                                true
                            )

                            // Keep a mutable copy for display
                            val capturedImage = transformedBitmap.copy(
                                transformedBitmap.config ?: Bitmap.Config.ARGB_8888,
                                true
                            )
                            capturedBitmap = capturedImage

                            // Compress to JPEG and convert to byte array
                            withContext(Dispatchers.IO) {
                                try {
                                    val bytes = ByteArrayOutputStream()
                                    transformedBitmap.compress(Bitmap.CompressFormat.JPEG, 60, bytes)
                                    val imageData = bytes.toByteArray()

                                    // Process image data using IREngine
                                    val imageSearchResult = irEngine.processImageData(imageData)

                                    // Track analytics for snapshot scan submission from gallery
                                    trackSnapshotScanSubmission(imageSearchResult, currentCameraMode)

                                    withContext(Dispatchers.Main) {
                                        if (imageSearchResult.isSuccess) {
                                            Log.d("IRKitLens", "Image recognized successfully from gallery")
                                            IRKit.getInstance().getImageRecognitionObserver()
                                                .handleImageRecognized(imageSearchResult)

                                            // Show ImageDetailsDialog for recognized images
                                            imageSearchResult.matchedImage?.let { imageModel ->
                                                showImageDetailsDialog = imageModel
                                                onImageRecognized?.invoke(imageModel)
                                            }
                                        } else {
                                            Log.d("IRKitLens", "Image not recognized from gallery")

                                            // Track "Scan Result — No Match" analytics event
                                            // For gallery images (isFromGallery = true)
                                            trackNoMatchScanResult(
                                                imageSearchResult = imageSearchResult,
                                                cameraMode = currentCameraMode,
                                                isFromGallery = true
                                            )

                                            IRKit.getInstance().getImageRecognitionObserver()
                                                .handleImageNotRecognized(imageSearchResult)
                                            onImageNotRecognized?.invoke(capturedImage)
                                        }
                                        isSearching = false
                                    }
                                } catch (e: Exception) {
                                    Log.e("IRKitLens", "Error processing selected image", e)
                                    withContext(Dispatchers.Main) {
                                        isSearching = false
                                    }
                                } finally {
                                    transformedBitmap.recycle()
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("IRKitLens", "Error transforming selected image", e)
                            isSearching = false
                        } finally {
                            // Clean up original bitmap
                            if (!bitmap.isRecycled) {
                                bitmap.recycle()
                            }
                        }
                    } ?: run {
                        Log.e("IRKitLens", "Failed to load bitmap from selected URI")
                    }
                } catch (e: Exception) {
                    Log.e("IRKitLens", "Error handling selected image", e)
                }
            }
        }
    }

    // Observe the image recognition results from IRKit
    val imageRecognitionObserver = remember { IRKit.getInstance().getImageRecognitionObserver() }
    val lastSeenImage by imageRecognitionObserver.lastSeenImage.collectAsState()
    val isLoadingDetails by imageRecognitionObserver.isLoadingDetails.collectAsState()

    // Track "not found" state for top sheet
    val isNotFound = lastSeenImage is ImageModel.NotRecognized

    // Stable notification image — prevents flicker when lastSeenImage briefly becomes null
    // during recognition pipeline. Content swaps smoothly when a new IRCODE is recognized.
    // Auto-dismisses via debounced null detection (3s LIVE / 500ms other modes).
    var displayedNotificationImage by remember { mutableStateOf<ImageModel?>(null) }
    // State for pending scan-to-site auto-open (openUrl is defined later in the composable)
    var pendingAutoOpenImage by remember { mutableStateOf<ImageModel?>(null) }

    // Clear stale notification state when returning from background (not on initial launch)
    var hasBeenPaused by remember { mutableStateOf(false) }
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) {
                hasBeenPaused = true
            }
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME && hasBeenPaused) {
                if (displayedNotificationImage != null) {
                    Log.d("IRKitLens", "Resuming from background — clearing stale notification")
                    displayedNotificationImage = null
                    isExpanded = false
                    imageRecognitionObserver.clearLastSeenImage()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(lastSeenImage, currentCameraMode) {
        val newImage = lastSeenImage
        if (newImage != null && newImage !is ImageModel.NotRecognized) {
            // Skip compressed card for scan-to-site when feature flag is enabled
            if (com.irdb.irkit.config.ScanToSiteConfig.enableAutoLaunchSTS && newImage.isScanToSite) {
                if (newImage.showInChromeTab) {
                    Log.d("IRKitLens", "Skip compressed: queuing auto-open for scan-to-site Chrome tab")
                    pendingAutoOpenImage = newImage
                    // Don't set displayedNotificationImage — no card shown
                } else if (newImage.showSmartView) {
                    Log.d("IRKitLens", "Skip compressed: auto-expanding SmartView for scan-to-site")
                    // Show expanded WebView directly — compressed card never appears
                    displayedNotificationImage = newImage
                    isExpanded = true
                }
            } else {
                // Normal path — show compressed card
                displayedNotificationImage = newImage
            }
        } else if (currentCameraMode == CameraMode.LIVE && displayedNotificationImage != null) {
            // When expanded with skip-compressed for a scan-to-site card, don't auto-dismiss — user must close manually
            if (isExpanded && com.irdb.irkit.config.ScanToSiteConfig.enableAutoLaunchSTS
                && displayedNotificationImage?.isScanToSite == true) {
                return@LaunchedEffect
            }
            // LIVE mode: use a longer debounce (3s) to survive the removeOldImages timer
            // + re-recognition cycle. If the camera is still on the image, the engine
            // re-recognizes within ~1-2s → this coroutine gets cancelled → no flicker.
            // If the camera moved away, no re-recognition → delay completes → dismiss.
            delay(3000)
            displayedNotificationImage = null
        } else {
            // Non-LIVE modes or no notification showing: short debounce
            delay(500)
            displayedNotificationImage = null
        }
    }
    // Whether the notification should be visible — driven by our stable state, not raw lastSeenImage
    val isNotificationShowing = displayedNotificationImage != null

    // NOTE: timeToDisplay is now included automatically in view events via the buffering system
    // No need for separate status events - removed sendTimeToDisplayEvent function

    // Function to open URLs in browser
    fun openUrl(
        url: String,
        buttonTitle: String? = null,
        isProductButton: Boolean = false,
        link: com.irdb.irkit.dto.MetaContent.Link? = null,
        image: ImageModel? = null,
        viewSource: ViewSource? = null,
        viewType: String? = null
    ) {
        val currentImage = image ?: lastSeenImage
        val currentImageId = currentImage?.imageId?.takeIf { it.isNotEmpty() }
        var trackFailedNavigation: (() -> Unit)? = null

        // Track button press event BEFORE opening URL
        if (isProductButton && currentImage != null) {
            // Capture values BEFORE launching coroutine to avoid race condition
            // (timers are cleared below, but coroutine may execute after that)
            val determinedViewSource = viewSource ?: when (currentCameraMode) {
                CameraMode.LIVE -> ViewSource.LIVE_SCAN
                CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                CameraMode.CREATOR -> ViewSource.CREATOR
            }
            val determinedViewType = viewType ?: if (expandedNotificationStartTime != null) {
                "expanded"
            } else {
                "full" // Assume full view if not expanded notification
            }

            scope.launch {
                // Track analytics - duration is automatically determined from active timer
                AnalyticsClient.getInstance().trackButtonPressedEvent(
                    buttonType = ButtonType.PRODUCT,
                    buttonSource = ButtonSource.IRCODE_VIEW,
                    buttonTitle = buttonTitle,
                    buttonLink = url,
                    linkToFollow = url,
                    imageId = currentImageId,
                    failed = false,
                    additionalParams = mapOf(
                        "viewSource" to determinedViewSource.value,
                        "viewType" to determinedViewType
                    )
                )
            }
        } else if (link != null && currentImage != null) {
            // Track link click analytics
            val determinedViewSource = viewSource ?: when (currentCameraMode) {
                CameraMode.LIVE -> ViewSource.LIVE_SCAN
                CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                CameraMode.CREATOR -> ViewSource.CREATOR
            }

            val determinedViewType = viewType ?: if (expandedNotificationStartTime != null) {
                "expanded"
            } else {
                "full"
            }

            trackFailedNavigation = trackLinkClick(
                link = link,
                image = currentImage,
                viewSource = determinedViewSource,
                viewType = determinedViewType,
                cameraMode = currentCameraMode
            )
        }

        // Capture values for failed navigation tracking BEFORE clearing timers
        val failedViewSource = viewSource ?: when (currentCameraMode) {
            CameraMode.LIVE -> ViewSource.LIVE_SCAN
            CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
            CameraMode.CREATOR -> ViewSource.CREATOR
        }
        val failedViewType = viewType ?: if (expandedNotificationStartTime != null) "expanded" else "full"

        // NOTE: timeToDisplay is now sent automatically via buffering system
        // Clear timers
        expandedNotificationStartTime = null
        compressedNotificationStartTime = null
        currentTimedImageId = null
        currentScanTrackingId = null

        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
            Log.d("IRKitLens", "Opening URL: $url")
        } catch (e: Exception) {
            Log.e("IRKitLens", "Failed to open URL: $url", e)
            // Track failed navigation
            if (isProductButton && currentImage != null) {
                scope.launch {
                    AnalyticsClient.getInstance().trackButtonPressedEvent(
                        buttonType = ButtonType.PRODUCT,
                        buttonSource = ButtonSource.IRCODE_VIEW,
                        buttonTitle = buttonTitle,
                        buttonLink = url,
                        linkToFollow = url,
                        imageId = currentImageId,
                        failed = true,
                        additionalParams = mapOf(
                            "viewSource" to failedViewSource.value,
                            "viewType" to failedViewType,
                            "category" to "deeplinkError"
                        )
                    )
                }
            } else if (trackFailedNavigation != null) {
                // Call the failed navigation tracking function returned from trackLinkClick
                trackFailedNavigation()
            }
        }
    }

    // Auto-open scan-to-site Chrome tab (deferred because openUrl is defined above)
    LaunchedEffect(pendingAutoOpenImage) {
        val autoImage = pendingAutoOpenImage ?: return@LaunchedEffect
        val link = autoImage.getLinks()
        if (link != null && link.url.isNotEmpty()) {
            Log.d("IRKitLens", "Skip compressed: auto-opening scan-to-site in Chrome: ${link.url}")
            openUrl(url = link.url, link = link, image = autoImage)
            imageRecognitionObserver.clearLastSeenImage()
        }
        pendingAutoOpenImage = null
    }

    // Handle camera mode changes - enable/disable continuous recognition
    LaunchedEffect(currentCameraMode) {
        // Clear timers when mode changes (don't send events - notification wasn't dismissed)
        compressedNotificationStartTime = null
        expandedNotificationStartTime = null
        fullNotificationStartTime = null
        currentTimedImageId = null
        currentScanTrackingId = null

        // Clear stale notification when leaving LIVE mode
        if (currentCameraMode != CameraMode.LIVE) {
            displayedNotificationImage = null
        }

        when (currentCameraMode) {
            CameraMode.LIVE -> {
                Log.d("IRKitLens", "Switching to LIVE mode - resuming recognition")
                irEngine.resumeRecognition()
            }
            CameraMode.SNAPSHOT, CameraMode.CREATOR -> {
                Log.d("IRKitLens", "Switching to ${currentCameraMode.name} mode - pausing recognition")
                irEngine.pauseRecognition()
            }
        }
    }

    // Pause recognition when device is in landscape orientation
    LaunchedEffect(isLandscape) {
        if (isLandscape) {
            Log.d("IRKitLens", "Landscape detected - pausing recognition")
            irEngine.pauseRecognition()
        } else {
            // Only resume if the current mode expects active recognition
            // Allow resume when compressed notification is showing (engine stays active for compressed)
            if (currentCameraMode == CameraMode.LIVE && !(isNotificationShowing && isExpanded)) {
                Log.d("IRKitLens", "Portrait restored - resuming recognition")
                irEngine.resumeRecognition()
            }
        }
    }

    // Handle recognition pause/resume based on notification visibility in LIVE mode
    // Also track timeToDisplay for compressed notifications
    LaunchedEffect(isNotificationShowing, isExpanded, currentCameraMode, displayedNotificationImage?.imageId) {
        val currentImageId = displayedNotificationImage?.imageId?.takeIf { it.isNotEmpty() }

        // Handle notification replacements
        if (currentImageId != null && currentImageId != currentTimedImageId && currentTimedImageId != null) {
            // Previous notification was replaced. The compressed view event for the previous
            // popup was already POSTed immediately when that popup was first shown (see the
            // LaunchedEffect inside the displayedNotificationImage block), so there is nothing
            // to flush here — just reset the per-popup timing state for the new popup.
            expandedNotificationStartTime = null
            compressedNotificationStartTime = null
            // Clear currentTimedImageId so new notification can start timer
            currentTimedImageId = null
            currentScanTrackingId = null
        }

        if (currentCameraMode == CameraMode.LIVE) {
            if (isNotificationShowing && isExpanded) {
                // Only pause when notification is expanded (user is interacting with full card)
                Log.d("IRKitLens", "Pausing recognition - notification expanded")
                irEngine.pauseRecognition()
            } else if (isNotificationShowing && !isExpanded) {
                // Compressed notification visible - keep engine running so it can scan new images
                if (!isLandscape) {
                    Log.d("IRKitLens", "Keeping recognition active - compressed notification visible")
                    irEngine.resumeRecognition()
                }

                // Start compressed notification timer when notification becomes visible and not expanded
                if (compressedNotificationStartTime == null && currentImageId != null) {
                    compressedNotificationStartTime = System.currentTimeMillis()
                    currentTimedImageId = currentImageId
                    // Store scanTrackingId from the recognized image (per spec: must be included in all events within scanned asset)
                    val recognizedImage = displayedNotificationImage
                    if (recognizedImage is ImageModel.FullImage) {
                        currentScanTrackingId = recognizedImage.trackingId.takeIf { it.isNotEmpty() }
                    }
                    Log.d("IRKitLens", "Started compressed notification timer for imageId: $currentImageId, scanTrackingId: ${currentScanTrackingId}")
                }
            } else {
                Log.d("IRKitLens", "Resuming recognition - notification hidden")
                irEngine.resumeRecognition()

                // The compressed view event was already POSTed at popup-show time, so there is
                // nothing to flush on auto-dismiss. We still call onMatchPopupDismissed() so the
                // scan-match dedup AND view/compressed dedup are cleared, allowing the same
                // imageID to fire fresh scan + view events on the next recognition
                // (analytics_doc (3).md §"Scan Result - Match").
                val hadCompressedNotification = compressedNotificationStartTime != null
                if (hadCompressedNotification) {
                    AnalyticsClient.getInstance().onMatchPopupDismissed()
                }

                expandedNotificationStartTime = null
                compressedNotificationStartTime = null
                currentTimedImageId = null
                currentScanTrackingId = null
            }
        }
    }

        // Show "not found" top sheet when image is not recognized in SNAPSHOT mode
        LaunchedEffect(isNotFound) {
            if (isNotFound && currentCameraMode == CameraMode.SNAPSHOT && !displayIsSearching) {
                Log.d("IRKitLens", "Image not recognized - showing top sheet")
                showIRCodeNotFoundTopSheet = true
            }
        }

    // Cleanup on dispose
    DisposableEffect(Unit) {
        onDispose {
            Log.d("IRKitLens", "Disposing IRKitLens")
        }
    }

    // Function to capture and process image (similar to main app's approach)
    fun captureAndProcessImage() {
        scope.launch {
            try {
                Log.d("IRKitLens", "Capturing image in ${currentCameraMode.name} mode")
                val lastFrame = irEngine.previewView.bitmap

                lastFrame?.let { frame ->
                    // Transform the bitmap (scale down slightly like the main app)
                    val matrix = android.graphics.Matrix().apply {
                        postScale(0.8f, 0.8f)
                        val tx = (frame.width * 0.1f)
                        val ty = (frame.height * 0.1f)
                        postTranslate(tx, ty)
                    }

                    val transformedBitmap = Bitmap.createBitmap(
                        frame,
                        0,
                        0,
                        frame.width,
                        frame.height,
                        matrix,
                        true
                    )

                    // Keep a mutable copy for display
                    val capturedImage = transformedBitmap.copy(
                        transformedBitmap.config ?: Bitmap.Config.ARGB_8888,
                        true
                    )

                    // Check if we're in creation mode
                    if (isCapturingForCreation) {
                        Log.d("IRKitLens", "[STEP 5] Image captured for creation flow - skipping normal recognition")
                        // In creation mode, just invoke the callback and let host app handle the flow
                        onImageCaptured?.invoke(capturedImage)
                        // Reset creation mode flag
                        isCapturingForCreation = false
                        // Clean up transformed bitmap
                        transformedBitmap.recycle()
                    } else {
                        // Normal recognition flow
                        capturedBitmap = capturedImage
                        onImageCaptured?.invoke(capturedImage)

                        // Process the image
                        isSearching = true

                        withContext(Dispatchers.IO) {
                            try {
                                val bytes = ByteArrayOutputStream()
                                transformedBitmap.compress(Bitmap.CompressFormat.JPEG, 60, bytes)
                                val imageData = bytes.toByteArray()

                                val imageSearchResult = irEngine.processImageData(imageData)

                                // Track analytics for snapshot scan submission
                                trackSnapshotScanSubmission(imageSearchResult, currentCameraMode)

                                withContext(Dispatchers.Main) {
                                    if (imageSearchResult.isSuccess) {
                                        Log.d("IRKitLens", "Image recognized successfully")
                                        IRKit.getInstance().getImageRecognitionObserver()
                                            .handleImageRecognized(imageSearchResult)

                                        // In SNAPSHOT mode, show ImageDetailsDialog and call the callback
                                        // In LIVE mode, notifications are shown automatically
                                        if (currentCameraMode == CameraMode.SNAPSHOT) {
                                            imageSearchResult.matchedImage?.let { imageModel ->
                                                showImageDetailsDialog = imageModel
                                                onImageRecognized?.invoke(imageModel)
                                            }
                                        }
                                    } else {
                                        Log.d("IRKitLens", "Image not recognized")

                                        // Track "Scan Result — No Match" analytics event
                                        // Only for SNAPSHOT/GALLERY modes, NOT LIVE mode
                                        trackNoMatchScanResult(
                                            imageSearchResult = imageSearchResult,
                                            cameraMode = currentCameraMode,
                                            isFromGallery = false
                                        )

                                        IRKit.getInstance().getImageRecognitionObserver()
                                            .handleImageNotRecognized(imageSearchResult)
                                        onImageNotRecognized?.invoke(capturedImage)
                                    }
                                    isSearching = false
                                }
                            } catch (e: Exception) {
                                Log.e("IRKitLens", "Error processing image", e)
                                withContext(Dispatchers.Main) {
                                    isSearching = false
                                }
                            } finally {
                                transformedBitmap.recycle()
                            }
                        }
                    }
                } ?: run {
                    Log.e("IRKitLens", "Failed to capture image - preview bitmap is null")
                }
            } catch (e: Exception) {
                Log.e("IRKitLens", "Error capturing image", e)
            }
        }
    }

    // Wrap all UI content in IRKitUITheme to provide theme colors and typography
    IRKitUITheme {
    Box(modifier = modifier.fillMaxSize()) {
        // Camera Preview Background - draws edge-to-edge behind status bar
        CameraPreview(
            previewView = irEngine.previewView,
            isSearching = displayIsSearching,
            isBlurred = isExpanded && isNotificationShowing,
            shouldShowGuidingRectangle = true,
            isDeviceStable = true,
            lastSeenImage = lastSeenImage != null,
            camera = irEngine.getCamera(),
            cameraMode = currentCameraMode,
            useFitScaleType = useFitScaleType
        )

        // Segmentation bounding box overlay — shows where the AI model detected an object.
        // Camera preview always shows the full feed; this is drawn on top.
        // Controlled by IRKit-UI config: ClientConfigBase.showSegmentationBoundingBox
        var segmentationBbox by remember { mutableStateOf<android.graphics.RectF?>(null) }
        var segmentationMask by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
        var segmentationFrameWidth by remember { mutableStateOf(0) }
        var segmentationFrameHeight by remember { mutableStateOf(0) }

        DisposableEffect(irEngine) {
            irEngine.onSegmentationBboxUpdate = { bbox, frameSize ->
                segmentationBbox = bbox
                segmentationFrameWidth = frameSize?.width ?: 0
                segmentationFrameHeight = frameSize?.height ?: 0
            }
            irEngine.onSegmentationMaskUpdate = { mask ->
                segmentationMask = mask
            }
            onDispose {
                irEngine.onSegmentationBboxUpdate = null
                irEngine.onSegmentationMaskUpdate = null
            }
        }

        com.irdb.irkit.ui.SegmentationBboxOverlay(
            showOverlay = com.irdb.irkit.segmentation.SegmentationConfig.showBoundingBoxOverlay,
            boundingBox = segmentationBbox,
            maskBitmap = segmentationMask,
            frameWidth = segmentationFrameWidth,
            frameHeight = segmentationFrameHeight,
            isFillScale = !useFitScaleType
        )

        // Captured Image Display (for SNAPSHOT mode or external bitmap)
        if (displayBitmap != null && !displayBitmap.isRecycled) {
            Image(
                bitmap = displayBitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // Top control bar with ModeSelector and + button
        // ModeSelector is always available as a library feature (LIVE/SNAPSHOT switching)
        // + button only shows when IRCODE creation is enabled
        // NOTE: Removed .statusBarsPadding() so topContentPadding is the actual distance from screen top
        // This allows proper control in both normal and full-screen modes
        // CRITICAL: Must use align(Alignment.TopStart) to position from top, then padding applies correctly
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(top = topContentPadding, bottom = 1.dp)
        ) {
            // ModeSelector centered - always visible when enabled (library feature)
            // Hide when bottom sheet is visible, expanded, or scanning
            AnimatedVisibility(
                visible = enableModeSelector &&
                    (currentCameraMode == CameraMode.LIVE || currentCameraMode == CameraMode.SNAPSHOT) &&
                    !isExpanded &&
                    !showCreateIRCodeBottomSheet &&
                    !displayIsSearching,
                enter = fadeIn(animationSpec = tween(durationMillis = 300)) +
                        scaleIn(initialScale = 0.8f, animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)),
                exit = fadeOut(animationSpec = tween(durationMillis = 200)) +
                       scaleOut(targetScale = 0.8f, animationSpec = tween(durationMillis = 200, easing = FastOutLinearInEasing)),
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .align(Alignment.Center)
            ) {
                ModeSelectorView(
                    currentMode = currentCameraMode,
                    onModeChanged = { mode ->
                        // Remember previous mode when switching
                        if (currentCameraMode != CameraMode.CREATOR) {
                            previousCameraMode = currentCameraMode
                        }
                        currentCameraMode = mode
                    },
                    modifier = Modifier.fillMaxWidth(),
                    backgroundAlpha = 0.4f
                )
            }

            // + / X Button positioned on the right
            // Show when: in CREATOR mode (always show close button),
            // or when showAddButton is true AND (IRCODE creation enabled OR creator callback provided)
            // Note: When notification is expanded, X button is rendered separately AFTER the notification to ensure proper Z-order
            val shouldShowAddButton = currentCameraMode == CameraMode.CREATOR || (showAddButton && (enableIRCodeCreation || onCreatorModeRequested != null))
            if (shouldShowAddButton && !showCreateIRCodeBottomSheet && !isExpanded) {
                ShadowButton(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 20.dp),
                    onClick = {
                        if (currentCameraMode == CameraMode.CREATOR) {
                            // Return to previous mode when X clicked in creator mode
                            currentCameraMode = previousCameraMode
                        } else if (isExpanded) {
                            // Close expanded notification when X clicked
                            // NOTE: timeToDisplay is now sent automatically via buffering system
                            expandedNotificationStartTime = null
                            compressedNotificationStartTime = null
                            currentTimedImageId = null
                            currentScanTrackingId = null

                            isExpanded = false
                            imageRecognitionObserver.setContentExpanded(false)
                            imageRecognitionObserver.clearLastSeenImage()
                            displayedNotificationImage = null
                        } else {
                            // Show bottom sheet or notify callback - only if enableIRCodeCreation is true
                            if (onCreatorModeRequested != null) {
                                onCreatorModeRequested()
                            } else if (enableIRCodeCreation) {
                                Log.d("IRKitLens", "[STEP 1] User tapped '+' button - showing CreateIRCodeBottomSheet")
                                showCreateIRCodeBottomSheet = true
                            }
                        }
                    },
                    isRound = true
                ) {
                    if (currentCameraMode == CameraMode.CREATOR || isExpanded) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add / Create",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Spacer(modifier = Modifier.weight(1f))

            // Bottom Bar - Only show for SNAPSHOT and CREATOR modes (matches main app)
            // Hide when TopSheet is visible or when scanning
            AnimatedVisibility(
                visible = (currentCameraMode == CameraMode.SNAPSHOT || currentCameraMode == CameraMode.CREATOR)
                    && !showIRCodeNotFoundTopSheet
                    && !displayIsSearching,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
                ) + fadeIn(animationSpec = tween(durationMillis = 300)),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = tween(durationMillis = 200, easing = FastOutLinearInEasing)
                ) + fadeOut(animationSpec = tween(durationMillis = 200))
            ) {
                BottomBar(
                    onCaptureClick = {
                        Log.d("IRKitLens", "Capture button clicked in ${currentCameraMode.displayName} mode")
                        captureAndProcessImage()
                    },
                    onSelectImageClick = {
                        // Track photo album button press analytics (automatic - no client app code needed)
                        scope.launch {
                            AnalyticsClient.getInstance().trackButtonPressedEvent(
                                buttonType = ButtonType.PHOTO_ALBUM,
                                buttonSource = ButtonSource.HOME_VIEW,
                                buttonTitle = "Photo Album"
                            )
                        }
                        // Use internal image picker if no external callback provided
                        if (onSelectImage != null) {
                            onSelectImage()
                        } else {
                            Log.d("IRKitLens", "Gallery button clicked, launching internal image picker")
                            selectImageLauncher.launch("image/*")
                        }
                    },
                    isExpanded = false, // Simplified for baseline
                    onCloseClick = { /* Handle close if needed */ },
                    onTorchClick = {
                        torchState = !torchState
                        // Track flash light button press analytics (automatic - no client app code needed)
                        scope.launch {
                            AnalyticsClient.getInstance().trackButtonPressedEvent(
                                buttonType = ButtonType.FLASH_LIGHT,
                                buttonSource = ButtonSource.HOME_VIEW,
                                buttonTitle = "Flashlight"
                            )
                        }
                        onTorchToggle?.invoke(torchState)
                        irEngine.getCamera()?.cameraControl?.enableTorch(torchState)
                    },
                    torchState = torchState,
                    hasVisibleNavigationBar = false,
                    cameraMode = currentCameraMode,
                    onAppModeChanged = { newMode ->
                        Log.d("IRKitLens", "Camera mode changed from ${currentCameraMode.displayName} to ${newMode.displayName}")
                        currentCameraMode = newMode
                    },
                    showGalleryButton = showGalleryButton
                )
            }
        }

        // Scanning Effect - Show when processing images (internal or external)
        ScanningEffect(isActive = displayIsSearching && displayBitmap != null) {
            Box(modifier = Modifier.fillMaxSize())
        }

        // Blur scrim behind notification when expanded (matches iOS style)
        AnimatedVisibility(
            visible = isExpanded && isNotificationShowing && currentCameraMode == CameraMode.LIVE,
            enter = fadeIn(animationSpec = tween(300)),
            exit = fadeOut(animationSpec = tween(300))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.2f))
            )
        }

        // Notifications - Show recognition results ONLY in LIVE mode
        // In SNAPSHOT mode, the onImageRecognized callback is used instead (consumer shows ImageDetailsView)
        // Positioned to match legacy placement - action buttons will be 30.dp from bottom (handled by RecognitionNotification)
        AnimatedVisibility(
            visible = isNotificationShowing && !displayIsSearching && currentCameraMode == CameraMode.LIVE,
            enter = slideInVertically(
                initialOffsetY = { 0 },
                animationSpec = tween(
                    durationMillis = 500,
                    easing = FastOutSlowInEasing
                )
            ) + fadeIn(initialAlpha = 0f, animationSpec = tween(300)),
            exit = slideOutVertically(
                targetOffsetY = { 0 },
                animationSpec = tween(
                    durationMillis = 500,
                    easing = FastOutSlowInEasing
                )
            ) + fadeOut(animationSpec = tween(300)),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                // No bottom padding here - RecognitionNotification handles positioning internally
                // Action buttons will be positioned 30.dp from bottom via RecognitionNotification's internal padding
        ) {
            displayedNotificationImage?.let { recognizedImage ->
                // Track compressed preview view event when notification is displayed
                LaunchedEffect(recognizedImage.imageId) {
                    // Skip when popup mounted already-expanded (auto-launch SmartView path):
                    // user never sees a compressed phase, so emitting ViewType.COMPRESSED would
                    // be wrong data. Normal compressed path leaves isExpanded=false on entry.
                    if (isExpanded) return@LaunchedEffect

                    val viewSource = when (currentCameraMode) {
                        CameraMode.LIVE -> ViewSource.LIVE_SCAN
                        CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                        CameraMode.CREATOR -> ViewSource.CREATOR
                    }

                    val imageId = recognizedImage.imageId.takeIf { it.isNotEmpty() }
                    // Get scanTrackingID from the recognized image (per spec: must be included in all events within scanned asset)
                    val scanTrackingId = recognizedImage.trackingId.takeIf { it.isNotEmpty() }
                    currentScanTrackingId = scanTrackingId
                    
                    // Record NOTIFICATION_DISPLAYED so timeToDisplay can be computed
                    scanTrackingId?.let { trackingId ->
                        try {
                            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                                trackingId,
                                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.NOTIFICATION_DISPLAYED
                            )
                        } catch (e: Exception) {
                            Log.w("IRKitLens", "Failed to record NOTIFICATION_DISPLAYED: ${e.message}")
                        }
                    }

                    // Send compressed view event IMMEDIATELY when the popup is shown.
                    //
                    // Previously this buffered the event and relied on a later "send-on-replacement"
                    // or "send-on-auto-dismiss" path to flush it. That deferred-send pattern raced
                    // with the next popup's bufferViewEvent: when popup A was replaced by popup B,
                    // B's bufferViewEvent could overwrite A's buffered event before A's flush ran,
                    // causing A's view to be lost (or sent with B's data). Symptom: scan count >>
                    // view count for fast-changing match streams.
                    //
                    // analytics_doc (3).md §"View - Preview (Compressed)" allows duration=0 on entry,
                    // so an immediate send is spec-correct. timeToDisplay is computed here from
                    // ImageLifecycleTracker (NOTIFICATION_DISPLAYED was just recorded above).
                    val timeToDisplay = scanTrackingId?.let { tid ->
                        try {
                            com.irdb.irkit.utils.ImageLifecycleTracker.getTimeToDisplay(tid)
                        } catch (e: Exception) {
                            Log.w("IRKitLens", "Failed to get timeToDisplay: ${e.message}")
                            null
                        }
                    }
                    val additionalParams = mutableMapOf<String, Any>()
                    scanTrackingId?.let { additionalParams["scanTrackingID"] = it }
                    additionalParams["timeToDisplay"] = timeToDisplay ?: 0L

                    AnalyticsClient.getInstance().trackViewEvent(
                        viewType = ViewType.COMPRESSED,
                        viewSource = viewSource,
                        imageId = imageId,
                        additionalParams = additionalParams
                    )
                    Log.d("IRKitLens", "Sent compressed view event immediately: imageId=$imageId, trackingId=$scanTrackingId, timeToDisplay=${timeToDisplay}ms")
                }

                // Show RecognitionNotification for recognized images in LIVE and SNAPSHOT modes
                // Fully self-contained with expanded content showing products/links
                RecognitionNotification(
                    image = recognizedImage,
                    isLoading = isLoadingDetails,
                    isExpanded = isExpanded,
                    onExpandChange = { expanded ->
                        Log.d("IRKitLens", "Notification expand changed to: $expanded")
                        val currentImageId = recognizedImage.imageId.takeIf { it.isNotEmpty() }

                        if (expanded) {
                            // External browser links — dismiss card and open URL directly
                            if (recognizedImage.showInChromeTab) {
                                val link = recognizedImage.getLinks()
                                if (link != null && link.url.isNotEmpty()) {
                                    Log.d("IRKitLens", "showInChromeTab=true, opening external browser: ${link.url}")
                                    // The compressed view event was already POSTed when the popup
                                    // first appeared; nothing to flush here. Just open the URL and
                                    // let the dismiss path clear dedup state.
                                    openUrl(
                                        url = link.url,
                                        link = link,
                                        image = recognizedImage
                                    )
                                    imageRecognitionObserver.clearLastSeenImage()
                                    displayedNotificationImage = null
                                    // External link tap dismisses the preview popup — clear dedup state.
                                    AnalyticsClient.getInstance().onMatchPopupDismissed()
                                }
                            } else if (recognizedImage.getCardTypeEmum() == CardTypes.ArtCard
                                || recognizedImage.getCardTypeEmum() == CardTypes.Contact) {
                                // Compressed view already POSTed at popup-show; nothing to flush.
                                showImageDetailsDialog = recognizedImage
                            } else {
                            // User expanded notification (non-art cards)
                            // The compressed view event was already POSTed at popup-show time;
                            // nothing to flush. Buffer the new expanded view event so its
                            // duration/timeToDisplay are captured on the next dismiss.
                            scope.launch {
                                val trackingId = recognizedImage.trackingId.takeIf { it.isNotEmpty() }

                                // Buffer expanded view event
                                // v2.0: In live mode, tapping the preview uses liveSearch viewSource
                                val viewSource = when (currentCameraMode) {
                                    CameraMode.LIVE -> ViewSource.LIVE_SEARCH
                                    CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                                    CameraMode.CREATOR -> ViewSource.CREATOR
                                }

                                val additionalParams = currentScanTrackingId?.let { mapOf("scanTrackingID" to it) } ?: emptyMap()

                                AnalyticsClient.getInstance().bufferViewEvent(
                                    viewType = ViewType.EXPANDED,
                                    viewSource = viewSource,
                                    imageId = currentImageId,
                                    trackingId = trackingId,
                                    additionalParams = additionalParams
                                )
                                Log.d("IRKitLens", "Buffered expanded view event")

                                // Track button press for expanded control
                                // v2.0: In live mode, tapping the preview uses liveResult buttonType
                                val expandButtonType = when (currentCameraMode) {
                                    CameraMode.LIVE -> ButtonType.LIVE_RESULT
                                    else -> ButtonType.EXPANDED
                                }
                                val buttonParams = mutableMapOf<String, Any>(
                                    "viewSource" to viewSource.value,
                                    "viewType" to "compressed" // Current view before expansion
                                )
                                AnalyticsClient.getInstance().trackButtonPressedEvent(
                                    buttonType = expandButtonType,
                                    buttonSource = ButtonSource.HOME_VIEW,
                                    buttonTitle = "Expand",
                                    imageId = currentImageId,
                                    failed = false,
                                    additionalParams = buttonParams
                                )
                                Log.d("IRKitLens", "Tracked expanded button press (${expandButtonType.value})")
                            }

                            compressedNotificationStartTime = null
                            expandedNotificationStartTime = System.currentTimeMillis()
                            currentTimedImageId = currentImageId

                            isExpanded = true
                            imageRecognitionObserver.setContentExpanded(true)
                            }
                        } else {
                            // User collapsed notification
                            scope.launch(Dispatchers.IO) {
                                try {
                                    // timeToDisplay is only meaningful for compressed view; expanded view gets 0
                                    val sent = AnalyticsClient.getInstance().sendBufferedViewEventSync(0L)
                                    if (sent) {
                                        Log.d("IRKitLens", "✅ Sent buffered expanded view event on collapse, timeToDisplay=0")
                                    }

                                    withContext(Dispatchers.Main) {
                                        expandedNotificationStartTime = null
                                        compressedNotificationStartTime = null
                                        isExpanded = false
                                        imageRecognitionObserver.setContentExpanded(false)
                                    }
                                } catch (e: Exception) {
                                    Log.e("IRKitLens", "Error tracking collapse analytics", e)
                                    withContext(Dispatchers.Main) {
                                        expandedNotificationStartTime = null
                                        compressedNotificationStartTime = null
                                        isExpanded = false
                                        imageRecognitionObserver.setContentExpanded(false)
                                    }
                                }
                            }
                        }
                    },
                    expandedContent = {
                        // Show appropriate expanded content based on what was recognized
                        if (recognizedImage.products.isNotEmpty()) {
                            // Show product carousel for product images
                            ResultCardProductView(
                                image = recognizedImage,
                                products = recognizedImage.products,
                                onBuyProductTapped = { product ->
                                    onProductClicked?.invoke(recognizedImage, product)
                                    openUrl(
                                        url = product.linkToFollow,
                                        buttonTitle = product.title,
                                        isProductButton = true
                                    )
                                },
                                onClick = { link ->
                                    val viewSource = when (currentCameraMode) {
                                        CameraMode.LIVE -> ViewSource.LIVE_SCAN
                                        CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                                        CameraMode.CREATOR -> ViewSource.CREATOR
                                    }
                                    openUrl(
                                        url = link.url,
                                        link = link,
                                        image = recognizedImage,
                                        viewSource = viewSource,
                                        viewType = "expanded"
                                    )
                                },
                                viewSource = when (currentCameraMode) {
                                    CameraMode.LIVE -> ViewSource.LIVE_SCAN
                                    CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                                    CameraMode.CREATOR -> ViewSource.CREATOR
                                },
                                viewType = "expanded",
                                cameraMode = currentCameraMode
                            )
                        } else {
                            // Show ExpandedContent for art cards, general content, and anything without products
                            // This handles links, metadata (Artist, Year, Medium, etc.), and microsite/webview content
                            com.irdb.irkitui.ui.components.ExpandedContent(
                                image = recognizedImage,
                                onClick = { link ->
                                    val viewSource = when (currentCameraMode) {
                                        CameraMode.LIVE -> ViewSource.LIVE_SCAN
                                        CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                                        CameraMode.CREATOR -> ViewSource.CREATOR
                                    }
                                    openUrl(
                                        url = link.url,
                                        link = link,
                                        image = recognizedImage,
                                        viewSource = viewSource,
                                        viewType = "expanded"
                                    )
                                },
                                viewSource = when (currentCameraMode) {
                                    CameraMode.LIVE -> ViewSource.LIVE_SCAN
                                    CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                                    CameraMode.CREATOR -> ViewSource.CREATOR
                                },
                                viewType = "expanded",
                                cameraMode = currentCameraMode,
                                onImageTap = onImageTapForFullDetails?.let { callback ->
                                    { callback(recognizedImage) }
                                }
                            )
                        }
                    },
                    onLinkClick = { link ->
                        val viewSource = when (currentCameraMode) {
                            CameraMode.LIVE -> ViewSource.LIVE_SCAN
                            CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                            CameraMode.CREATOR -> ViewSource.CREATOR
                        }
                        openUrl(
                            url = link.url,
                            link = link,
                            image = recognizedImage,
                            viewSource = viewSource,
                            viewType = if (isExpanded) "expanded" else "compressed"
                        )
                    },
                    topContentPadding = topContentPadding // Use same padding for consistency
                )
            }
        }

        // Show CreateIRCodeBottomSheet when + button is clicked - only if enableIRCodeCreation is true
        if (showCreateIRCodeBottomSheet && enableIRCodeCreation) {
            // Log when bottom sheet is shown (Step 2)
            LaunchedEffect(showCreateIRCodeBottomSheet) {
                Log.d("IRKitLens", "[STEP 2] CreateIRCodeBottomSheet displayed - showing 'Take Photo' and 'Choose Photo' options")
            }
            CreateIRCodeBottomSheet(
                onTakePhotoClick = {
                    // Check if creation callback is provided
                    Log.d("IRKitLens", "[STEP 3] User tapped 'Take Photo' in CreateIRCodeBottomSheet")
                    // Always switch to CREATOR mode so bottom bar appears (required for both callback and default behavior)
                    previousCameraMode = currentCameraMode
                    currentCameraMode = CameraMode.CREATOR
                    Log.d("IRKitLens", "[STEP 3] Switched to CREATOR mode - bottom bar will appear")

                    if (onTakePhotoForCreation != null) {
                        Log.d("IRKitLens", "[STEP 3] Using creation callback (onTakePhotoForCreation)")
                        isCapturingForCreation = true
                        onTakePhotoForCreation()
                    } else {
                        // Default behavior: Just switched to CREATOR mode above
                        Log.d("IRKitLens", "[STEP 3] Using default behavior (CREATOR mode)")
                    }
                    showCreateIRCodeBottomSheet = false
                },
                onChoosePhotoClick = {
                    // Launch image picker - check if creation callback is provided
                    Log.d("IRKitLens", "[STEP 3] User tapped 'Choose Photo' in CreateIRCodeBottomSheet")
                    if (onChoosePhotoForCreation != null) {
                        Log.d("IRKitLens", "[STEP 3] Using creation callback (onChoosePhotoForCreation)")
                        onChoosePhotoForCreation()
                    } else if (onSelectImage != null) {
                        Log.d("IRKitLens", "onChoosePhotoClick: Using external onSelectImage callback")
                        onSelectImage()
                    } else {
                        Log.d("IRKitLens", "onChoosePhotoClick: Using default recognition picker")
                        selectImageLauncher.launch("image/*")
                    }
                    showCreateIRCodeBottomSheet = false
                },
                onDismiss = {
                    showCreateIRCodeBottomSheet = false
                }
            )
        }

        // TODO: IRCodeNotFoundTopSheet would need to be implemented in IRKit-UI or provided by consumer
        // For now, silently dismiss after a delay when not found
        androidx.compose.runtime.LaunchedEffect(showIRCodeNotFoundTopSheet) {
            if (showIRCodeNotFoundTopSheet) {
                delay(3000)
                showIRCodeNotFoundTopSheet = false
                capturedBitmap = null
                imageRecognitionObserver.clearLastSeenImage()
                displayedNotificationImage = null
            }
        }

        // X button overlay - render AFTER notification to ensure it's on top when expanded
        // This solves the Z-order issue where the expanded notification covers the X button
        // Position is fixed relative to screen (status bar + small offset) regardless of card height
        if (isExpanded && !showCreateIRCodeBottomSheet) {
            val isBottomClose = IRKitUI.getConfig().expandedCloseButtonPlacement == ExpandedCloseButtonPlacement.bottomCenter
            ShadowButton(
                modifier = (if (isBottomClose) {
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp).size(54.dp)
                } else {
                    Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 4.dp, end = 20.dp)
                }).zIndex(2f),
                onClick = {
                    Log.d("IRKitLens", "X button tapped - tracking analytics and closing expanded view")
                    // Get current image data (before clearing state)
                    val recognizedImage = lastSeenImage
                    val trackingId = recognizedImage?.trackingId?.takeIf { it.isNotEmpty() }
                    val imageId = recognizedImage?.imageId?.takeIf { it.isNotEmpty() }

                    val viewSource = when (currentCameraMode) {
                        CameraMode.LIVE -> ViewSource.LIVE_SCAN
                        CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                        CameraMode.CREATOR -> ViewSource.CREATOR
                    }

                    // Clear UI immediately so the button always feels responsive
                    expandedNotificationStartTime = null
                    compressedNotificationStartTime = null
                    currentTimedImageId = null
                    currentScanTrackingId = null
                    isExpanded = false
                    imageRecognitionObserver.setContentExpanded(false)
                    imageRecognitionObserver.clearLastSeenImage()
                    displayedNotificationImage = null

                    // X dismisses the preview popup — clear dedup state so the same imageID can
                    // be POSTed again as a fresh match on the next recognition.
                    AnalyticsClient.getInstance().onMatchPopupDismissed()

                    // Track analytics in the background (do not block UI)
                    scope.launch(Dispatchers.IO) {
                        try {
                            // Send button press first so it can't be blocked by view event persistence
                            // Use sync variant for guaranteed enqueue/logging
                            val buttonParams = mutableMapOf<String, Any>(
                                "viewSource" to viewSource.value,
                                "viewType" to "expanded"
                            )

                            AnalyticsClient.getInstance().trackButtonPressedEventSync(
                                buttonType = ButtonType.X,
                                buttonSource = ButtonSource.HOME_VIEW,
                                buttonTitle = "Close",
                                imageId = imageId,
                                failed = false,
                                additionalParams = buttonParams
                            )
                            Log.d("IRKitLens", "Tracked X button press")

                            // timeToDisplay is only meaningful for compressed view; expanded view gets 0
                            val sent = withTimeoutOrNull(1500L) {
                                AnalyticsClient.getInstance().sendBufferedViewEvent(0L)
                            } ?: false
                            if (sent) {
                                Log.d("IRKitLens", "✅ Sent buffered expanded view event on X button, timeToDisplay=0")
                            } else {
                                Log.w("IRKitLens", "⚠️ Buffered expanded view event not sent (timeout or no buffered event)")
                            }
                        } catch (e: Exception) {
                            Log.e("IRKitLens", "Error tracking X button analytics", e)
                        }
                    }
                },
                isRound = true
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = Color.White,
                    modifier = Modifier.size(if (isBottomClose) 32.dp else 24.dp)
                )
            }
        }

        // Show ImageDetailsDialog when image is recognized in SNAPSHOT mode
        showImageDetailsDialog?.let { imageModel ->
            // Buffer full view analytics when dialog is shown (send on exit for accurate duration)
            LaunchedEffect(imageModel.imageId) {
                Log.d("IRKitLens", "Buffering FULL view for SNAPSHOT mode: imageId=${imageModel.imageId}")
                val trackingId = imageModel.trackingId.takeIf { it.isNotEmpty() }
                val additionalParams = trackingId?.let { mapOf("scanTrackingID" to it) } ?: emptyMap()

                try {
                    AnalyticsClient.getInstance().bufferViewEvent(
                        viewType = ViewType.FULL,
                        viewSource = ViewSource.SNAPSHOT,
                        imageId = imageModel.imageId,
                        campaignId = imageModel.campaignId.takeIf { it > 0 }?.toString(),
                        campaignName = imageModel.campaignName?.takeIf { it.isNotEmpty() },
                        trackingId = trackingId,
                        additionalParams = additionalParams
                    )
                } catch (e: Exception) {
                    Log.e("IRKitLens", "Error buffering full view analytics", e)
                }
            }

            // Send full view event when dialog is dismissed (duration = time in view)
            DisposableEffect(Unit) {
                onDispose {
                    Log.d("IRKitLens", "Full view dismissed for SNAPSHOT mode")
                    scope.launch(Dispatchers.IO) {
                        // timeToDisplay is only meaningful for compressed view; full view gets 0
                        val sent = AnalyticsClient.getInstance().sendBufferedViewEventSync(0L)
                        if (sent) {
                            Log.d("IRKitLens", "✅ Sent buffered full view event on dismiss, timeToDisplay=0")
                        }
                    }
                }
            }

            Dialog(
                onDismissRequest = {
                    showImageDetailsDialog = null
                    capturedBitmap = null
                    imageRecognitionObserver.clearLastSeenImage()
                    displayedNotificationImage = null
                    // SNAPSHOT detail dialog dismissed — clear dedup state for next match.
                    AnalyticsClient.getInstance().onMatchPopupDismissed()
                },
                properties = DialogProperties(
                    dismissOnBackPress = true,
                    dismissOnClickOutside = false,
                    usePlatformDefaultWidth = false
                )
            ) {
                ImageDetailsView(
                    currentImage = imageModel,
                    onClose = {
                        showImageDetailsDialog = null
                        capturedBitmap = null
                        imageRecognitionObserver.clearLastSeenImage()
                        displayedNotificationImage = null
                        // SNAPSHOT detail dialog closed — clear dedup state for next match.
                        AnalyticsClient.getInstance().onMatchPopupDismissed()
                    },
                    onBuyProductClicked = { image, link ->
                        onProductClicked?.invoke(image, ProductInCampaignDto(
                            id = null,
                            imageUrl = "",
                            title = link.title,
                            linkToFollow = link.url
                        ))
                        openUrl(link.url)
                    },
                    onContentMetaLinksClicked = { image, link ->
                        val viewSource = when (currentCameraMode) {
                            CameraMode.LIVE -> ViewSource.LIVE_SCAN
                            CameraMode.SNAPSHOT -> ViewSource.SNAPSHOT
                            CameraMode.CREATOR -> ViewSource.CREATOR
                        }
                        openUrl(
                            url = link.url,
                            link = link,
                            image = image,
                            viewSource = viewSource,
                            viewType = "full"
                        )
                    },
                    viewSource = ViewSource.UNDEFINED,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        // Landscape orientation overlay - covers entire camera UI
        if (isLandscape) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.ScreenRotation,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Please rotate your device\nback to portrait mode",
                        color = Color.White,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
    } // IRKitUITheme
}
