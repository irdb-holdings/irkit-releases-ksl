package com.irdb.irkitui.configuration

/**
 * Enum representing the available client applications that use IRKit-UI.
 * Used internally to select the appropriate configuration values.
 */
enum class LibraryClient {
    /**
     * IRCODE app - the primary/default client
     */
    IRCODE,

    /**
     * KSL client
     */
    KSL,

    /**
     * LiveNation client
     */
    LIVENATION,

    /**
     * Test App (stubbed - uses IRCODE defaults)
     */
    TEST_APP,

    /**
     * Bloomreach (stubbed - uses IRCODE defaults)
     */
    BLOOMREACH
}
