package com.irdb.irkitui.configuration.liveNation

import com.irdb.irkitui.BuildConfig
import com.irdb.irkitui.configuration.ClientConfigBase
import com.irdb.irkitui.configuration.ExpandedCloseButtonPlacement

/**
 * Configuration values for the LiveNation client.
 * Contains Dev, Staging, and Production variants.
 *
 * Note: LiveNation uses companyName "LiveNation" to distinguish its analytics data
 * from the main IRCODE app. sessionSource is built dynamically.
 */
object LiveNationConfig {

    const val useIRCODE = true
    object Dev : ClientConfigBase() {
        override val clientName = "LiveNation"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
        override val irEngineUrl = "https://production.backend.irdb.com/v1"
        override val irkitSubscriptionKey = "E7480C60A81F48F69D9F19F0B13F6A41890F654E8FE3448DA1877FFC095FA397AAD4B1505B084F6186961F082BE601CD"
        override val analyticsApiKey = "E7480C60A81F48F69D9F19F0B13F6A41890F654E8FE3448DA1877FFC095FA397AAD4B1505B084F6186961F082BE601CD"
        override val analyticsApiKeyHeaderName = "sdkapikey"
        override val companyName = "LiveNation"
        override val analyticsBucketName = "--"
        override val environment = "production"
        override val prefsEncryptionKey = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
        override val prefsEncryptionSalt = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
        override val expandedCloseButtonPlacement get() = ExpandedCloseButtonPlacement.bottomCenter
    }

    object Staging : ClientConfigBase() {
        override val clientName = "LiveNation"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
        override val irEngineUrl = "https://production.backend.irdb.com/v1"
        override val irkitSubscriptionKey = "E7480C60A81F48F69D9F19F0B13F6A41890F654E8FE3448DA1877FFC095FA397AAD4B1505B084F6186961F082BE601CD"
        override val analyticsApiKey = "E7480C60A81F48F69D9F19F0B13F6A41890F654E8FE3448DA1877FFC095FA397AAD4B1505B084F6186961F082BE601CD"
        override val analyticsApiKeyHeaderName = "sdkapikey"
        override val companyName = "LiveNation"
        override val analyticsBucketName = "--"
        override val environment = "production"
        override val prefsEncryptionKey = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
        override val prefsEncryptionSalt = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
        override val expandedCloseButtonPlacement get() = ExpandedCloseButtonPlacement.bottomCenter
    }

    object Production : ClientConfigBase() {
        override val clientName = "LiveNation"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
        override val irEngineUrl = "https://production.backend.irdb.com/v1"
        override val irkitSubscriptionKey = "E7480C60A81F48F69D9F19F0B13F6A41890F654E8FE3448DA1877FFC095FA397AAD4B1505B084F6186961F082BE601CD"
        override val analyticsApiKey = "E7480C60A81F48F69D9F19F0B13F6A41890F654E8FE3448DA1877FFC095FA397AAD4B1505B084F6186961F082BE601CD"
        override val analyticsApiKeyHeaderName = "sdkapikey"
        override val companyName = "LiveNation"
        override val analyticsBucketName = "--"
        override val environment = "production"
        override val prefsEncryptionKey = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
        override val prefsEncryptionSalt = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
        override val expandedCloseButtonPlacement get() = ExpandedCloseButtonPlacement.bottomCenter
    }

    /**
     * Returns the appropriate configuration based on the current build flavor.
     */
    val current: ClientConfigBase
        get() = when (BuildConfig.FLAVOR) {
            "staging" -> Staging
            "production" -> Production
            else -> Dev
        }
}
