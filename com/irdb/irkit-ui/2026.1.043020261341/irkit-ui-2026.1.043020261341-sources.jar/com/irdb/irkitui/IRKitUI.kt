package com.irdb.irkitui

import android.content.Context
import android.util.Log
import com.irdb.analytics.AnalyticsClient
import com.irdb.analytics.AnalyticsConfig
import com.irdb.analytics.StatusType
import com.irdb.analytics.buildSessionSource
import com.irdb.analytics.models.UserContext
import androidx.lifecycle.ProcessLifecycleOwner
import com.irdb.irkit.BackendService
import com.irdb.irkit.config.IRKitConfigManager
import com.irdb.irkit.config.IRKitConfiguration
import com.irdb.irkit.getLens
import com.irdb.irkit.response.LensResponse
import com.irdb.irkit.segmentation.SegmentationConfig
import com.irdb.irkit.segmentation.SegmentationModelResolver
import com.irdb.irkit.utils.UUIDGenerator
import com.irdb.irkitui.configuration.ClientConfigBase
import com.irdb.irkitui.configuration.LibraryClient
import com.irdb.irkitui.configuration.ircode.IrcodeConfig
import com.irdb.irkitui.configuration.ksl.KslConfig
import com.irdb.irkitui.configuration.liveNation.LiveNationConfig
import com.irdb.irkitui.lifecycle.AppLifecycleObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * IRKitUI - Main initialization object for IRKit-UI library.
 *
 * Handles automatic initialization of analytics module that is completely hidden from client applications.
 * All configuration is internal - client apps provide nothing.
 *
 * Analytics is initialized automatically when IRKitLens is first composed.
 *
 * Configuration Selection:
 * - Client is set at compile time via Gradle property: -PirkitClient=KSL_DEMO
 * - Defaults to IRCODE if not specified
 * - Valid values: IRCODE, KSL_DEMO, TEST_APP, BLOOMREACH
 * - Configuration values are automatically selected based on build flavor (dev/staging/production)
 */
object IRKitUI {
    private const val TAG = "IRKitUI"

    @Volatile
    private var lastLensSearchString: String? = null

    @Volatile
    private var lensPrimaryCollection: String? = null

    @Volatile
    private var isInitialized = false
    private val initLock = Any()

    /**
     * Tracks whether the IRKitLens composable is currently in the composition tree.
     * Set by IRKitLens via DisposableEffect.
     *
     * When true, AppLifecycleObserver skips its foreground refresh because
     * the lens's own repeatOnLifecycle(STARTED) callback will handle it
     * (and fires after the network stack has reconnected).
     */
    @Volatile
    internal var isLensVisible = false

    /**
     * Tracks whether the lens has ever been opened in this process.
     * Set to true by IRKitLens's DisposableEffect the first time the lens enters
     * the composition. AppLifecycleObserver uses this to skip foreground lens-config
     * refreshes until the lens has been opened at least once — ensuring zero REST
     * API calls are made at Application startup.
     */
    @Volatile
    internal var hasLensEverBeenOpened = false

    // Internal flag for future "do not track" feature (default: true)
    private var enableTracking = true

    /**
     * Get the current LibraryClient selection from BuildConfig.
     * The client is set at compile time via Gradle property (for example: -PirkitClient=KSL_DEMO).
     * Defaults to IRCODE if not specified or invalid.
     */
    internal fun getLibraryClient(): LibraryClient {
        val configuredValue = BuildConfig.LIBRARY_CLIENT
        return when (configuredValue) {
            // Backward-compatible alias used by root Gradle auto-detection.
            "KSL_DEMO" -> LibraryClient.KSL
            else -> try {
                LibraryClient.valueOf(configuredValue)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "Unknown LIBRARY_CLIENT: $configuredValue, defaulting to IRCODE")
                LibraryClient.IRCODE
            }
        }
    }

    private fun resolveLibraryClient(context: Context): LibraryClient {
        val configuredClient = getLibraryClient()
        if (configuredClient != LibraryClient.IRCODE) {
            return configuredClient
        }

        // If IRCODE is explicitly selected, do not auto-detect by package name.
        if (BuildConfig.LIBRARY_CLIENT == LibraryClient.IRCODE.name) {
            return configuredClient
        }

        val packageName = context.packageName.lowercase()
        return when {
            packageName.contains("ksldemo") -> LibraryClient.KSL
            else -> configuredClient
        }
    }

    /**
     * Get the current configuration based on the selected LibraryClient.
     * Returns the appropriate config (Dev/Staging/Production) based on build flavor.
     * Client is determined at compile time via Gradle property: -PirkitClient=KSL
     */
    internal fun getCurrentConfig(libraryClient: LibraryClient): ClientConfigBase = when (libraryClient) {
        LibraryClient.IRCODE -> IrcodeConfig.current
        LibraryClient.KSL -> KslConfig.current
        LibraryClient.LIVENATION -> LiveNationConfig.current
        // Stubbed clients - fallback to IRCODE
        LibraryClient.TEST_APP -> IrcodeConfig.current
        LibraryClient.BLOOMREACH -> IrcodeConfig.current
    }

    /**
     * Get the current configuration using context-aware client resolution.
     * This keeps runtime behavior consistent with initialize(context).
     */
    internal fun getResolvedConfig(context: Context): ClientConfigBase {
        val resolvedClient = resolveLibraryClient(context.applicationContext)
        return getCurrentConfig(resolvedClient)
    }

    /**
     * Get the current theme without requiring full initialization.
     * This is used by IRKitUITheme to resolve the theme before analytics is initialized.
     *
     * @return The theme from the current client configuration
     */
    fun getTheme(): com.irdb.irkitui.theme.IRKitTheme {
        val libraryClient = getLibraryClient()
        val config = getCurrentConfig(libraryClient)
        return config.theme
    }

    /**
     * Get build and environment information for the IRKit libraries.
     * Available without initialization -- values are baked in at build time.
     *
     * @return [IRKitBuildInfo] containing environment, version, and endpoint details
     */
    @JvmStatic
    fun getBuildInfo(): IRKitBuildInfo {
        val config = getCurrentConfig(getLibraryClient())
        return IRKitBuildInfo(
            environment = config.environment,
            libraryVersion = com.irdb.irkit.LibraryVersion.version,
            companyName = config.companyName,
            backendUrl = config.backendUrl,
            irEngineUrl = config.irEngineUrl,
            clientName = config.clientName
        )
    }

    /**
     * Initialize IRKitUI with automatic configuration based on the selected client.
     * This is called automatically when IRKitLens is first composed.
     *
     * Configuration is determined by:
     * 1. The selected LibraryClient (defaults to IRCODE)
     * 2. The current build flavor (dev/staging/production)
     *
     * @param context Application context (will be converted to Application context if needed)
     */
    fun initialize(context: Context) {
        if (!enableTracking) {
            Log.d(TAG, "Analytics tracking is disabled")
            return
        }

        if (isInitialized) {
            Log.d(TAG, "IRKitUI already initialized")
            return
        }

        synchronized(initLock) {
            if (isInitialized) {
                return
            }

            try {
                val applicationContext = context.applicationContext
                val libraryClient = resolveLibraryClient(applicationContext)
                val config = getCurrentConfig(libraryClient)

                Log.d(TAG, "Initializing IRKitUI with client: $libraryClient, environment: ${config.environment}")

                // IMPORTANT: Set up IRKit configuration BEFORE calling any BackendService methods
                setupIRKitConfiguration(applicationContext, config)

                // GetLens (refreshLensConfig) is intentionally NOT called here.
                // It is deferred to when IRKitLens first opens via the lens's
                // LaunchedEffect(lifecycleOwner) → repeatOnLifecycle(STARTED) block,
                // ensuring zero REST API calls are made at Application startup.

                // Register lifecycle observer for subsequent foreground events.
                // ProcessLifecycleOwner auto-initializes via androidx.startup —
                // client apps do nothing.
                ProcessLifecycleOwner.get().lifecycle.addObserver(AppLifecycleObserver())
                Log.d(TAG, "AppLifecycleObserver registered")

                // Initialize analytics
                initializeAnalytics(
                    context = applicationContext,
                    config = config,
                    libraryClient = libraryClient,
                    lensPrimaryCollection = lensPrimaryCollection
                )

                isInitialized = true
                Log.d(TAG, "IRKitUI initialized successfully")

            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize IRKitUI", e)
            }
        }
    }

    /**
     * Legacy initialize method for backward compatibility.
     * Parameters are ignored - configuration is determined by the selected LibraryClient.
     *
     * @param context Application context
     * @param companyName Ignored - kept for API compatibility
     * @param appName Ignored - kept for API compatibility
     */
    @Deprecated(
        message = "Use initialize(context) instead. companyName and appName are now determined by LibraryClient configuration.",
        replaceWith = ReplaceWith("initialize(context)")
    )
    @Suppress("UNUSED_PARAMETER")
    fun initialize(
        context: Context,
        companyName: String?,
        appName: String?
    ) {
        initialize(context)
    }

    /**
     * Refresh lens configuration from the backend.
     * Called every time the lens opens and on background→foreground transitions.
     * Updates segmentation model, lens search string, and primary collection.
     * On failure, keeps existing values (last-known-good).
     */
    internal suspend fun refreshLensConfig() {
        withContext(Dispatchers.IO) {
            try {
                val lensResponse = BackendService.getLens()
                logLensResponse(lensResponse)
                val firstLens = lensResponse.lenses?.firstOrNull() ?: run {
                    Log.w(TAG, "refreshLensConfig: getLens returned no lenses — keeping current config")
                    return@withContext
                }

                // Update primary collection
                lensPrimaryCollection = firstLens.primaryCollection

                // Push the bucket forward into the analytics SDK. /lenses is
                // deferred to lens-open (zero REST at app startup), so the
                // first analytics init runs with config.analyticsBucketName
                // (a placeholder like "--"). Once we have the real bucket
                // from the server, update AnalyticsClient so subsequent
                // /Statistics payloads ship the correct bucketName /
                // sessionSource — derived per the analytics spec by
                // [resolveAnalyticsSession]. Returns null on missing/blank
                // server data, in which case we keep the placeholder rather
                // than overwrite with garbage.
                val clientCompany = getCurrentConfig(getLibraryClient()).companyName
                val descriptor = com.irdb.irkitui.analytics.resolveAnalyticsSession(
                    lensResponse = lensResponse,
                    companyName = clientCompany
                )
                if (descriptor != null) {
                    getAnalyticsClient()?.setBucketName(descriptor.bucketName)
                    Log.d(
                        TAG,
                        "refreshLensConfig: bucketName=${descriptor.bucketName} " +
                            "sessionSource=${descriptor.sessionSource}"
                    )
                } else {
                    Log.w(
                        TAG,
                        "refreshLensConfig: resolver returned null — keeping previous bucket"
                    )
                }

                // Update scan-to-site auto-launch flag from backend (nested under characteristics)
                val autoLaunchSts = firstLens.characteristics?.get("enableAutoLaunchSTS") as? Boolean ?: false
                com.irdb.irkit.config.ScanToSiteConfig.backendEnableAutoLaunchSTS = autoLaunchSts
                Log.d(TAG, "refreshLensConfig: backendEnableAutoLaunchSTS=$autoLaunchSts")

                // Build search string from ALL entries in lensSearchList
                val searchList = firstLens.lensSearchList
                    ?: lensResponse.lensSearchList

                val lensSearchString = if (!searchList.isNullOrEmpty()) {
                    searchList.mapNotNull { entry ->
                        entry["primaryCollection"]
                            ?: entry.values.firstOrNull { !it.isNullOrBlank() }
                    }.joinToString(",")
                } else {
                    firstLens.lensSearchString ?: lensResponse.searchString
                }
                lastLensSearchString = lensSearchString
                IRKitConfigManager.getConfiguration().putLensSearchString(lensSearchString)
                Log.d(TAG, "refreshLensConfig: lensSearchString=$lensSearchString")

                // Resolve segmentation model from lens characteristics
                val characteristics = firstLens.characteristics
                val lensType = characteristics?.get("lensType") as? String
                val segmentationModel = characteristics?.get("segmentationModel") as? String
                val resolvedModel = SegmentationModelResolver.resolve(lensType, segmentationModel)
                val previousModel = SegmentationConfig.modelName

                SegmentationConfig.modelName = resolvedModel
                if (resolvedModel == SegmentationModelResolver.MODEL_NONE) {
                    SegmentationConfig.segmentationEnabled = false
                    Log.d(TAG, "refreshLensConfig: segmentation disabled (model=none)")
                }
                if (resolvedModel != previousModel) {
                    Log.d(TAG, "refreshLensConfig: segmentation model changed: $previousModel -> $resolvedModel")
                } else {
                    Log.d(TAG, "refreshLensConfig: segmentation model unchanged: $resolvedModel")
                }
            } catch (e: Exception) {
                Log.e(TAG, "refreshLensConfig failed — keeping current values", e)
            }
        }
    }

    /**
     * Set up IRKit configuration via IRKitConfigManager.
     * This allows IRKit.initialize(context) to work without requiring clients to pass configuration.
     */
    private fun setupIRKitConfiguration(context: Context, config: ClientConfigBase) {
        // Create an implementation of IRKitConfiguration using our ClientConfigBase
        val irkitConfig = object : IRKitConfiguration {
            // Mutable storage for values that can be updated from backend
            private var storedEnvironment: String = config.environment
            private var storedIREngineUrl: String = config.irEngineUrl
            private var storedAPIKeyForIREngine: String = config.irkitSubscriptionKey  // Initial key from config, can be updated from getEnvironment
            private var storedLensSearchString: String? = null
            private val storedBackendUrl: String = config.backendUrl

            override fun getBackendUrl(): String = storedBackendUrl
            override fun getUrlToIREngine(): String = storedIREngineUrl
            override fun getAPIKeyForIREngine(): String = storedAPIKeyForIREngine
            override fun getEnvironment(): String = storedEnvironment
            override fun getLensSearchString(): String? = storedLensSearchString

            override fun getInstallationId(): String {
                // Generate or retrieve a persistent installation ID
                val prefs = context.getSharedPreferences("irkit_prefs", Context.MODE_PRIVATE)
                var installId = prefs.getString("installation_id", null)
                if (installId == null) {
                    installId = java.util.UUID.randomUUID().toString()
                    prefs.edit().putString("installation_id", installId).apply()
                }
                return installId
            }

            override fun putEnvironment(value: String) {
                storedEnvironment = value
            }

            override fun putUrlToIREngine(value: String) {
                storedIREngineUrl = value
            }

            override fun putAPIKeyForIREngine(value: String) {
                storedAPIKeyForIREngine = value
                Log.d(TAG, "IR Engine API key updated from getEnvironment")
            }

            override fun putLensSearchString(value: String?) {
                storedLensSearchString = value
            }

            override fun isIRCodeCreationEnabled(): Boolean = false
        }

        IRKitConfigManager.setConfiguration(irkitConfig)

        // Also set BackendService configuration immediately so getLens() can be called
        // BackendService expects com.irdb.irkit.IRKitConfiguration, not com.irdb.irkit.config.IRKitConfiguration
        val backendServiceConfig = object : com.irdb.irkit.IRKitConfiguration {
            override fun getBackendUrl(): String = config.backendUrl
            override fun getIREngineUrl(): String = config.irEngineUrl
            override fun getAPIKey(): String = config.irkitSubscriptionKey
            override fun isDebugMode(): Boolean = config.environment.lowercase() == "development"
            override fun isImageLifecycleLoggingEnabled(): Boolean = false
            override fun getSubscriptionKey(): String = config.irkitSubscriptionKey
            override fun getEnvironment(): String = config.environment
            override fun getPreferencesEncryptionKey(): String = config.prefsEncryptionKey
            override fun getPreferencesEncryptionSalt(): String = config.prefsEncryptionSalt
        }
        BackendService.setConfiguration(backendServiceConfig)

        // Initialize segmentation configuration from client config.
        // IRKit-UI is the authority for these flags — the library never decides them.
        com.irdb.irkit.segmentation.SegmentationConfig.segmentationEnabled = config.segmentationEnabled
        com.irdb.irkit.segmentation.SegmentationConfig.showBoundingBoxOverlay = config.showSegmentationBoundingBox

        Log.d(TAG, "IRKit configuration set via IRKitConfigManager and BackendService")
        Log.d(TAG, "Segmentation: enabled=${config.segmentationEnabled}, showBbox=${config.showSegmentationBoundingBox}")
    }


    /**
     * Initialize analytics with the given configuration.
     */
    private fun initializeAnalytics(
        context: Context,
        config: ClientConfigBase,
        libraryClient: LibraryClient,
        lensPrimaryCollection: String?
    ) {
        // DEBUG: Log the config values we're about to use
        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        Log.d(TAG, "IRKitUI initializeAnalytics called")
        Log.d(TAG, "  → LibraryClient: $libraryClient")
        Log.d(TAG, "  → Config class: ${config::class.simpleName}")
        Log.d(TAG, "  → analyticsBucketName (config): ${config.analyticsBucketName}")
        Log.d(TAG, "  → analyticsBucketName (primaryCollection): $lensPrimaryCollection")
        Log.d(TAG, "  → companyName: ${config.companyName}")
        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        // Check if AnalyticsClient is already initialized (by the main app)
        // If so, use the existing instance instead of re-initializing
        val analyticsClient = try {
            val existing = AnalyticsClient.getInstance()
            Log.w(TAG, "⚠️ AnalyticsClient was ALREADY initialized! Using existing instance.")
            Log.w(TAG, "   This means config from IRKitUI is NOT being used!")
            existing
        } catch (e: IllegalStateException) {
            // Not initialized yet - initialize it now
            Log.d(TAG, "✅ AnalyticsClient not initialized yet, initializing from IRKitUI")

            // Build analytics endpoint from backend URL
            val analyticsEndpoint = "${config.backendUrl}/Statistics"

            // Create analytics configuration using client config values
            val resolvedBucketName = lensPrimaryCollection ?: config.analyticsBucketName
            val analyticsConfig = AnalyticsConfig(
                apiEndpoint = analyticsEndpoint,
                apiKey = config.analyticsApiKey,
                companyName = config.companyName,
                bucketName = resolvedBucketName,
                irEngineBaseUrl = config.irEngineUrl,  // For constructing imageUrlOfScan
                enableDebugLogging = BuildConfig.DEBUG,  // Show Analytics-Params in logcat
                enableMocking = false,  // Send real analytics events
                autoTrackLifecycle = false,  // Session events managed by IRKitUI at init time
                autoDetectDeviceInfo = true
            )

            // DEBUG: Log the AnalyticsConfig values
            Log.d(TAG, "Created AnalyticsConfig:")
            Log.d(TAG, "  → companyName: ${analyticsConfig.companyName}")
            Log.d(TAG, "  → bucketName: ${analyticsConfig.bucketName}")
            Log.d(TAG, "  → irEngineBaseUrl: ${analyticsConfig.irEngineBaseUrl}")
            Log.d(TAG, "  → autoTrackLifecycle: ${analyticsConfig.autoTrackLifecycle}")

            // Initialize AnalyticsClient
            AnalyticsClient.initialize(context, analyticsConfig)
            AnalyticsClient.getInstance()
        }

        // Check if user context already exists (set by main app)
        val existingContext = analyticsClient.getUserContext()
        if (existingContext == null || existingContext.userId == null) {
            // No user context set yet - initialize with anonymous user
            Log.d(TAG, "No user context found, initializing with anonymous user")

            // Generate UUIDv7 for session tracking ID
            val sessionTrackingId = UUIDGenerator.generateSessionTrackingID()
            val installationId = IRKitConfigManager.getConfiguration().getInstallationId()

            // Create initial user context with anonymous user and auto-detected device info
            val userContext = UserContext(
                userId = null,
                installationId = installationId,
                userType = "anonymous",
                sessionTrackingId = sessionTrackingId,
                sessionSource = buildSessionSource("Android", config.companyName, analyticsClient.getBucketName()),
                // Include IRKit library version information
                libraryVersion = com.irdb.irkit.LibraryVersion.version,
                libraryMainRelease = com.irdb.irkit.LibraryVersion.mainRelease,
                libraryPointRelease = com.irdb.irkit.LibraryVersion.pointRelease
            )

            // Set user context (this will auto-detect and merge device info)
            analyticsClient.setUserContext(userContext)
            Log.d(TAG, "Session Tracking ID: $sessionTrackingId")
        } else {
            // User context already set by main app - don't overwrite it!
            // But ensure installationId is set (main app doesn't know about it)
            if (existingContext.installationId == null) {
                val installationId = IRKitConfigManager.getConfiguration().getInstallationId()
                analyticsClient.setUserContext(existingContext.copy(installationId = installationId))
            }
            Log.d(TAG, "Using existing user context: userId=${existingContext.userId}, userType=${existingContext.userType}")
        }

        Log.d(TAG, "Analytics initialized with companyName: ${config.companyName}, sessionSource will be built dynamically")

        // Session start/end are NOT emitted here. Sessions are lens-scoped:
        // the IRKitLens composable owns its session lifetime via a
        // DisposableEffect that calls AnalyticsClient.onSessionStarted() +
        // trackStatusEvent(SESSION_STARTED) on enter and
        // trackStatusEventSync(SESSION_STOPPED) + flushSync on dispose. This
        // file's initialize path only prepares the analytics client; it does
        // not open a session. A host app that boots but never opens the lens
        // produces zero analytics POSTs.

        // Flushing cached events from previous sessions is intentionally NOT done here.
        // It is deferred to the lens-open DisposableEffect in IRKitLens.kt so that no
        // REST API calls are made at Application startup.
    }

    private fun logLensResponse(response: LensResponse) {
        Log.d(TAG, "getLens results: $response")

        val lenses = response.lenses
        Log.d(TAG, "getLens lenses count: ${lenses?.size ?: 0} (isNull=${lenses == null})")

        lenses?.forEachIndexed { index, lens ->
            Log.d(
                TAG,
                "getLens lens[$index]: lensId=${lens.lensId}, sdkId=${lens.sdkId}, apiKey=${lens.apiKey}, " +
                    "lensOwnerId=${lens.lensOwnerId}, primaryCollection=${lens.primaryCollection}, " +
                    "originId=${lens.originId}, lensSearchList=${lens.lensSearchList}, " +
                    "characteristics=${lens.characteristics}, lensSearchString=${lens.lensSearchString}"
            )
        }

        Log.d(
            TAG,
            "getLens metadata: associatedUserId=${response.associatedUserId}, " +
                "lensSearchList=${response.lensSearchList}, searchString=${response.searchString}"
        )
    }

    /**
     * Get the AnalyticsClient instance (for internal use only).
     * Returns null if not initialized or tracking is disabled.
     */
    internal fun getAnalyticsClient(): AnalyticsClient? {
        return if (isInitialized && enableTracking) {
            try {
                AnalyticsClient.getInstance()
            } catch (e: Exception) {
                Log.e(TAG, "AnalyticsClient not available", e)
                null
            }
        } else {
            null
        }
    }

    /**
     * Check if analytics is initialized.
     */
    fun isInitialized(): Boolean = isInitialized

    /**
     * Get the current configuration (for internal use only).
     * Useful for debugging and testing.
     */
    internal fun getConfig(): ClientConfigBase = getCurrentConfig(getLibraryClient())

    /**
     * Get the last lensSearchString returned by getLens().
     * Useful for QA/debug displays in client demo apps.
     */
    @JvmStatic
    fun getLensSearchString(): String? = lastLensSearchString

    /**
     * De-initialize IRKitUI and send session end analytics.
     *
     * This MUST be called when the user leaves IRKitLensActivity to ensure:
     * 1. Session-ended event is sent
     * 2. All cached events are flushed to the server
     *
     * This method blocks until all operations complete (with a timeout).
     * Safe to call from any thread.
     */
    fun deInitialize() {
        if (!isInitialized) {
            Log.d(TAG, "IRKitUI not initialized, skipping deInitialize")
            return
        }

        Log.d(TAG, "🛑 IRKitUI.deInitialize() called - draining any queued analytics events")

        try {
            val analyticsClient = getAnalyticsClient()
            if (analyticsClient == null) {
                Log.w(TAG, "AnalyticsClient not available for deInitialize")
                return
            }

            // SESSION_STOPPED is now emitted by AppLifecycleObserver.onStop when
            // the app backgrounds (ProcessLifecycleOwner). Emitting it here too
            // would double-send, since onStop fires before onActivityDestroyed
            // on every backgrounding. Instead, just drain any events queued
            // after onStop ran — typically empty, but cheap insurance.
            kotlinx.coroutines.runBlocking(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val flushed = analyticsClient.flushSync(timeoutMs = 3000L)
                    Log.d(TAG, "🔄 Flush completed (sync): $flushed")
                } catch (e: Exception) {
                    Log.e(TAG, "Error in deInitialize flush", e)
                }
            }

            Log.d(TAG, "✅ IRKitUI.deInitialize() completed")

        } catch (e: Exception) {
            Log.e(TAG, "Failed to deInitialize IRKitUI", e)
        }

        // Note: We intentionally do NOT reset isInitialized here
        // because the user might re-enter IRKitLensActivity and we want
        // analytics to continue working without re-initialization.
        // The AnalyticsClient instance persists across activity lifecycle.
    }
}
