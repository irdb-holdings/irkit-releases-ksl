package com.irdb.irkitui.lifecycle

import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.irdb.irkitui.IRKitUI
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Observes app-level foreground/background transitions via ProcessLifecycleOwner.
 *
 * On each foreground event after a real background, re-fetches the lens
 * configuration via IRKitUI.refreshLensConfig(). Does NOT re-initialize
 * camera, analytics, or anything visible to the user.
 *
 * When the lens is visible, this observer skips the refresh because the
 * lens's own repeatOnLifecycle(STARTED) callback handles it — and fires
 * after the network stack has reconnected, avoiding DNS resolution failures.
 *
 * Registered once during IRKitUI.initialize(). Client apps do nothing.
 */
internal class AppLifecycleObserver : DefaultLifecycleObserver {

    companion object {
        private const val TAG = "AppLifecycleObserver"
        private const val NETWORK_SETTLE_DELAY_MS = 500L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Only call getLens after a real background→foreground transition.
    // Starts false so the first onStart (which fires during init) is ignored.
    @Volatile
    private var hasBeenBackgrounded = false

    override fun onStop(owner: LifecycleOwner) {
        hasBeenBackgrounded = true
        Log.d(TAG, "App backgrounded")
    }

    override fun onStart(owner: LifecycleOwner) {
        if (!hasBeenBackgrounded) {
            Log.d(TAG, "First onStart — skipping (initialize already fetched lens)")
            return
        }

        if (IRKitUI.isLensVisible) {
            Log.d(TAG, "App foregrounded — lens is visible, skipping (lens callback will refresh)")
            return
        }

        Log.d(TAG, "App foregrounded — refreshing lens config")
        scope.launch {
            // Brief delay lets the network stack reconnect after background.
            // Without this, DNS resolution can fail on immediate foreground.
            delay(NETWORK_SETTLE_DELAY_MS)
            try {
                IRKitUI.refreshLensConfig()
            } catch (e: Exception) {
                Log.w(TAG, "Foreground refresh failed — will retry on next lens open", e)
            }
        }
    }
}
