package com.irdb.irkitui.ui.components

import com.irdb.irkit.ImageModel

/**
 * Primary headline for the compressed recognition banner.
 * Uses line1 from the API response directly.
 */
fun ImageModel.collapsedPeekPrimaryLabel(): String =
    line1.trim()

/**
 * Secondary line for the compressed card.
 * Uses line2 from the API response directly.
 */
fun ImageModel.collapsedPeekSubtitle(): String =
    line2.trim()
