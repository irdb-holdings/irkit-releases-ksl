package com.irdb.irkitui.configuration.ircode

import com.irdb.irkitui.BuildConfig
import com.irdb.irkitui.configuration.ClientConfigBase

/**
 * Configuration values for the IRCODE app (primary/default client).
 * Contains Dev, Staging, and Production variants.
 */
object IrcodeConfig {

    object Dev : ClientConfigBase() {
        override val clientName = "IRCODE"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_44"
        override val irEngineUrl = "https://dev.backend.irdb.com/v1"
        override val irkitSubscriptionKey = "C86CEC4A751E40DE9CBCCAD53868F2EB4D49ECC12F1044D68BD53BF6FEE393FE097D5473D714402C81360CB9623FD208"
        override val analyticsApiKey = "C86CEC4A751E40DE9CBCCAD53868F2EB4D49ECC12F1044D68BD53BF6FEE393FE097D5473D714402C81360CB9623FD208"
        override val analyticsApiKeyHeaderName = "sdkapikey"
        override val companyName = "irdb"
        override val analyticsBucketName = "irdbMain"
        override val environment = "development"
        override val prefsEncryptionKey = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
        override val prefsEncryptionSalt = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
    }

    object Staging : ClientConfigBase() {
        override val clientName = "IRCODE"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/staging-v1_44"
        override val irEngineUrl = "https://staging.backend.irdb.com/v1"
        override val irkitSubscriptionKey = Dev.irkitSubscriptionKey
        override val analyticsApiKey = Dev.analyticsApiKey
        override val analyticsApiKeyHeaderName = Dev.analyticsApiKeyHeaderName
        override val companyName = Dev.companyName
        override val analyticsBucketName = Dev.analyticsBucketName
        override val environment = "staging"
        override val prefsEncryptionKey = Dev.prefsEncryptionKey
        override val prefsEncryptionSalt = Dev.prefsEncryptionSalt
    }

    object Production : ClientConfigBase() {
        override val clientName = "IRCODE"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
        override val irEngineUrl = "https://production.backend.irdb.com/v1"
        override val irkitSubscriptionKey = Dev.irkitSubscriptionKey
        override val analyticsApiKey = Dev.analyticsApiKey
        override val analyticsApiKeyHeaderName = Dev.analyticsApiKeyHeaderName
        override val companyName = Dev.companyName
        override val analyticsBucketName = Dev.analyticsBucketName
        override val environment = "production"
        override val prefsEncryptionKey = Dev.prefsEncryptionKey
        override val prefsEncryptionSalt = Dev.prefsEncryptionSalt
    }

    /**
     * Returns the appropriate configuration based on the current build flavor.
     */
    val current: ClientConfigBase
        get() = when (BuildConfig.FLAVOR) {
            "staging" -> Staging
            "production" -> Production
            else -> Dev
        }
}
