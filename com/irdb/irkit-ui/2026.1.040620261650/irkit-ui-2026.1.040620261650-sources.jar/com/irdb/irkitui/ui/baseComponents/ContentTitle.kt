package com.irdb.irkitui.ui.baseComponents

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun ContentTitle(
    title: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    Text(
        text = title,
        style = TextStyle(
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = color
        ),
        modifier = modifier
    )
}

/** Compressed card text colors (iOS / ForAndroid spec). */
@Composable
fun collapsedPeekPrimaryTextColor(): Color =
    if (true) Color(0xFFE6E6E6) else Color(0xFF12121A) // TODO: Temporarily force dark mode; light mode support coming later

@Composable
fun ContentTitleForCollapsed(
    title: String,
    modifier: Modifier = Modifier,
    color: Color? = null,
    fontSize: TextUnit = 24.sp,
    fontWeight: FontWeight = FontWeight.ExtraBold,
    maxLines: Int = 2,
    topPaddingWhenSubtitleEmpty: Boolean = false
) {
    val resolvedColor = color ?: collapsedPeekPrimaryTextColor()
    Text(
        text = title,
        style = TextStyle(
            fontSize = fontSize,
            fontWeight = fontWeight,
            color = resolvedColor,
            textAlign = TextAlign.Start
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier.then(
            if (topPaddingWhenSubtitleEmpty) Modifier.padding(top = 8.dp) else Modifier
        )
    )
}

@Composable
fun ContentSubtitleForCollapsed(
    text: String,
    modifier: Modifier = Modifier,
    color: Color? = null
) {
    val resolvedColor = color ?: collapsedPeekPrimaryTextColor()
    Text(
        text = text,
        style = TextStyle(
            fontSize = 15.sp,
            fontWeight = FontWeight.Normal,
            color = resolvedColor,
            textAlign = TextAlign.Start
        ),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun ContentTitlePreview() {
    IRKitUITheme {
        ContentTitle(title = "Sample Image Title")
    }
}

@Preview(showBackground = true)
@Composable
fun ContentTitleCollapsedPreview() {
    IRKitUITheme {
        ContentTitleForCollapsed(
            title = "A Very Long Preview Title That Should Demonstrate Text Overflow Handling in Various Components"
        )
    }
}
