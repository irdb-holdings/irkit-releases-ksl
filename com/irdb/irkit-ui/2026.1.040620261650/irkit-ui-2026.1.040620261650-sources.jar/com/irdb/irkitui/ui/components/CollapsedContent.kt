package com.irdb.irkitui.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.irdb.irkit.ImageModel
import com.irdb.irkit.enums.CardTypes
import com.irdb.irkit.getCardTypeEmum
import com.irdb.irkitui.ui.baseComponents.ContentSubtitleForCollapsed
import com.irdb.irkitui.ui.baseComponents.ContentTitleForCollapsed

@Composable
fun CollapsedContent(
    image: ImageModel,
    isExpanded: Boolean = true,
    modifier: Modifier = Modifier
) {
    val subtitle = image.collapsedPeekSubtitle()
    val subtitleNonEmpty = subtitle.isNotBlank()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 14.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ThumbNailScaled(image, isExpanded)

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp),
            horizontalAlignment = Alignment.Start
        ) {
            when (image.getCardTypeEmum()) {
                CardTypes.Contact -> CollapsedContactContent(image)
                else -> {
                    ContentTitleForCollapsed(
                        title = image.collapsedPeekPrimaryLabel(),
                        maxLines = 2,
                        topPaddingWhenSubtitleEmpty = !subtitleNonEmpty
                    )
                    ContentSubtitleForCollapsed(text = subtitle)
                }
            }
        }
    }
}
