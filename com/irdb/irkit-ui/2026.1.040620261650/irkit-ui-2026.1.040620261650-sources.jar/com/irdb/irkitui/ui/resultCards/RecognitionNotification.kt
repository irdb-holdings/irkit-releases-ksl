package com.irdb.irkitui.ui.resultCards

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isFinite
import androidx.compose.ui.unit.sp
import com.irdb.irkit.IRKit
import com.irdb.irkit.ImageModel
import com.irdb.irkit.getFooterCTALink
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.UserDto
import com.irdb.irkit.enums.IRKitResourceProvider
import com.irdb.irkit.enums.ImageStatus
import com.irdb.irkitui.internal.AppDetection
import com.irdb.irkitui.theme.IRKitUITheme
import com.irdb.irkitui.ui.baseComponents.GripView
import com.irdb.irkitui.ui.components.CollapsedContent
import com.irdb.irkitui.ui.components.ContentMetaLinksView
import com.irdb.irkitui.ui.internal.NotificationActionButtons

// This is what is shown when the AI recognizes something

// Constants for positioning the expanded content
private const val X_BUTTON_SIZE_DP = 80
private const val X_BUTTON_TO_EXPANDED_CONTENT_GAP_DP = 10 // Gap between expanded content bottom and X button top

/**
 * Default top padding for expanded notification to ensure proper spacing from the top of the view.
 * Lower value = notification starts higher (closer to top), allowing it to stretch down more
 * Higher value = notification starts lower (farther from top), reducing vertical space
 * Can be overridden via topContentPadding parameter for flexibility.
 */
private const val EXPANDED_NOTIFICATION_STARTING_POSITION_DP = 40

/**
 * Distance in dp that the collapsed notification should be positioned from the bottom of the screen.
 * Adjust this value to move the collapsed card up (higher value) or down (lower value).
 */
private const val COLLAPSED_BOTTOM_OFFSET_DP = 70

/**
 * Distance in dp that the expanded notification should be positioned from the bottom of the screen.
 * Adjust this value to move the expanded card up (higher value) or down (lower value).
 */
private const val EXPANDED_BOTTOM_OFFSET_DP = 125

/**
 * Vertical spacing between the notification card and the action buttons (share/bookmark).
 * This constant makes it easy to adjust the gap between the card and buttons.
 */
private const val NOTIFICATION_CARD_TO_BUTTONS_SPACING_DP = 5

/** Collapsed peek: iOS spec fill, 16dp radius, 1.6dp diagonal gradient border. */
@Composable
private fun CollapsedRecognitionCardChrome(
    modifier: Modifier = Modifier,
    gradientHeightHint: Dp,
    content: @Composable () -> Unit
) {
    val isDark = true // TODO: Temporarily force dark mode; light mode support coming later
    val fillColor = if (isDark) Color(0xFF372E38) else Color(0xFFE7E2E9)
    val outerShape = RoundedCornerShape(16.dp)
    val borderWidth = 1.6.dp
    val innerShape = RoundedCornerShape(14.4.dp)

    Box(
        modifier = modifier.shadow(
            elevation = 8.dp,
            shape = outerShape,
            ambientColor = Color.Black.copy(alpha = 0.22f),
            spotColor = Color.Black.copy(alpha = 0.22f)
        )
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            val density = LocalDensity.current
            val wPx = with(density) { maxWidth.toPx().coerceAtLeast(1f) }
            val hPx = with(density) {
                if (maxHeight.isFinite) {
                    minOf(maxHeight.toPx(), gradientHeightHint.toPx()).coerceAtLeast(1f)
                } else {
                    gradientHeightHint.toPx().coerceAtLeast(1f)
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .background(
                        brush = Brush.linearGradient(
                            colorStops = arrayOf(
                                0f to Color.White.copy(alpha = 0.40f),
                                0.41f to Color.White.copy(alpha = 0f),
                                0.57f to Color.White.copy(alpha = 0f),
                                1f to Color.White.copy(alpha = 0.10f)
                            ),
                            start = Offset.Zero,
                            end = Offset(wPx, hPx)
                        ),
                        shape = outerShape
                    )
                    .padding(borderWidth)
                    .background(color = fillColor, shape = innerShape)
            ) {
                Column(modifier = Modifier.padding(5.dp)) {
                    content()
                }
            }
        }
    }
}

@Composable
fun RecognitionNotification(
    image: ImageModel,
    isLoading: Boolean,
    isExpanded: Boolean = false,
    onExpandChange: (Boolean) -> Unit = {},
    expandedContent: (@Composable () -> Unit)? = null,
    onLinkClick: ((MetaContent.Link) -> Unit)? = null,
    contentMetaLinksViewResourceProvider: IRKitResourceProvider? = null,
    modifier: Modifier = Modifier,
    topContentPadding: Dp = EXPANDED_NOTIFICATION_STARTING_POSITION_DP.dp // Default to legacy value for backward compatibility
) {
    // Check if running in official app (internal feature)
    val context = LocalContext.current
    val showActionButtons = remember { AppDetection.isOfficialApp(context) }

    val ActionButtonsHeight = if (showActionButtons) 58.dp else 0.dp
    val NotificationBottomOffset = if (isExpanded) EXPANDED_BOTTOM_OFFSET_DP.dp else COLLAPSED_BOTTOM_OFFSET_DP.dp
    val CardToButtonsSpacing = if (showActionButtons) NOTIFICATION_CARD_TO_BUTTONS_SPACING_DP.dp else 0.dp

    val previewCardVerticalSize = 140.dp // Title (up to 2 lines @ 20sp) + subtitle + handle + iOS spec padding

    // Position the entire Column (card + buttons) within the IRKitLens view rectangle.
    // When expanded, fill available space using padding to define top/bottom boundaries.
    // This lets Android handle sizing across all screen densities — no manual calculation needed.
    Column(
        modifier = modifier
            .then(
                if (isExpanded && image.showSmartView) {
                    // WebView/browser: fill all available space between back arrow and X button
                    Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .padding(top = 56.dp, bottom = NotificationBottomOffset + 16.dp)
                } else {
                    // Collapsed or regular expanded cards: original layout
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = NotificationBottomOffset)
                }
            )
    ) {
        
        if (!isExpanded) {
            CollapsedRecognitionCardChrome(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .heightIn(max = previewCardVerticalSize)
                    .clickable {
                        android.util.Log.d(
                            "RecognitionNotification",
                            "Card clicked. isExpanded=$isExpanded, hasExpandedContent=${expandedContent != null}"
                        )
                        onExpandChange(!isExpanded)
                    },
                gradientHeightHint = previewCardVerticalSize
            ) {
                if (expandedContent != null) {
                    GripView(
                        onClick = {
                            onExpandChange(!isExpanded)
                        }
                    )
                }
                CollapsedContent(image = image, isExpanded = false)
            }
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (image.showSmartView) Modifier.weight(1f) // WebView: fill all available space
                        else Modifier.wrapContentHeight() // Regular cards: wrap content naturally
                    )
                    .padding(start = 16.dp, end = 16.dp, top = 0.dp),
                colors = if (image.showSmartView) CardDefaults.cardColors() else CardDefaults.cardColors(
                    containerColor = Color(0xFF2C2C2E)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(vertical = 0.dp)) {
                    if (expandedContent != null) {
                        expandedContent()
                    }
                }
            }
        }

        // CTA button below the notification card (both collapsed and expanded)
        // Selection logic matches iOS: one CTA based on card type and onScanDisplay flag
        if (onLinkClick != null) {
            val footerCTA = image.getFooterCTALink()
            if (footerCTA != null) {
                Spacer(modifier = Modifier.height(8.dp))
                ContentMetaLinksView(
                    image = image,
                    onClick = { link -> onLinkClick(link) },
                    resourceProvider = contentMetaLinksViewResourceProvider,
                    modifier = Modifier.padding(horizontal = 16.dp),
                    links = listOf(footerCTA)
                )
            }
        }

        // Automatically show action buttons if official app (internal feature)
        // Buttons are positioned at the bottom of the Column with consistent spacing
        if (showActionButtons) {
            Spacer(modifier = Modifier.height(CardToButtonsSpacing))
            NotificationActionButtons(
                image = image,
                onSaveClick = { IRKit.invokeSaveCallback(it) },
                onShareClick = { IRKit.invokeShareCallback(it) }
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun RecognitionNotificationPreview() {
    val previewImage = ImageModel.FullImage(
        title = "Mock Recognition Result",
        description = "Mock description that is long enough to show multiple lines of text and demonstrate the ellipsis behavior",
        imageId = "",
        displayImageUrl = "https://upload.wikimedia.org/wikipedia/en/f/f7/Inside_Out_2_poster.jpg",
        campaignId = 1,
        campaignName = "1",
        products = emptyList(),
        metaItems = emptyList(),
        location = null,
        imageSize = 0,
        imageHeight = 0,
        imageWidth = 0,
        bucketName = "",
        trackingId = "",
        imageUser = UserDto(
            email = "",
            phone = "",
            userId = 2,
            fullName = "",
            userName = "",
            profileUrl = ""
        ),
        isFromManualCapture = false,
        imageStatus = ImageStatus.PUBLISH
    )

    var isExpanded by remember { mutableStateOf(false) }

    RecognitionNotification(
        image = previewImage,
        isLoading = false,
        isExpanded = isExpanded,
        onExpandChange = { isExpanded = it },
        expandedContent = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Expanded Content",
                    style = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = "This is some sample expanded content to show how it looks.",
                    modifier = Modifier.padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
private fun RecognitionNotificationExpandedPreview() {
    val previewImage = ImageModel.FullImage(
        title = "Mock Recognition Result",
        description = "Mock description that is long enough to show multiple lines of text and demonstrate the ellipsis behavior",
        imageId = "",
        displayImageUrl = "https://upload.wikimedia.org/wikipedia/en/f/f7/Inside_Out_2_poster.jpg",
        campaignId = 1,
        campaignName = "1",
        products = emptyList(),
        metaItems = emptyList(),
        location = null,
        imageSize = 0,
        imageHeight = 0,
        imageWidth = 0,
        bucketName = "",
        trackingId = "",
        imageUser = UserDto(
            email = "",
            phone = "",
            userId = 2,
            fullName = "",
            userName = "",
            profileUrl = ""
        ),
        isFromManualCapture = false,
        imageStatus = ImageStatus.PUBLISH
    )

    var isExpanded by remember { mutableStateOf(true) }

    RecognitionNotification(
        image = previewImage,
        isLoading = false,
        isExpanded = isExpanded,
        onExpandChange = { isExpanded = it },
        expandedContent = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Expanded Content",
                    style = TextStyle(
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = "This is some sample expanded content to show how it looks.",
                    modifier = Modifier.padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    )
}
