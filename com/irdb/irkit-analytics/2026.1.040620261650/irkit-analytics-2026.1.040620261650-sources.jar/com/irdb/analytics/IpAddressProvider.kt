package com.irdb.analytics

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Provider for fetching and caching the device's public IP address.
 * Fetches IP from the /myip endpoint and caches it for use in analytics events.
 */
internal class IpAddressProvider(
    private val config: AnalyticsConfig,
    private val userPreferences: UserPreferences,
    private val logger: AnalyticsLogger
) {
    companion object {
        private const val MAX_RETRY_ATTEMPTS = 3
        private const val RETRY_DELAY_MS = 1000L // 1 second base delay, multiplied by attempt number
    }
    /**
     * Get the cached IP address, or fetch it from the server if not cached.
     * Falls back to local IP detection if the API call fails.
     * 
     * @return The IP address string, or null if unavailable
     */
    suspend fun getIpAddress(): String? = withContext(Dispatchers.IO) {
        // First, check if we have a cached IP address
        val cachedIp = userPreferences.loadCachedIpAddress()
        if (cachedIp != null) {
            logger.logDebug("🌐 [IP] Using cached IP address: $cachedIp")
            return@withContext cachedIp
        }
        
        // No cached IP - fetch from /myip endpoint with retry
        logger.logDebug("🌐 [IP] No cached IP found, fetching from server...")

        for (attempt in 1..MAX_RETRY_ATTEMPTS) {
            val fetchedIp = fetchIpFromServer()
            if (fetchedIp != null) {
                userPreferences.saveCachedIpAddress(fetchedIp)
                logger.logDebug("🌐 [IP] Fetched and cached IP address: $fetchedIp (attempt $attempt)")
                return@withContext fetchedIp
            }
            if (attempt < MAX_RETRY_ATTEMPTS) {
                val delayMs = RETRY_DELAY_MS * attempt
                logger.logDebug("🌐 [IP] Attempt $attempt failed, retrying in ${delayMs}ms...")
                kotlinx.coroutines.delay(delayMs)
            }
        }

        // All retries failed - do NOT fall back to local/private IP detection.
        // Private IPs (10.x, 192.168.x) cause the backend to derive garbage lat/long values.
        logger.logDebug("🌐 [IP] All $MAX_RETRY_ATTEMPTS attempts failed, no IP available")
        return@withContext null
    }
    
    /**
     * Fetch IP address from the /myip endpoint.
     * Uses the base URL from config.apiEndpoint and appends /myip.
     * 
     * @return The IP address string, or null if the request fails
     */
    private suspend fun fetchIpFromServer(): String? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        
        return@withContext try {
            // Build the /myip endpoint URL from the base API endpoint
            // Extract base URL by removing the last path component (e.g., /Statistics)
            // Example: https://.../development-v1_43/Statistics -> https://.../development-v1_43/myip
            val baseUrl = config.apiEndpoint.substringBeforeLast("/")
            val myipUrl = "$baseUrl/myip"
            
            logger.logDebug("🌐 [IP] Fetching IP from: $myipUrl")
            
            val url = URL(myipUrl)
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.doInput = true
            
            // Set standard headers
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty(config.apiKeyHeaderName, config.apiKey)
            
            // Add custom headers
            config.customHeaders.forEach { (key, value) ->
                connection.setRequestProperty(key, value)
            }
            
            // Set timeouts
            connection.connectTimeout = config.connectTimeout.inWholeMilliseconds.toInt()
            connection.readTimeout = config.readTimeout.inWholeMilliseconds.toInt()
            
            // Read response
            val responseCode = connection.responseCode
            
            if (responseCode in 200..299) {
                val responseBody = connection.inputStream?.let { inputStream ->
                    BufferedReader(InputStreamReader(inputStream, "UTF-8")).use { reader ->
                        reader.readText()
                    }
                } ?: ""
                
                connection.disconnect()
                connection = null
                
                // Parse the response - expect plain text IP address or JSON with "ip" field
                val ipAddress = parseIpResponse(responseBody)
                
                if (ipAddress != null) {
                    logger.logDebug("🌐 [IP] Successfully fetched IP: $ipAddress")
                } else {
                    logger.logError("🌐 [IP] Failed to parse IP from response: $responseBody")
                }
                
                ipAddress
            } else {
                val errorBody = connection.errorStream?.let { errorStream ->
                    BufferedReader(InputStreamReader(errorStream, "UTF-8")).use { reader ->
                        reader.readText()
                    }
                } ?: ""
                
                connection.disconnect()
                connection = null
                
                logger.logError("🌐 [IP] HTTP error $responseCode when fetching IP: $errorBody")
                null
            }
        } catch (e: Exception) {
            connection?.disconnect()
            logger.logError("🌐 [IP] Exception when fetching IP from server: ${e.message}", e)
            null
        }
    }
    
    /**
     * Parse the IP address from the server response.
     * Handles both plain text and JSON responses.
     * 
     * Expected formats:
     * - Plain text: "192.168.1.1"
     * - JSON: {"ip": "192.168.1.1"}
     * 
     * @param responseBody The response body from the server
     * @return The parsed IP address, or null if parsing fails
     */
    private fun parseIpResponse(responseBody: String): String? {
        val trimmed = responseBody.trim()
        
        if (trimmed.isEmpty()) {
            return null
        }
        
        // Try to parse as JSON first
        if (trimmed.startsWith("{")) {
            return try {
                // Simple JSON parsing for {"ip": "..."} format
                val ipPattern = """"ip"\s*:\s*"([^"]+)"""".toRegex()
                val match = ipPattern.find(trimmed)
                match?.groupValues?.get(1)
            } catch (e: Exception) {
                logger.logError("🌐 [IP] Failed to parse JSON response: ${e.message}", e)
                null
            }
        }
        
        // Otherwise, treat as plain text IP address
        // Validate it looks like an IP address (basic validation)
        val ipPattern = """^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$""".toRegex()
        return if (ipPattern.matches(trimmed)) {
            trimmed
        } else {
            logger.logError("🌐 [IP] Response doesn't match IP address pattern: $trimmed")
            null
        }
    }
    
    /**
     * Clear the cached IP address.
     * This forces a fresh fetch on the next getIpAddress() call.
     */
    fun clearCache() {
        userPreferences.clearCachedIpAddress()
        logger.logDebug("🌐 [IP] Cleared cached IP address")
    }
}
