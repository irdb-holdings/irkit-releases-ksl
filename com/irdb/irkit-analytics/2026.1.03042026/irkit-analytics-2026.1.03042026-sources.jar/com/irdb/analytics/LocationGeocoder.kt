package com.irdb.analytics

import android.content.Context
import android.location.Geocoder
import android.location.Address
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Utility for reverse geocoding: converting latitude/longitude coordinates to human-readable addresses.
 * Used to populate the `locationLookup` field in analytics events.
 * 
 * **Performance:** Results are cached to avoid repeated geocoding of the same coordinates.
 * **Cost:** Free - uses Android's built-in Geocoder (no Google Maps API billing required).
 */
internal class LocationGeocoder(
    private val context: Context,
    private val logger: AnalyticsLogger
) {
    // Cache geocoding results to avoid repeated API calls for the same coordinates
    // Key: "lat,lng" rounded to 4 decimal places (~11 meters precision)
    // Value: Pair(timestamp, address string)
    private val geocodeCache = mutableMapOf<String, Pair<Long, String>>()
    
    // Cache duration: 5 minutes (same as location cache)
    private val CACHE_DURATION_MS = 5 * 60 * 1000L
    
    // Round coordinates to 4 decimal places for caching (~11 meters precision)
    // This prevents cache misses for tiny GPS variations
    private fun roundCoordinate(coord: Double): Double {
        return (coord * 10000).toInt().toDouble() / 10000
    }
    
    private fun getCacheKey(latitude: Double, longitude: Double): String {
        val roundedLat = roundCoordinate(latitude)
        val roundedLng = roundCoordinate(longitude)
        return "$roundedLat,$roundedLng"
    }
    /**
     * Convert latitude and longitude to a formatted address string.
     * Results are cached to avoid repeated geocoding of the same coordinates.
     * 
     * @param latitude The latitude coordinate (must be between -90 and 90)
     * @param longitude The longitude coordinate (must be between -180 and 180)
     * @return A formatted address string (e.g., "123 Main St, New York, NY 10001, USA") or null if geocoding fails
     */
    suspend fun getLocationLookup(latitude: Double, longitude: Double): String? {
        // Validate coordinates are within valid ranges
        if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
            logger.logDebug("📍 [Geocoder] Invalid coordinates: lat=$latitude, lng=$longitude")
            return null
        }
        
        return withContext(Dispatchers.IO) {
            try {
                // Check cache first
                val cacheKey = getCacheKey(latitude, longitude)
                val now = System.currentTimeMillis()
                
                geocodeCache[cacheKey]?.let { (cacheTime, cachedAddress) ->
                    val age = (now - cacheTime) / 1000
                    if (now - cacheTime < CACHE_DURATION_MS) {
                        logger.logDebug("📍 [Geocoder] Cache HIT (${age}s old): $cachedAddress")
                        return@withContext cachedAddress
                    } else {
                        // Cache expired, remove it
                        geocodeCache.remove(cacheKey)
                        logger.logDebug("📍 [Geocoder] Cache expired (${age}s old), fetching fresh")
                    }
                }
                
                // Check if Geocoder is available on this device
                if (!Geocoder.isPresent()) {
                    logger.logDebug("📍 [Geocoder] Geocoder service not available on this device")
                    return@withContext null
                }
                
                val geocoder = Geocoder(context, Locale.getDefault())
                
                // Perform reverse geocoding (coordinates -> address)
                val addresses: List<Address>? = try {
                    geocoder.getFromLocation(latitude, longitude, 1)
                } catch (e: Exception) {
                    logger.logDebug("📍 [Geocoder] Error during geocoding: ${e.message}")
                    return@withContext null
                }
                
                if (addresses.isNullOrEmpty()) {
                    logger.logDebug("📍 [Geocoder] No address found for lat=$latitude, lng=$longitude")
                    return@withContext null
                }
                
                val address = addresses[0]
                val locationLookup = formatAddress(address)
                
                if (locationLookup != null) {
                    // Cache the result
                    geocodeCache[cacheKey] = now to locationLookup
                    logger.logDebug("📍 [Geocoder] Success (cached): $locationLookup")
                } else {
                    logger.logDebug("📍 [Geocoder] Address found but could not format")
                }
                
                locationLookup
            } catch (e: Exception) {
                logger.logDebug("📍 [Geocoder] Exception during reverse geocoding: ${e.message}")
                null
            }
        }
    }
    
    /**
     * Clear the geocoding cache (useful for testing or memory management).
     */
    fun clearCache() {
        geocodeCache.clear()
        logger.logDebug("📍 [Geocoder] Cache cleared")
    }
    
    /**
     * Format an Address object into a readable string.
     * Format: "Street Address, City, State ZIP, Country"
     * Falls back to simpler formats if some fields are missing.
     */
    private fun formatAddress(address: Address): String? {
        val parts = mutableListOf<String>()
        
        // Street address (thoroughfare + subthoroughfare)
        val streetAddress = buildString {
            address.subThoroughfare?.let { append(it).append(" ") }
            address.thoroughfare?.let { append(it) }
        }.trim()
        
        if (streetAddress.isNotEmpty()) {
            parts.add(streetAddress)
        }
        
        // City
        address.locality?.let { parts.add(it) }
        
        // State and ZIP
        val stateZip = buildString {
            address.adminArea?.let { append(it) }
            address.postalCode?.let { 
                if (address.adminArea != null) append(" ") 
                append(it) 
            }
        }.trim()
        
        if (stateZip.isNotEmpty()) {
            parts.add(stateZip)
        }
        
        // Country
        address.countryName?.let { parts.add(it) }
        
        // If we have at least some information, return formatted string
        return if (parts.isNotEmpty()) {
            parts.joinToString(", ")
        } else {
            // Fallback: try to get any available address line
            address.getAddressLine(0)?.takeIf { it.isNotEmpty() }
        }
    }
}
