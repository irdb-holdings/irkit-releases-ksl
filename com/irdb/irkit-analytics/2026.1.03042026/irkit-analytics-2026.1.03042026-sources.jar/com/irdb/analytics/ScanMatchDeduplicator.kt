package com.irdb.analytics

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Deduplication mechanism for scan match events.
 * Prevents CONSECUTIVE duplicate submissions of the same imageID/assetID.
 * 
 * Rule: Only block analytics if the SAME imageId is detected back-to-back (consecutively).
 * This allows the sequence A → B → A to send 3 analytics calls (all different from previous),
 * but blocks A → A → A to send only 1 call (2nd and 3rd are consecutive duplicates).
 * 
 * Examples:
 * - A → B → C → sends 3 calls (all different from previous)
 * - A → A → A → sends 1 call (2nd and 3rd are consecutive duplicates)
 * - A → (no hit) → A → sends 1 call (2nd A is consecutive duplicate)
 * - A → B → A → sends 3 calls (2nd A is different from previous B)
 */
internal class ScanMatchDeduplicator {
    private val mutex = Mutex()
    
    // Track only the last scanned imageID to detect consecutive duplicates
    private var lastScannedImageId: String? = null
    
    /**
     * Check if a match should be submitted (not a consecutive duplicate).
     * 
     * @param imageId The imageID or assetID to check
     * @return true if the match should be submitted (different from last), false if it's a consecutive duplicate
     */
    suspend fun shouldSubmitMatch(imageId: String, currentTimeSeconds: Long = System.currentTimeMillis() / 1000): Boolean {
        return mutex.withLock {
            if (imageId == lastScannedImageId) {
                // Same as last scan - consecutive duplicate, skip
                false
            } else {
                // Different from last scan - allow and update
                lastScannedImageId = imageId
                true
            }
        }
    }
    
    /**
     * Mark a match as submitted (update the last scanned imageID).
     * 
     * @param imageId The imageID or assetID that was submitted
     */
    suspend fun markAsSubmitted(imageId: String) {
        mutex.withLock {
            lastScannedImageId = imageId
        }
    }
    
    /**
     * Clear the deduplication state (resets last scanned imageID).
     */
    suspend fun clear() {
        mutex.withLock {
            lastScannedImageId = null
        }
    }
    
    /**
     * Remove/reset the last scanned imageID (for compatibility).
     * 
     * @param imageId The imageID to remove (ignored in consecutive-only mode)
     */
    suspend fun remove(imageId: String) {
        mutex.withLock {
            // In consecutive-only mode, just reset the last scanned ID
            lastScannedImageId = null
        }
    }
    
    /**
     * Get the number of tracked matches (for debugging).
     * Returns 1 if there's a last scanned ID, 0 otherwise.
     */
    suspend fun getTrackedCount(): Int {
        return mutex.withLock {
            if (lastScannedImageId != null) 1 else 0
        }
    }
}

