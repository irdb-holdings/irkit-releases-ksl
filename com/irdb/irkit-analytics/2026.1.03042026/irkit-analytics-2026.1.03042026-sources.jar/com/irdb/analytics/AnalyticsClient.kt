package com.irdb.analytics

import android.app.Application
import android.content.Context
import android.util.Log
import com.irdb.analytics.models.CacheStats
import com.irdb.analytics.models.EventPayload
import com.irdb.analytics.models.UserContext
import com.irdb.analytics.utils.SessionTrackingIdGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Main public API for analytics tracking.
 * Provides a simple, clean interface for apps to track events.
 */
class AnalyticsClient private constructor(
    private val config: AnalyticsConfig,
    private val context: Context
) {
    private val logger = AnalyticsLogger(config)
    private val timerManager = TimerManager(logger)
    private val deviceInfoDetector = DeviceInfoDetector(context)
    private val locationProvider = LocationProvider(context, logger)
    private val locationGeocoder = LocationGeocoder(context, logger)
    private val userPreferences = UserPreferences(context)
    private val ipAddressProvider = IpAddressProvider(config, userPreferences, logger)
    // v2.0: advertisingIdProvider removed (deviceIFA no longer sent)
    private val cache = AnalyticsCache(context, config, logger)
    private val repository = AnalyticsRepository(config, logger, cache)
    private val lifecycleTracker = LifecycleTracker(this, config, logger, userPreferences)
    private val networkMonitor = NetworkMonitor(
        context,
        onConnectivityRestored = { flush() },
        logger
    )
    private val scanMatchDeduplicator = ScanMatchDeduplicator()
    private val viewCompressedDeduplicator = ViewCompressedDeduplicator()
    private val viewEventBuffer = ViewEventBuffer(logger)

    private var userContext: UserContext? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    
    // Current session tracking ID: generated each time onSessionStarted() is called
    // This ID is used for all events until the next onSessionStarted() call
    private var currentSessionTrackingId: String? = null
    
    // Session-level geocoding cache: geocode once per session, reuse for all events
    // Key: "lat,lng" rounded to 4 decimal places, Value: geocoded address string
    private var sessionGeocodeCache: Pair<String, String>? = null
    
    /**
     * Round coordinates to 4 decimal places (~11 meters precision) for session caching.
     * This prevents cache misses for tiny GPS variations within the same location.
     */
    private fun roundCoordinate(coord: Double): Double {
        return (coord * 10000).toInt().toDouble() / 10000
    }
    
    /**
     * Get cache key for coordinates (rounded to avoid cache misses from minor GPS variations).
     */
    private fun getLocationCacheKey(latitude: Double, longitude: Double): String {
        val roundedLat = roundCoordinate(latitude)
        val roundedLng = roundCoordinate(longitude)
        return "$roundedLat,$roundedLng"
    }
    
    /**
     * Get location lookup for coordinates, using session-level cache.
     * Geocodes once per session and reuses the result for all events.
     */
    private suspend fun getSessionLocationLookup(latitude: Double, longitude: Double): String? {
        val cacheKey = getLocationCacheKey(latitude, longitude)
        
        // Check session cache first
        sessionGeocodeCache?.let { (cachedKey, cachedAddress) ->
            if (cachedKey == cacheKey) {
                logger.logDebug("📍 [Geocoder] Session cache HIT: $cachedAddress")
                return cachedAddress
            } else {
                // Location changed significantly, clear cache and geocode new location
                logger.logDebug("📍 [Geocoder] Location changed, clearing session cache")
                sessionGeocodeCache = null
            }
        }
        
        // No cache hit - geocode once for this session
        logger.logDebug("📍 [Geocoder] Geocoding once for this session: lat=$latitude, lng=$longitude")
        val locationLookup = locationGeocoder.getLocationLookup(latitude, longitude)
        
        // Cache the result for this session
        if (locationLookup != null) {
            sessionGeocodeCache = cacheKey to locationLookup
            logger.logDebug("📍 [Geocoder] Session cache updated: $locationLookup")
        }
        
        return locationLookup
    }
    
    init {
        // Initialize repository (loads cached events)
        scope.launch {
            repository.initialize()
        }
        
        // Load persisted userID and merge into userContext if not already set
        scope.launch {
            val persistedUserId = userPreferences.loadUserId()
            persistedUserId?.let { userId ->
                // If userContext is not set, create a minimal one with persisted userID
                // This ensures userID is available for all events even before setUserContext is called
                if (userContext == null) {
                    val deviceInfo = if (config.autoDetectDeviceInfo) {
                        deviceInfoDetector.detectDeviceInfo()
                    } else {
                        null
                    }
                    
                    userContext = UserContext(
                        userId = userId,
                        sessionSource = buildSessionSource("Android", config.companyName, config.bucketName),
                        deviceType = deviceInfo?.deviceType ?: "Android",
                        userAgent = deviceInfo?.userAgent,
                        networkType = deviceInfo?.networkType
                    )
                } else {
                    // If userContext exists but doesn't have userId, merge it in
                    if (userContext?.userId.isNullOrEmpty()) {
                        userContext = userContext?.copy(userId = userId)
                    }
                }
            }
        }
        
        // Check for unsent session-ended event from previous session
        // This handles cases where the app was killed, crashed, or force-stopped
        scope.launch {
            logger.logDebug("🔍 [Recovery] Checking for pending session end from previous session...")
            val pendingSessionEnd = userPreferences.loadPendingSessionEnd()
            if (pendingSessionEnd != null) {
                logger.logDebug("🔄 [Recovery] Found pending session-ended event from previous session: ${pendingSessionEnd.sessionTrackingId}")
                logger.logDebug("🔄 [Recovery] Session start: ${pendingSessionEnd.sessionStartTimestamp}, end: ${pendingSessionEnd.sessionEndTimestamp}")
                logger.logDebug("🔄 [Recovery] Duration: ${pendingSessionEnd.sessionEndTimestamp - pendingSessionEnd.sessionStartTimestamp}ms")
                
                // Send session-ended event for the PREVIOUS session
                // CRITICAL: Use the original sessionTrackingId from the closed session
                trackStatusEvent(
                    statusType = StatusType.SESSION_STOPPED,
                    additionalParams = mapOf(
                        "sessionDuration" to (pendingSessionEnd.sessionEndTimestamp - pendingSessionEnd.sessionStartTimestamp),
                        "globalDuration" to pendingSessionEnd.globalDuration,
                        "sessionStartTime" to pendingSessionEnd.sessionStartTimestamp,
                        "sessionEndTime" to pendingSessionEnd.sessionEndTimestamp,
                        "sessionTrackingID" to pendingSessionEnd.sessionTrackingId, // Override with original session ID
                        "deferred" to true  // Flag indicating this was sent on next app start
                    )
                )
                
                // Force immediate send
                flush()
                
                // Clear pending session after successful queue
                // Note: Even if flush fails, we clear it because the event is now in the cache
                // and will be retried automatically by the repository
                userPreferences.clearPendingSessionEnd()
                
                logger.logDebug("📤 [Recovery] Queued deferred session-ended event for session: ${pendingSessionEnd.sessionTrackingId}")
            } else {
                logger.logDebug("🔍 [Recovery] No pending session end found (app was likely killed while in foreground)")
            }
        }
        
        // Fetch IP address once at initialization
        // This happens in the background and caches the result for all analytics events
        scope.launch {
            logger.logDebug("🌐 [IP] Fetching IP address at analytics initialization...")
            ipAddressProvider.getIpAddress()
        }

        // Fetch advertising ID once at initialization
        // Initialize lifecycle tracking
        if (context is Application) {
            lifecycleTracker.initialize(context)
        }
        
        // Start network monitoring if enabled
        if (config.autoSyncOnConnectivity) {
            networkMonitor.start()
        }
    }
    
    /**
     * Set user context (called when user logs in/out)
     */
    fun setUserContext(userContext: UserContext) {
        // Merge with auto-detected device info
        val deviceInfo = if (config.autoDetectDeviceInfo) {
            deviceInfoDetector.detectDeviceInfo()
        } else {
            null
        }

        // Preserve currentSessionTrackingId if it exists (active session takes precedence)
        // Otherwise use the sessionTrackingId from the provided userContext
        val sessionTrackingId = currentSessionTrackingId?.takeIf { it.isNotEmpty() }
            ?: userContext.sessionTrackingId?.takeIf { it.isNotEmpty() }

        // Resolve userId: use provided value, or fall back to persistent anonymous UUIDv7
        val resolvedUserId = userContext.userId ?: userPreferences.getOrCreateAnonymousUserId()

        this.userContext = userContext.copy(
            userId = resolvedUserId,
            deviceType = if (userContext.deviceType != "Android") {
                userContext.deviceType
            } else {
                deviceInfo?.deviceType ?: userContext.deviceType
            },
            userAgent = userContext.userAgent ?: deviceInfo?.userAgent,
            networkType = userContext.networkType ?: deviceInfo?.networkType,
            sessionSource = buildSessionSource("Android", config.companyName, config.bucketName),
            sessionTrackingId = sessionTrackingId
        )
        
        // Persist userID for use in all subsequent analytics calls
        userPreferences.saveUserId(this.userContext?.userId)
    }
    
    /**
     * Get current user context (for preserving fields like sessionTrackingId)
     */
    fun getUserContext(): UserContext? {
        return userContext
    }
    
    /**
     * Clear user context (on logout)
     */
    fun clearUserContext() {
        userContext = null
        userPreferences.clearUserId()
    }
    
    /**
     * Track scan event
     * 
     * For Scan Result — Match events:
     * - Only submits matches when they are new and unique
     * - If the same match is returned within the same second, it counts as a single match
     * - Deduplication is handled automatically for matched=true events
     * 
     * Match Data Fields (Required after successful scan match per analytics spec):
     * - userIDOwner: The userID of the user who owns the matched image
     * - usernameOwner: The username of the user who owns the matched image
     * - These fields must be included in all subsequent events related to the matched scan
     */
    fun trackScanEvent(
        scanType: ScanType,
        matched: Boolean,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        scanTrackingId: String? = null,
        similarCount: Int? = null,
        failed: Boolean = false,
        imageUrlOfScan: String? = null,
        viewSource: ViewSource? = null,
        imageTitle: String? = null,
        imageUrl: String? = null,
        bucketName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        category: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Per analytics_doc.md: "omit this call entirely for Live Visual Search" when no match.
            // No-match events are only for snapshot and camera roll modes.
            if (!matched && !failed && scanType == ScanType.LIVE) {
                logger.logDebug("📊 [Scan Event] Suppressing no-match event for live scan (per spec)")
                return@launch
            }

            // NOTE: Deduplication temporarily disabled — send scan event for EVERY recognition.
            // To restore consecutive-duplicate filtering, uncomment the block below.
            // if (matched && imageId != null) {
            //     val shouldSubmit = scanMatchDeduplicator.shouldSubmitMatch(imageId)
            //     if (!shouldSubmit) {
            //         logger.logDebug("Skipping duplicate scan match for imageID: $imageId (already submitted)")
            //         return@launch
            //     }
            // }
            
            val duration = if (matched) {
                // Get duration from scan/match timer
                timerManager.getDuration(TimerManager.TimerType.SCAN_MATCH)
            } else {
                0L
            }
            
            if (matched) {
                // Start scan/match timer for new match
                timerManager.startTimer(TimerManager.TimerType.SCAN_MATCH)
            }
            
            val optionalParams = mutableMapOf<String, Any>()
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            scanTrackingId?.let { optionalParams["scanTrackingID"] = it }
            similarCount?.let { optionalParams["similarCount"] = it }
            imageUrlOfScan?.let { optionalParams["imageUrlOfScan"] = it }
            imageTitle?.let { optionalParams["imageTitle"] = it }
            imageUrl?.let { optionalParams["imageUrl"] = it }
            viewSource?.let { optionalParams["viewSource"] = it.value }
            userIDOwner?.let { optionalParams["userIDOwner"] = it }
            usernameOwner?.let { optionalParams["usernameOwner"] = it }
            category?.let { optionalParams["category"] = it }
            
            // Override bucketName if provided (otherwise uses config default)
            val finalBucketName = bucketName ?: config.bucketName
            
            val parameters = buildEventParameters(
                eventName = "scan",
                additionalParams = additionalParams + mapOf(
                    "scanType" to scanType.value,
                    "duration" to duration,
                    "matched" to matched,
                    "failed" to failed,
                    "bucketName" to finalBucketName
                )
            ) + optionalParams
            
            val event = EventPayload(
                eventName = "scan",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )
            
            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [Scan Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }
            
            repository.enqueueEvent(event)
            
            // NOTE: Deduplication temporarily disabled — see comment above.
            // if (matched && imageId != null) {
            //     scanMatchDeduplicator.markAsSubmitted(imageId)
            // }
        }
    }
    
    /**
     * Track view event (LEGACY - Immediate Send Pattern)
     * 
     * DEPRECATED for COMPRESSED/EXPANDED views in Live mode notification cards.
     * Use bufferViewEvent() + sendBufferedViewEvent() instead for the new buffered pattern.
     * 
     * This method is still valid for:
     * - FULL view type (ImageDetailsView dialog)
     * - Library section views (History, Save, etc.)
     * - Any view that doesn't need buffering/duration tracking
     * 
     * For Live mode notification cards (compressed/expanded):
     * - Use bufferViewEvent() when card appears
     * - Use sendBufferedViewEvent() when user takes action
     * - This provides duration and timeToDisplay automatically
     * 
     * Match Data Fields (Include when viewing matched content):
     * - userIDOwner: The userID of the user who owns the matched image
     * - usernameOwner: The username of the user who owns the matched image
     * - imageUrlOfScan: URL of image submitted by user to make the match
     */
    fun trackViewEvent(
        viewType: ViewType,
        viewSource: ViewSource,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        imageUrlOfScan: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Deduplicate view/compressed for the same imageId (e.g. repeated callbacks from UI)
            if (viewType == ViewType.COMPRESSED && imageId != null) {
                if (!viewCompressedDeduplicator.shouldSubmitViewCompressed(imageId)) {
                    logger.logDebug("📊 [View Event] Skipping duplicate view/compressed for imageId=$imageId")
                    return@launch
                }
            }

            val timerType = when (viewType) {
                ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
            }

            // Get duration from previous view (if any)
            val duration = when (viewType) {
                ViewType.COMPRESSED -> 0L  // Starting compressed view
                ViewType.EXPANDED -> timerManager.getDuration(TimerManager.TimerType.COMPRESSED_VIEW)
                ViewType.FULL -> timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
            }

            // Stop previous view timer
            when (viewType) {
                ViewType.COMPRESSED -> { /* No previous */ }
                ViewType.EXPANDED -> timerManager.stopTimer(TimerManager.TimerType.COMPRESSED_VIEW)
                ViewType.FULL -> timerManager.stopTimer(TimerManager.TimerType.EXPANDED_VIEW)
            }

            // Start timer for this view
            timerManager.startTimer(timerType)

            val optionalParams = mutableMapOf<String, Any>()
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            userIDOwner?.let { optionalParams["userIDOwner"] = it }
            usernameOwner?.let { optionalParams["usernameOwner"] = it }
            imageUrlOfScan?.let { optionalParams["imageUrlOfScan"] = it }

            // CRITICAL: Ensure viewType is always set and cannot be overwritten by additionalParams
            // Merge additionalParams first, then explicitly set viewType, viewSource, and duration
            val mergedParams = additionalParams.toMutableMap()
            mergedParams["viewType"] = viewType.value
            mergedParams["viewSource"] = viewSource.value
            mergedParams["duration"] = duration

            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mergedParams
            ) + optionalParams

            val event = EventPayload(
                eventName = "view",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )

            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [View Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }

            repository.enqueueEvent(event)

            if (viewType == ViewType.COMPRESSED && imageId != null) {
                viewCompressedDeduplicator.markViewCompressedSubmitted(imageId)
            }
        }
    }
    
    /**
     * Buffer a view event to be sent later when user takes action.
     *
     * New Pattern (Buffered Events):
     * - When notification card appears → Call bufferViewEvent (don't send yet)
     * - When user takes action (expand, dismiss, click link) → Call sendBufferedViewEvent
     * - Event is sent WITH duration and timeToDisplay
     *
     * @param viewType The type of view (compressed, expanded, full)
     * @param viewSource The source of the view (liveScan, snapshot, etc.)
     * @param imageId Optional imageID for deduplication
     * @param campaignId Optional campaign ID
     * @param campaignName Optional campaign name
     * @param userIDOwner Optional owner user ID (for matched content)
     * @param usernameOwner Optional owner username (for matched content)
     * @param imageUrlOfScan URL of image submitted by user to make the match (required after match)
     * @param trackingId Optional tracking ID for ImageLifecycleTracker (for timeToDisplay calculation)
     * @param additionalParams Additional parameters to include in event
     */
    fun bufferViewEvent(
        viewType: ViewType,
        viewSource: ViewSource,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        imageUrlOfScan: String? = null,
        trackingId: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Check if should buffer (deduplication)
            if (!viewEventBuffer.shouldBuffer(imageId, viewType)) {
                logger.logDebug("📊 [Buffer] Skipping duplicate buffer for imageId=$imageId, viewType=${viewType.value}")
                return@launch
            }
            
            // Create buffered event
            val bufferedEvent = ViewEventBuffer.BufferedViewEvent(
                viewType = viewType,
                viewSource = viewSource,
                imageId = imageId,
                campaignId = campaignId,
                campaignName = campaignName,
                userIDOwner = userIDOwner,
                usernameOwner = usernameOwner,
                imageUrlOfScan = imageUrlOfScan,
                startTimestamp = System.currentTimeMillis(),
                trackingId = trackingId,
                additionalParams = additionalParams
            )
            
            // Buffer the event
            val buffered = viewEventBuffer.bufferViewEvent(bufferedEvent)
            if (buffered) {
                logger.logDebug("📊 [Buffer] Buffered ${viewType.value} event for imageId=$imageId, trackingId=$trackingId")
                
                // Start timer for this view type
                val timerType = when (viewType) {
                    ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                    ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                    ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
                }
                timerManager.startTimer(timerType)
            }
        }
    }
    
    /**
     * Send the buffered view event with duration and timeToDisplay.
     * Called when user takes action (expand, dismiss, click link, etc.)
     *
     * @param timeToDisplay Optional timeToDisplay value (in milliseconds) from ImageLifecycleTracker
     * @return true if event was sent, false if no buffered event
     */
    suspend fun sendBufferedViewEvent(timeToDisplay: Long? = null): Boolean {
        return viewEventBuffer.sendBufferedEvent(
            getDuration = { startTimestamp ->
                // Calculate duration from start timestamp
                System.currentTimeMillis() - startTimestamp
            },
            getTimeToDisplay = { _ ->
                // Use provided timeToDisplay value
                timeToDisplay
            }
        )?.let { bufferedEvent ->
            // Calculate duration
            val duration = System.currentTimeMillis() - bufferedEvent.startTimestamp

            // Normalize timeToDisplay:
            // - COMPRESSED view: if timing exists but rounds to 0ms, report 1ms minimum
            // - Other views: preserve existing behavior (0 when not provided)
            val finalTimeToDisplay = when (bufferedEvent.viewType) {
                ViewType.COMPRESSED -> when {
                    timeToDisplay == null -> 0L
                    timeToDisplay <= 0L -> 1L
                    else -> timeToDisplay
                }
                else -> timeToDisplay ?: 0L
            }

            // Stop timer for this view type
            val timerType = when (bufferedEvent.viewType) {
                ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
            }
            timerManager.stopTimer(timerType)

            // Build optional params
            val optionalParams = mutableMapOf<String, Any>()
            bufferedEvent.imageId?.let { optionalParams["imageID"] = it }
            bufferedEvent.campaignId?.let { optionalParams["campaignID"] = it }
            bufferedEvent.campaignName?.let { optionalParams["campaignName"] = it }
            bufferedEvent.userIDOwner?.let { optionalParams["userIDOwner"] = it }
            bufferedEvent.usernameOwner?.let { optionalParams["usernameOwner"] = it }
            bufferedEvent.imageUrlOfScan?.let { optionalParams["imageUrlOfScan"] = it }

            // Always include timeToDisplay
            optionalParams["timeToDisplay"] = finalTimeToDisplay

            // Merge with additional params from buffered event
            val mergedParams = bufferedEvent.additionalParams.toMutableMap()
            mergedParams["viewType"] = bufferedEvent.viewType.value
            mergedParams["viewSource"] = bufferedEvent.viewSource.value
            mergedParams["duration"] = duration

            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mergedParams
            ) + optionalParams

            // CRITICAL: Use the original start timestamp, NOT current time
            // The timestamp must reflect when the event ACTUALLY happened, not when it's sent
            val event = EventPayload(
                eventName = "view",
                timestamp = bufferedEvent.startTimestamp,
                parameters = parameters
            )

            logger.logDebug("📊 [Buffer] Sent ${bufferedEvent.viewType.value} event for imageId=${bufferedEvent.imageId}, duration=${duration}, timeToDisplay=${finalTimeToDisplay}, imageUrlOfScan=${bufferedEvent.imageUrlOfScan}, timestamp=${bufferedEvent.startTimestamp}")

            repository.enqueueEvent(event)

            true
        } ?: false
    }

    /**
     * Synchronously send buffered view event and wait for persistence.
     * Use for critical exit paths where event loss is unacceptable.
     *
     * @param timeToDisplay Optional timeToDisplay value (in milliseconds) from ImageLifecycleTracker
     * @return true if event was sent, false if no buffered event
     */
    suspend fun sendBufferedViewEventSync(timeToDisplay: Long? = null): Boolean {
        return viewEventBuffer.sendBufferedEvent(
            getDuration = { startTimestamp ->
                // Calculate duration from start timestamp
                System.currentTimeMillis() - startTimestamp
            },
            getTimeToDisplay = { _ ->
                // Use provided timeToDisplay value
                timeToDisplay
            }
        )?.let { bufferedEvent ->
            // Calculate duration
            val duration = System.currentTimeMillis() - bufferedEvent.startTimestamp

            // Normalize timeToDisplay:
            // - COMPRESSED view: if timing exists but rounds to 0ms, report 1ms minimum
            // - Other views: preserve existing behavior (0 when not provided)
            val finalTimeToDisplay = when (bufferedEvent.viewType) {
                ViewType.COMPRESSED -> when {
                    timeToDisplay == null -> 0L
                    timeToDisplay <= 0L -> 1L
                    else -> timeToDisplay
                }
                else -> timeToDisplay ?: 0L
            }

            // Stop timer for this view type
            val timerType = when (bufferedEvent.viewType) {
                ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
            }
            timerManager.stopTimer(timerType)

            // Build optional params
            val optionalParams = mutableMapOf<String, Any>()
            bufferedEvent.imageId?.let { optionalParams["imageID"] = it }
            bufferedEvent.campaignId?.let { optionalParams["campaignID"] = it }
            bufferedEvent.campaignName?.let { optionalParams["campaignName"] = it }
            bufferedEvent.userIDOwner?.let { optionalParams["userIDOwner"] = it }
            bufferedEvent.usernameOwner?.let { optionalParams["usernameOwner"] = it }
            bufferedEvent.imageUrlOfScan?.let { optionalParams["imageUrlOfScan"] = it }

            // Always include timeToDisplay
            optionalParams["timeToDisplay"] = finalTimeToDisplay

            // Merge with additional params from buffered event
            val mergedParams = bufferedEvent.additionalParams.toMutableMap()
            mergedParams["viewType"] = bufferedEvent.viewType.value
            mergedParams["viewSource"] = bufferedEvent.viewSource.value
            mergedParams["duration"] = duration

            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mergedParams
            ) + optionalParams

            // CRITICAL: Use the original start timestamp, NOT current time
            // The timestamp must reflect when the event ACTUALLY happened, not when it's sent
            val event = EventPayload(
                eventName = "view",
                timestamp = bufferedEvent.startTimestamp,
                parameters = parameters
            )

            logger.logDebug("📊 [Buffer] Sent ${bufferedEvent.viewType.value} event (sync) for imageId=${bufferedEvent.imageId}, duration=${duration}, timeToDisplay=${finalTimeToDisplay}, imageUrlOfScan=${bufferedEvent.imageUrlOfScan}, timestamp=${bufferedEvent.startTimestamp}")

            // Use synchronous enqueue that waits for cache save
            repository.enqueueEventSync(event)

            true
        } ?: false
    }
    
    /**
     * Clear the view event buffer without sending.
     * Called when card is dismissed or user navigates away without action.
     */
    fun clearViewEventBuffer() {
        scope.launch {
            viewEventBuffer.clearBuffer()
        }
    }
    
    /**
     * Track library section view event (History, Save, My IRCodes, Trash, Profile)
     * 
     * This is separate from trackViewEvent() because library sections use section timers
     * (which are managed separately) rather than view timers.
     * 
     * @param viewSource The library section being viewed (HISTORY, SAVE, MY_IRCODES, TRASH, PROFILE)
     * @param previousSectionDuration Duration spent in previous section (lap model)
     */
    fun trackLibrarySectionView(
        viewSource: ViewSource,
        previousSectionDuration: Long = 0L
    ) {
        scope.launch {
            // CRITICAL: Ensure viewType is always set for library section views
            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mapOf(
                    "viewType" to ViewType.FULL.value,
                    "viewSource" to viewSource.value,
                    "duration" to previousSectionDuration
                )
            )
            
            val event = EventPayload(
                eventName = "view",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )
            
            repository.enqueueEvent(event)
        }
    }
    
    /**
     * Track button pressed event
     *
     * Match Data Fields (Include when button is related to matched content):
     * - userIDOwner: The userID of the user who owns the matched image
     * - usernameOwner: The username of the user who owns the matched image
     */
    fun trackButtonPressedEvent(
        buttonType: ButtonType,
        buttonSource: ButtonSource,
        buttonTitle: String? = null,
        buttonLink: String? = null,
        linkToFollow: String? = null,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        failed: Boolean = false,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Get duration from active timer based on context
            val viewType = additionalParams["viewType"]?.toString()
            val duration = when (buttonSource) {
                ButtonSource.HOME_VIEW -> {
                    if (viewType == ViewType.EXPANDED.value) {
                        timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                    } else {
                        timerManager.getDuration(TimerManager.TimerType.COMPRESSED_VIEW)
                    }
                }
                ButtonSource.IRCODE_VIEW -> {
                    // Check FULL_VIEW timer first (ImageDetailsView)
                    val fullViewDuration = timerManager.getDuration(TimerManager.TimerType.FULL_VIEW)
                    if (fullViewDuration > 0) {
                        fullViewDuration
                    } else {
                        // Fall back to EXPANDED_VIEW timer (expanded notification)
                        timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                    }
                }
                ButtonSource.PROFILE_VIEW -> timerManager.getDuration(TimerManager.TimerType.SECTION_PROFILE)
                else -> timerManager.getDuration(TimerManager.TimerType.GLOBAL_SESSION)
            }

            val optionalParams = mutableMapOf<String, Any>()
            buttonTitle?.let { optionalParams["buttonTitle"] = it }
            buttonLink?.let { optionalParams["buttonLink"] = it }
            linkToFollow?.let { optionalParams["linkToFollow"] = it }
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            userIDOwner?.let { optionalParams["userIDOwner"] = it }
            usernameOwner?.let { optionalParams["usernameOwner"] = it }

            val parameters = buildEventParameters(
                eventName = "buttonPressed",
                additionalParams = additionalParams + mapOf(
                    "buttonType" to buttonType.value,
                    "buttonSource" to buttonSource.value,
                    "duration" to duration,
                    "failed" to failed
                )
            ) + optionalParams

            val event = EventPayload(
                eventName = "buttonPressed",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )

            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [Button Press Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }

            repository.enqueueEvent(event)
        }
    }

    /**
     * Synchronously track button pressed event and wait for persistence.
     * Use for critical exit paths where event loss is unacceptable.
     */
    suspend fun trackButtonPressedEventSync(
        buttonType: ButtonType,
        buttonSource: ButtonSource,
        buttonTitle: String? = null,
        buttonLink: String? = null,
        linkToFollow: String? = null,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        failed: Boolean = false,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        // Get duration from active timer based on context
        val viewType = additionalParams["viewType"]?.toString()
        val duration = when (buttonSource) {
            ButtonSource.HOME_VIEW -> {
                if (viewType == ViewType.EXPANDED.value) {
                    timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                } else {
                    timerManager.getDuration(TimerManager.TimerType.COMPRESSED_VIEW)
                }
            }
            ButtonSource.IRCODE_VIEW -> {
                // Check FULL_VIEW timer first (ImageDetailsView)
                val fullViewDuration = timerManager.getDuration(TimerManager.TimerType.FULL_VIEW)
                if (fullViewDuration > 0) {
                    fullViewDuration
                } else {
                    // Fall back to EXPANDED_VIEW timer (expanded notification)
                    timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                }
            }
            ButtonSource.PROFILE_VIEW -> timerManager.getDuration(TimerManager.TimerType.SECTION_PROFILE)
            else -> timerManager.getDuration(TimerManager.TimerType.GLOBAL_SESSION)
        }

        val optionalParams = mutableMapOf<String, Any>()
        buttonTitle?.let { optionalParams["buttonTitle"] = it }
        buttonLink?.let { optionalParams["buttonLink"] = it }
        linkToFollow?.let { optionalParams["linkToFollow"] = it }
        imageId?.let { optionalParams["imageID"] = it }
        campaignId?.let { optionalParams["campaignID"] = it }
        campaignName?.let { optionalParams["campaignName"] = it }
        userIDOwner?.let { optionalParams["userIDOwner"] = it }
        usernameOwner?.let { optionalParams["usernameOwner"] = it }

        val parameters = buildEventParameters(
            eventName = "buttonPressed",
            additionalParams = additionalParams + mapOf(
                "buttonType" to buttonType.value,
                "buttonSource" to buttonSource.value,
                "duration" to duration,
                "failed" to failed
            )
        ) + optionalParams

        val event = EventPayload(
            eventName = "buttonPressed",
            timestamp = System.currentTimeMillis(),
            parameters = parameters
        )

        // Verification logging for campaign fields
        if (imageId != null) {
            logger.logDebug("📊 [Button Press Event] (sync) imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
        }

        // Use synchronous enqueue that waits for cache save
        repository.enqueueEventSync(event)
    }
    
    /**
     * Track status event
     */
    fun trackStatusEvent(
        statusType: StatusType,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            val optionalParams = mutableMapOf<String, Any>()
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            
            val parameters = buildEventParameters(
                eventName = "status",
                additionalParams = additionalParams + mapOf(
                    "statusType" to statusType.value
                )
            ) + optionalParams
            
            // CRITICAL: For session events, use the actual event time from additionalParams
            // For SESSION_STARTED, use sessionStartTime; for SESSION_STOPPED, use sessionEndTime
            // Otherwise use current time
            val eventTimestamp = when (statusType) {
                StatusType.SESSION_STARTED -> (additionalParams["timestamp"] as? Long) ?: System.currentTimeMillis()
                StatusType.SESSION_STOPPED -> (additionalParams["sessionEndTime"] as? Long) ?: System.currentTimeMillis()
                else -> System.currentTimeMillis()
            }
            
            val event = EventPayload(
                eventName = "status",
                timestamp = eventTimestamp,
                parameters = parameters
            )
            
            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [Status Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }
            
            repository.enqueueEvent(event)
        }
    }

    /**
     * Synchronously track status event and wait for cache persistence.
     * Use for critical events (like session-ended) that must be persisted before app termination.
     *
     * This method blocks until the event is saved to the SQLite cache.
     */
    suspend fun trackStatusEventSync(
        statusType: StatusType,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        val optionalParams = mutableMapOf<String, Any>()
        imageId?.let { optionalParams["imageID"] = it }
        campaignId?.let { optionalParams["campaignID"] = it }
        campaignName?.let { optionalParams["campaignName"] = it }

        val parameters = buildEventParameters(
            eventName = "status",
            additionalParams = additionalParams + mapOf(
                "statusType" to statusType.value
            )
        ) + optionalParams

        // CRITICAL: For session events, use the actual event time from additionalParams
        // For SESSION_STARTED, use sessionStartTime; for SESSION_STOPPED, use sessionEndTime
        // Otherwise use current time
        val eventTimestamp = when (statusType) {
            StatusType.SESSION_STARTED -> (additionalParams["timestamp"] as? Long) ?: System.currentTimeMillis()
            StatusType.SESSION_STOPPED -> (additionalParams["sessionEndTime"] as? Long) ?: System.currentTimeMillis()
            else -> System.currentTimeMillis()
        }

        val event = EventPayload(
            eventName = "status",
            timestamp = eventTimestamp,
            parameters = parameters
        )

        // Verification logging for campaign fields
        if (imageId != null) {
            logger.logDebug("📊 [Status Event] (sync) imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
        }

        logger.logDebug("📊 [Status Event] (sync) statusType=${statusType.value}")

        // Use synchronous enqueue that waits for cache save
        repository.enqueueEventSync(event)
    }

    /**
     * Track user account created event.
     * This should be called immediately after a user account is successfully created.
     * All required fields per analytics spec are automatically included from userContext.
     */
    fun trackUserAccountCreated() {
        scope.launch {
            val currentContext = userContext
            if (currentContext == null) {
                logger.logError("Cannot track userAccountCreated: userContext is null")
                return@launch
            }
            
            // Build additional parameters with user-specific fields
            val additionalParams = mutableMapOf<String, Any>()
            
            // userName is required
            currentContext.username?.let { additionalParams["userName"] = it }
            
            // userProfileUrl is optional but include if available
            currentContext.userProfileUrl?.let { additionalParams["userProfileUrl"] = it }
            
            // All other required fields (userID, userType, sessionTrackingID, location, device info, etc.)
            // are automatically included via buildEventParameters() from userContext
            
            val parameters = buildEventParameters(
                eventName = "status",
                additionalParams = additionalParams + mapOf(
                    "statusType" to StatusType.USER_ACCOUNT_CREATED.value
                )
            )
            
            val event = EventPayload(
                eventName = "status",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )
            
            // Send immediately (enqueue will handle sending)
            repository.enqueueEvent(event)
            
            // Force immediate flush to send this critical event right away
            repository.flushEvents()
        }
    }
    
    /**
     * Generic event tracking
     */
    fun trackEvent(
        eventName: String,
        parameters: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            val eventParams = buildEventParameters(eventName, parameters)
            
            val event = EventPayload(
                eventName = eventName,
                timestamp = System.currentTimeMillis(),
                parameters = eventParams
            )
            
            repository.enqueueEvent(event)
        }
    }
    
    /**
     * Timer management
     */
    suspend fun startViewTimer(viewType: ViewType) {
        val timerType = when (viewType) {
            ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
            ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
            ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
        }
        timerManager.startTimer(timerType)
    }
    
    suspend fun stopViewTimer(viewType: ViewType): Long {
        val timerType = when (viewType) {
            ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
            ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
            ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
        }
        return timerManager.stopTimer(timerType)
    }
    
    suspend fun getViewDuration(viewType: ViewType): Long {
        val timerType = when (viewType) {
            ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
            ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
            ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
        }
        return timerManager.getDuration(timerType)
    }
    
    fun startScanMatchTimer() {
        scope.launch {
            timerManager.startTimer(TimerManager.TimerType.SCAN_MATCH)
        }
    }
    
    suspend fun stopScanMatchTimer(): Long {
        return timerManager.stopTimer(TimerManager.TimerType.SCAN_MATCH)
    }
    
    fun startSectionTimer(section: ViewSource) {
        scope.launch {
            val timerType = when (section) {
                ViewSource.HISTORY -> TimerManager.TimerType.SECTION_HISTORY
                ViewSource.SAVE -> TimerManager.TimerType.SECTION_SAVE
                ViewSource.MY_IRCODES -> TimerManager.TimerType.SECTION_MY_IRCODES
                ViewSource.TRASH -> TimerManager.TimerType.SECTION_TRASH
                ViewSource.PROFILE -> TimerManager.TimerType.SECTION_PROFILE
                else -> null
            }
            timerType?.let { timerManager.startTimer(it) }
        }
    }
    
    suspend fun stopSectionTimer(section: ViewSource): Long {
        val timerType = when (section) {
            ViewSource.HISTORY -> TimerManager.TimerType.SECTION_HISTORY
            ViewSource.SAVE -> TimerManager.TimerType.SECTION_SAVE
            ViewSource.MY_IRCODES -> TimerManager.TimerType.SECTION_MY_IRCODES
            ViewSource.TRASH -> TimerManager.TimerType.SECTION_TRASH
            ViewSource.PROFILE -> TimerManager.TimerType.SECTION_PROFILE
            else -> return 0L
        }
        return timerManager.stopTimer(timerType)
    }
    
    fun onAppBackgrounded() {
        scope.launch {
            timerManager.pauseAll()
        }
    }
    
    fun onAppForegrounded() {
        scope.launch {
            timerManager.resumeAll()
        }
    }
    
    fun onSessionStarted() {
        scope.launch {
            // Clear IP cache - user may have moved to a new location since last session
            ipAddressProvider.clearCache()
            logger.logDebug("🌐 [IP] Cleared cached IP for new session")

            // Generate a new session tracking ID each time session starts
            // This ID will be used for all events until the next onSessionStarted() call
            currentSessionTrackingId = SessionTrackingIdGenerator.generate()
            
            // Update userContext with the new session ID to keep it in sync
            userContext?.let { context ->
                userContext = context.copy(sessionTrackingId = currentSessionTrackingId)
            }
            
            logger.logDebug("🆔 [Session] New session started with ID: $currentSessionTrackingId")
            timerManager.startTimer(TimerManager.TimerType.GLOBAL_SESSION)
        }
    }
    
    suspend fun onSessionStopped(): Long {
        return timerManager.stopTimer(TimerManager.TimerType.GLOBAL_SESSION)
    }
    
    /**
     * Get global session duration without stopping the timer
     */
    suspend fun getGlobalSessionDuration(): Long {
        return timerManager.getDuration(TimerManager.TimerType.GLOBAL_SESSION)
    }
    
    /**
     * Get current session tracking ID for lifecycle tracking.
     * Returns the current session ID or generates a new one if not set.
     * This is used by LifecycleTracker to preserve the session ID when saving pending session end.
     */
    fun getCurrentSessionTrackingId(): String {
        return currentSessionTrackingId ?: SessionTrackingIdGenerator.generate()
    }

    /**
     * Get the analytics bucket name currently in use.
     */
    fun getBucketName(): String = config.bucketName

    /**
     * Get the analytics session source currently in use.
     */
    fun getSessionSource(): String = buildSessionSource("Android", config.companyName, config.bucketName)
    
    /**
     * Flush pending events
     */
    suspend fun flush() {
        repository.flushEvents()
    }

    /**
     * Synchronously flush pending events with a timeout.
     * Use for critical exit paths where we need to ensure events are sent before app termination.
     *
     * This method blocks until either:
     * - All events are flushed successfully, OR
     * - The timeout is reached (to prevent indefinite blocking on network issues)
     *
     * @param timeoutMs Maximum time to wait for flush to complete (default 2000ms)
     * @return true if flush completed within timeout, false if timed out
     */
    suspend fun flushSync(timeoutMs: Long = 2000L): Boolean {
        logger.logDebug("🔄 [Flush] Starting synchronous flush with ${timeoutMs}ms timeout")
        val result = withTimeoutOrNull(timeoutMs) {
            repository.flushEvents()
            true
        }
        val success = result == true
        if (success) {
            logger.logDebug("✅ [Flush] Synchronous flush completed successfully")
        } else {
            logger.logDebug("⏰ [Flush] Synchronous flush timed out after ${timeoutMs}ms")
        }
        return success
    }

    /**
     * Pause all timers synchronously.
     * Use for critical exit paths where we need to ensure timers are paused before app termination.
     */
    suspend fun onAppBackgroundedSync() {
        timerManager.pauseAll()
    }

    /**
     * Cache inspection (dev mode)
     */
    suspend fun getCachedEvents(): List<EventPayload> {
        return cache.loadEvents()
    }
    
    suspend fun getCacheStats(): CacheStats {
        return repository.getCacheStats()
    }
    
    suspend fun clearCache() {
        cache.clearAll()
    }
    
    /**
     * Clear a specific imageID from the scan match deduplication queue.
     * This should be called when the preview popup is dismissed to allow
     * the same imageID to be submitted again if it's recognized again.
     * 
     * @param imageId The imageID or assetID to remove from the deduplication queue
     */
    fun clearScanMatchDeduplication(imageId: String) {
        scope.launch {
            scanMatchDeduplicator.remove(imageId)
            logger.logDebug("Cleared scan match deduplication for imageID: $imageId")
        }
    }
    
    /**
     * Clear all scan match deduplication entries.
     * Useful for testing or when resetting the analytics state.
     */
    fun clearAllScanMatchDeduplication() {
        scope.launch {
            scanMatchDeduplicator.clear()
            logger.logDebug("Cleared all scan match deduplication entries")
        }
    }
    
    /**
     * Clear the cached IP address.
     * This forces a fresh fetch from the /myip endpoint on the next analytics event.
     * Useful when the device's network changes (e.g., switching from WiFi to cellular).
     */
    fun clearIpAddressCache() {
        scope.launch {
            ipAddressProvider.clearCache()
        }
    }
    
    /**
     * Build event parameters with user context and common fields.
     * Automatically fetches location if permissions are available.
     */
    private suspend fun buildEventParameters(
        eventName: String,
        additionalParams: Map<String, Any>
    ): Map<String, Any?> {
        val params = mutableMapOf<String, Any?>()
        
        // Add common parameters
        // CRITICAL: bucketName and sessionSource are REQUIRED per analytics spec
        // These come from config, not userContext (they're app-level configuration)
        params["bucketName"] = config.bucketName
        params["sessionSource"] = buildSessionSource("Android", config.companyName, config.bucketName)
        params["created"] = System.currentTimeMillis()

        // timeToDisplay is REQUIRED for all events - default to 0 if not provided
        // Individual event methods can override via additionalParams or optionalParams
        params["timeToDisplay"] = 0L

        // CRITICAL: userID is REQUIRED for all events per analytics spec
        // For anonymous users (no Firebase), this is a persistent UUIDv7
        // Fall back to anonymous UUID if userContext hasn't been set yet (race condition
        // where lifecycle events fire before setUserContext is called)
        params["userID"] = userContext?.userId ?: userPreferences.getOrCreateAnonymousUserId()
        params["installationID"] = userContext?.installationId

        // Automatically fetch location if permissions are available
        // This happens transparently - client apps don't need to provide location
        val location = locationProvider.getCurrentLocation()
        val autoLocationLat = location?.latitude   // latitude -> locationLat (do not swap with longitude)
        val autoLocationLng = location?.longitude   // longitude -> locationLng (do not swap with latitude)
        
        // Automatically fetch IP address from cache or /myip endpoint
        // This happens transparently - client apps don't need to provide IP
        val autoIpAddress = ipAddressProvider.getIpAddress()
        
        // CRITICAL: sessionTrackingID is REQUIRED per analytics spec (line 81)
        // Must be UUIDv7. Use currentSessionTrackingId (generated in onSessionStarted()),
        // fall back to userContext if available, or generate new one as safety net
        // IMPORTANT: Allow override from additionalParams for deferred session-ended events
        // This ensures the session-ended event uses the original session ID, not the new one
        val sessionTrackingId = (additionalParams["sessionTrackingID"] as? String)
            ?: currentSessionTrackingId?.takeIf { it.isNotEmpty() }
            ?: userContext?.sessionTrackingId?.takeIf { it.isNotEmpty() }
            ?: SessionTrackingIdGenerator.generate()
        params["sessionTrackingID"] = sessionTrackingId
        
        // Add user context
        // CRITICAL: userType is REQUIRED per analytics spec (line 83)
        // Must be one of: "anonymous", "basic", "pro", "enterprise", "creator"
        // Default to "anonymous" if not provided
        val userType = userContext?.userType?.takeIf { it.isNotEmpty() } ?: "anonymous"
        params["userType"] = userType
        
        userContext?.let { context ->
            context.username?.let { params["username"] = it }
            context.userProfileUrl?.let { params["profileUrl"] = it }
            
            // Location - use auto-detected location if not provided in UserContext
            // Priority: UserContext location > Auto-detected location
            // IP Address - use cached IP from /myip endpoint if not provided in UserContext
            // Priority: UserContext IP > Cached IP from /myip > Local IP detection
            val finalLocationIp = context.locationIp ?: autoIpAddress
            finalLocationIp?.let { params["locationIP"] = it }
            
            val finalLocationLat = context.locationLat ?: autoLocationLat
            val finalLocationLng = context.locationLng ?: autoLocationLng
            finalLocationLat?.let { params["locationLat"] = it }  // latitude only
            finalLocationLng?.let { params["locationLng"] = it }  // longitude only
            
            // Location lookup: Currently not geocoding - passing null
            // Geocoding code is kept in place for future use (getSessionLocationLookup method)
            // If locationLookup is provided in UserContext, use it; otherwise pass null
            context.locationLookup?.let { params["locationLookup"] = it }
            // Note: Auto-geocoding disabled - uncomment below to enable:
            // else if (finalLocationLat != null && finalLocationLng != null) {
            //     val locationLookup = getSessionLocationLookup(finalLocationLat, finalLocationLng)
            //     locationLookup?.let { params["locationLookup"] = it }
            // }
            
            // Device info (v2.0: removed deviceManufacturer, deviceCarrier, deviceIFA, cookies)
            params["deviceModel"] = context.deviceModel
            params["deviceType"] = context.deviceType
            params["osVersion"] = context.osVersion
            context.userAgent?.let { params["userAgent"] = it }
            context.appVersion?.let { params["appVersion"] = it }
            params["appSource"] = APP_SOURCE
            context.libraryVersion?.let { params["libraryVersion"] = it }
            context.networkType?.let { params["network"] = it.value }
        }
        
        // If no userContext but we have auto-detected location or IP, include it
        if (userContext == null) {
            // Include auto-detected IP address
            autoIpAddress?.let { params["locationIP"] = it }
            
            // Include auto-detected location
            if (autoLocationLat != null || autoLocationLng != null) {
                autoLocationLat?.let { params["locationLat"] = it }  // latitude only
                autoLocationLng?.let { params["locationLng"] = it }   // longitude only
                
                // Location lookup: Currently not geocoding - passing null
                // Geocoding code is kept in place for future use (getSessionLocationLookup method)
                // Note: Auto-geocoding disabled - uncomment below to enable:
                // if (autoLocationLat != null && autoLocationLng != null) {
                //     val locationLookup = getSessionLocationLookup(autoLocationLat, autoLocationLng)
                //     locationLookup?.let { params["locationLookup"] = it }
                // }
            }
        }
        
        // If network was not set from userContext, detect it now
        if (!params.containsKey("network")) {
            params["network"] = getDetectedNetworkType()
        }
        
        // Add additional parameters (override common ones if needed)
        additionalParams.forEach { (key, value) ->
            params[key] = value
        }
        
        // CRITICAL: Ensure network parameter is always a simple string enum value, never a JSON object
        // Per analytics_doc.md line 119: network must be one of: offline, wifi, cellular2g, 3g, 4g, 5g, ethernet, unknown
        // SessionStart and SessionEnd should both send just the active network name (e.g., "wifi"), not an object
        val networkValue = params["network"]
        params["network"] = when {
            networkValue is String -> {
                // Already a string - validate it's a valid enum value, otherwise detect actual network
                val validValues = setOf("offline", "wifi", "cellular2g", "3g", "4g", "5g", "ethernet", "unknown")
                if (networkValue.lowercase() in validValues) {
                    networkValue.lowercase()
                } else {
                    // Invalid string value - detect actual network type
                    getDetectedNetworkType()
                }
            }
            networkValue is NetworkType -> networkValue.value // Convert enum to string value
            networkValue is Map<*, *> -> {
                // If network is a Map/JSON object (e.g., {"bluetooth":false,"wifi":true,"cellular":false}),
                // extract the active network name or detect actual network type
                // Try to extract active network from map, otherwise detect it
                val map = networkValue as Map<*, *>
                when {
                    map["wifi"] == true -> "wifi"
                    map["cellular"] == true -> getDetectedNetworkType() // Detect cellular generation
                    map["bluetooth"] == true -> "unknown" // Bluetooth is not a valid network type
                    else -> getDetectedNetworkType() // Fallback to actual detection
                }
            }
            else -> {
                // If network is any other invalid type, detect actual network type
                // Also use detected network if network was not set at all
                getDetectedNetworkType()
            }
        }
        
        // Log location fields at INFO so it shows even when Debug is filtered (tag: analytics_payload).
        // v2.0: locationLat/locationLng stay in params for header extraction but are stripped from JSON payload
        Log.i(
            "analytics_payload",
            "Event params built: locationLat=${params["locationLat"]} (header), locationLng=${params["locationLng"]} (header), locationIP=${params["locationIP"]} (payload)"
        )
        return params
    }
    
    /**
     * Detect current network type and return as string enum value.
     * Per analytics_doc.md: network must be one of: offline, wifi, cellular2g, 3g, 4g, 5g, ethernet, unknown
     */
    private fun getDetectedNetworkType(): String {
        return if (config.autoDetectDeviceInfo) {
            deviceInfoDetector.detectDeviceInfo().networkType.value
        } else {
            // Fallback to unknown if auto-detection is disabled
            NetworkType.UNKNOWN.value
        }
    }
    
    /**
     * Construct imageUrlOfScan from trackingId and bucketName.
     *
     * The imageUrlOfScan is the URL of the image submitted by the user to make the match.
     * This URL points to the query image stored on the IR Engine backend.
     *
     * @param trackingId The tracking ID from the image search result
     * @param bucketName The bucket name (defaults to config bucketName if not provided)
     * @return The URL for the scanned image, or empty string if trackingId is empty
     */
    fun getQueryImageUrlForTrackingId(trackingId: String, bucketName: String? = null): String {
        val trimmed = trackingId.trim()
        if (trimmed.isEmpty()) return ""
        val bucket = bucketName?.ifEmpty { config.bucketName } ?: config.bucketName
        val baseUrl = config.irEngineBaseUrl.trimEnd('/')
        return "$baseUrl/queries/$bucket/$trimmed/image"
    }

    companion object {
        /** Value for the required `appSource` field on `sessionStarted` events. */
        const val APP_SOURCE = "app"

        @Volatile
        private var instance: AnalyticsClient? = null

        @JvmStatic
        fun getInstance(): AnalyticsClient {
            return instance ?: throw IllegalStateException(
                "AnalyticsClient not initialized. Call AnalyticsClient.initialize() first."
            )
        }

        fun initialize(context: Context, config: AnalyticsConfig) {
            if (instance == null) {
                synchronized(this) {
                    if (instance == null) {
                        instance = AnalyticsClient(config, context.applicationContext)
                    }
                }
            }
        }
    }
}

