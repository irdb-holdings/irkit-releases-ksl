package com.irdb.analytics.models

/**
 * Represents a session-ended event that needs to be sent on next app start.
 * This is used to track session closures when the app is killed, crashed, or force-stopped.
 * 
 * The session state is persisted to SharedPreferences when the app goes to background,
 * ensuring we can send the session-ended event even if the app is killed before the
 * network call completes.
 */
data class PendingSessionEnd(
    /**
     * The session tracking ID (UUIDv7) of the session that ended.
     * This must be preserved so the session-ended event is associated with the correct session.
     */
    val sessionTrackingId: String,
    
    /**
     * Timestamp (milliseconds since epoch) when the session ended.
     * Used for the event timestamp and calculating sessionDuration.
     */
    val sessionEndTimestamp: Long,
    
    /**
     * Timestamp (milliseconds since epoch) when the session started.
     * Used for calculating sessionDuration.
     */
    val sessionStartTimestamp: Long,
    
    /**
     * Total duration (milliseconds) from the global session timer.
     * This is the actual time spent in the app, excluding pauses.
     */
    val globalDuration: Long
)
