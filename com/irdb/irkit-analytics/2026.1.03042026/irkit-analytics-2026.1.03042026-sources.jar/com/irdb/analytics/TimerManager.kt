package com.irdb.analytics

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Manages multiple duration timers for different app sections/views.
 * 
 * Key Features:
 * - Multiple concurrent timers
 * - Pause/resume on app background/foreground
 * - Lap model: Duration is cumulative within section, resets on section change
 * - Thread-safe with coroutines
 */
internal class TimerManager(
    private val logger: AnalyticsLogger
) {
    private val timers = mutableMapOf<TimerType, TimerState>()
    private val mutex = Mutex()
    private var isPaused = false
    private var pauseStartTime: Long = 0
    
    enum class TimerType {
        GLOBAL_SESSION,      // App running time
        COMPRESSED_VIEW,     // Compressed notification/view visible
        EXPANDED_VIEW,       // Expanded view visible
        FULL_VIEW,           // Full detail view visible
        SCAN_MATCH,          // Time since match was made
        SECTION_HISTORY,     // History section
        SECTION_SAVE,        // Save section
        SECTION_MY_IRCODES,  // My IRCodes section
        SECTION_TRASH,       // Trash section
        SECTION_PROFILE      // Profile section
    }
    
    data class TimerState(
        val type: TimerType,
        var startTime: Long,
        var pausedDuration: Long = 0,  // Total time paused
        var isActive: Boolean = false
    ) {
        fun getElapsedTime(currentTime: Long): Long {
            if (!isActive) return 0
            val activeDuration = currentTime - startTime
            return activeDuration - pausedDuration
        }
    }
    
    /**
     * Start a timer (resets if already running)
     */
    suspend fun startTimer(type: TimerType) {
        mutex.withLock {
            val now = System.currentTimeMillis()
            timers[type] = TimerState(
                type = type,
                startTime = now,
                isActive = true
            )
            logger.logDebug("⏱️ Started timer: ${type.name}")
        }
    }
    
    /**
     * Stop a timer (returns duration)
     */
    suspend fun stopTimer(type: TimerType): Long {
        return mutex.withLock {
            val timer = timers[type] ?: return@withLock 0L
            val duration = timer.getElapsedTime(System.currentTimeMillis())
            timer.isActive = false
            logger.logDebug("⏱️ Stopped timer: ${type.name}, duration: ${duration}ms")
            duration
        }
    }
    
    /**
     * Get current duration without stopping
     */
    suspend fun getDuration(type: TimerType): Long {
        return mutex.withLock {
            val timer = timers[type] ?: return@withLock 0L
            timer.getElapsedTime(System.currentTimeMillis())
        }
    }
    
    /**
     * Pause all active timers (app backgrounded)
     */
    suspend fun pauseAll() {
        mutex.withLock {
            if (isPaused) return@withLock
            isPaused = true
            pauseStartTime = System.currentTimeMillis()
            logger.logDebug("⏸️ Paused all timers")
        }
    }
    
    /**
     * Resume all active timers (app foregrounded)
     */
    suspend fun resumeAll() {
        mutex.withLock {
            if (!isPaused) return@withLock
            val pauseDuration = System.currentTimeMillis() - pauseStartTime
            
            timers.values.forEach { timer ->
                if (timer.isActive) {
                    timer.pausedDuration += pauseDuration
                }
            }
            
            isPaused = false
            logger.logDebug("▶️ Resumed all timers (paused for ${pauseDuration}ms)")
        }
    }
    
    /**
     * Reset a timer (stops and clears)
     */
    suspend fun resetTimer(type: TimerType) {
        mutex.withLock {
            timers.remove(type)
            logger.logDebug("🔄 Reset timer: ${type.name}")
        }
    }
    
    /**
     * Get all active timers (for debugging)
     */
    suspend fun getActiveTimers(): Map<TimerType, Long> {
        return mutex.withLock {
            timers.filter { it.value.isActive }
                .mapValues { (_, timer) -> timer.getElapsedTime(System.currentTimeMillis()) }
        }
    }
}

