package com.irdb.analytics

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Automatically detects and provides user location for analytics when permissions are available.
 * Client apps don't need to pass location data - the library handles it automatically.
 */
internal class LocationProvider(
    private val context: Context,
    private val logger: AnalyticsLogger
) {
    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)
    
    private var cachedLocation: Location? = null
    private var lastLocationUpdateTime: Long = 0
    private var isInitialFetchInProgress = false
    
    // Cache location for 5 minutes to avoid excessive location requests
    private val LOCATION_CACHE_DURATION_MS = 5 * 60 * 1000L
    
    init {
        // Start background location fetch immediately (non-blocking)
        startBackgroundLocationFetch()
    }
    
    /**
     * Start fetching location in the background.
     * This is called during initialization so location is ready when events are sent.
     */
    private fun startBackgroundLocationFetch() {
        if (!hasLocationPermission()) {
            logger.logDebug("📍 [Location] No permission for background fetch")
            return
        }
        
        logger.logDebug("📍 [Location] Starting background location fetch...")
        isInitialFetchInProgress = true
        
        // Use callback-based approach for background fetch (non-blocking)
        try {
            @Suppress("MissingPermission")
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        cachedLocation = location
                        lastLocationUpdateTime = System.currentTimeMillis()
                        logger.logDebug("📍 [Location] ✓ Background fetch succeeded: lat=${location.latitude}, lng=${location.longitude}")
                    } else {
                        logger.logDebug("📍 [Location] Background fetch: no last known location available")
                    }
                    isInitialFetchInProgress = false
                }
                .addOnFailureListener { e ->
                    logger.logDebug("📍 [Location] Background fetch failed: ${e.message}")
                    isInitialFetchInProgress = false
                }
        } catch (e: Exception) {
            logger.logDebug("📍 [Location] Background fetch exception: ${e.message}")
            isInitialFetchInProgress = false
        }
    }
    
    /**
     * Check if location permissions are granted.
     */
    fun hasLocationPermission(): Boolean {
        val fineLocationGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        
        val coarseLocationGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        
        return fineLocationGranted || coarseLocationGranted
    }
    
    /**
     * Get current location if permissions are available.
     * Returns cached location immediately (non-blocking).
     * If cache is stale, triggers background refresh for next time.
     */
    suspend fun getCurrentLocation(): Location? {
        if (!hasLocationPermission()) {
            return null
        }
        
        val now = System.currentTimeMillis()
        
        // Return cached location if available (even if slightly stale)
        if (cachedLocation != null) {
            val age = (now - lastLocationUpdateTime) / 1000
            logger.logDebug("📍 [Location] Using cached location (${age}s old): lat=${cachedLocation?.latitude}, lng=${cachedLocation?.longitude}")
            
            // If cache is getting old, trigger background refresh for next time (non-blocking)
            if ((now - lastLocationUpdateTime) > LOCATION_CACHE_DURATION_MS && !isInitialFetchInProgress) {
                logger.logDebug("📍 [Location] Cache stale, triggering background refresh...")
                startBackgroundLocationFetch()
            }
            
            return cachedLocation
        }
        
        // No cached location available
        logger.logDebug("📍 [Location] No cached location available")
        
        // If initial fetch is still in progress, just return null (don't block)
        if (isInitialFetchInProgress) {
            logger.logDebug("📍 [Location] Initial fetch in progress, returning null for now")
            return null
        }
        
        // Try one quick attempt at last known location only (fast, non-blocking)
        return try {
            getLastKnownLocation()
        } catch (e: Exception) {
            logger.logDebug("📍 [Location] Failed to get location: ${e.message}")
            null
        }
    }
    
    /**
     * Get last known location (fastest, but may be stale).
     */
    @Suppress("MissingPermission") // Permission check done in hasLocationPermission()
    private suspend fun getLastKnownLocation(): Location? = suspendCancellableCoroutine { continuation ->
        try {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        logger.logDebug("📍 [Location] lastLocation success: lat=${location.latitude}, lng=${location.longitude}")
                    } else {
                        logger.logDebug("📍 [Location] lastLocation returned null")
                    }
                    continuation.resume(location)
                }
                .addOnFailureListener { e ->
                    logger.logDebug("📍 [Location] lastLocation failed: ${e.message}")
                    continuation.resume(null)
                }
        } catch (e: Exception) {
            logger.logDebug("📍 [Location] lastLocation exception: ${e.message}")
            continuation.resume(null)
        }
    }
    
    /**
     * Request current location (slower, but more accurate).
     * Note: This often returns null on emulators or when location services are disabled.
     */
    @Suppress("MissingPermission") // Permission check done in hasLocationPermission()
    private suspend fun requestCurrentLocation(): Location? = suspendCancellableCoroutine { continuation ->
        val cancellationTokenSource = CancellationTokenSource()
        
        continuation.invokeOnCancellation {
            cancellationTokenSource.cancel()
        }
        
        try {
            fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                cancellationTokenSource.token
            )
                .addOnSuccessListener { location ->
                    if (location != null) {
                        logger.logDebug("📍 [Location] getCurrentLocation success: lat=${location.latitude}, lng=${location.longitude}")
                    } else {
                        logger.logDebug("📍 [Location] getCurrentLocation returned null (location services may be disabled or no GPS fix)")
                    }
                    continuation.resume(location)
                }
                .addOnFailureListener { e ->
                    logger.logDebug("📍 [Location] getCurrentLocation failed: ${e.message}")
                    continuation.resume(null)
                }
        } catch (e: Exception) {
            logger.logDebug("📍 [Location] getCurrentLocation exception: ${e.message}")
            continuation.resume(null)
        }
    }
    
    /**
     * Clear cached location to force fresh lookup on next request.
     */
    fun clearCache() {
        cachedLocation = null
        lastLocationUpdateTime = 0
    }
}

