package com.irdb.analytics

import android.content.Context
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Provider for fetching and caching the device's Advertising ID (GAID).
 * Respects user opt-out preferences.
 */
internal class AdvertisingIdProvider(
    private val context: Context,
    private val logger: AnalyticsLogger
) {
    private var cachedAdvertisingId: String? = null
    private var hasFetched = false

    /**
     * Fetch the advertising ID asynchronously.
     * Call this at initialization to pre-fetch the ID.
     */
    suspend fun fetchAdvertisingId(): String? = withContext(Dispatchers.IO) {
        if (hasFetched) {
            return@withContext cachedAdvertisingId
        }

        try {
            val adInfo = AdvertisingIdClient.getAdvertisingIdInfo(context)

            // Respect user opt-out preference
            if (adInfo.isLimitAdTrackingEnabled) {
                logger.logDebug("📱 [IFA] User has opted out of ad tracking")
                cachedAdvertisingId = null
            } else {
                val id = adInfo.id
                // Handle zeroed-out ID (user deleted advertising ID on Android 12+)
                if (id == "00000000-0000-0000-0000-000000000000") {
                    logger.logDebug("📱 [IFA] User has deleted advertising ID")
                    cachedAdvertisingId = null
                } else {
                    cachedAdvertisingId = id
                    logger.logDebug("📱 [IFA] Retrieved advertising ID: ${id?.take(8)}...")
                }
            }
        } catch (e: Exception) {
            // Device may not have Google Play Services
            logger.logDebug("📱 [IFA] Failed to get advertising ID: ${e.message}")
            cachedAdvertisingId = null
        }

        hasFetched = true
        cachedAdvertisingId
    }

    /**
     * Get the cached advertising ID synchronously.
     * Returns null if not yet fetched or unavailable.
     */
    fun getCachedAdvertisingId(): String? = cachedAdvertisingId
}
