package com.irdb.analytics

import kotlin.time.Duration.Companion.seconds

/**
 * Builds the sessionSource string dynamically from its component parts.
 * Format: "{platform}-{companyName}-{bucketName}"
 *
 * @param platform The platform identifier (e.g., "Android")
 * @param companyName The company name (e.g., "ksl", "irdb")
 * @param bucketName The analytics bucket name (e.g., "ksldemo", "irdbMain")
 * @return The constructed sessionSource string (e.g., "Android-ksl-ksldemo")
 */
fun buildSessionSource(platform: String, companyName: String, bucketName: String): String {
    return "$platform-$companyName-$bucketName".lowercase()
}

/**
 * Helper function to create AnalyticsConfig from Java.
 * Provides sensible defaults for all parameters.
 */
fun createAnalyticsConfig(
    apiEndpoint: String,
    apiKey: String,
    companyName: String,
    bucketName: String,
    isDebugBuild: Boolean
): AnalyticsConfig {
    return AnalyticsConfig(
        apiEndpoint = apiEndpoint,
        apiKey = apiKey,
        companyName = companyName,
        bucketName = bucketName,
        enableMocking = true,  // Mock/log only (no network calls)
        enableDebugLogging = isDebugBuild,
        autoTrackLifecycle = true,  // REQUIRED for session tracking
        autoDetectDeviceInfo = true,
        enableCaching = true,
        cacheRetentionPolicy = CacheRetentionPolicy.CLEAR_ON_SUCCESS,
        maxBatchSize = 100,
        flushInterval = 10.seconds,
        autoSyncOnConnectivity = true
    )
}
