package com.irdb.analytics.models

/**
 * Statistics about cached events for debugging and inspection.
 */
data class CacheStats(
    val totalEvents: Int = 0,
    val pendingEvents: Int = 0,           // Not sent yet
    val successEvents: Int = 0,           // Successfully sent (dev mode only)
    val failedEvents: Int = 0,            // Failed to send
    val oldestEventTimestamp: Long? = null,
    val newestEventTimestamp: Long? = null,
    val oldestSentTimestamp: Long? = null,  // When oldest event was sent
    val newestSentTimestamp: Long? = null,  // When newest event was sent
    val cacheSize: Int = 0,                // Total size in bytes
    val lastUpdated: Long = 0              // Last cache update timestamp
)

