package com.irdb.analytics.network

/**
 * Analytics API interface - now using NetworkClient instead of Retrofit
 * This file kept for reference but actual implementation is in NetworkClient
 */
