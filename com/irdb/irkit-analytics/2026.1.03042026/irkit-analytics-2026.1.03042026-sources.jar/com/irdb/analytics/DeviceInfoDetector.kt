package com.irdb.analytics

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build

/**
 * Automatically detects device information from Android OS.
 * Falls back to provided values if auto-detection fails.
 */
internal class DeviceInfoDetector(
    private val context: Context
) {
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    
    fun detectDeviceInfo(): DeviceInfo {
        return DeviceInfo(
            deviceModel = Build.MODEL,
            deviceType = getDeviceType(),
            osVersion = Build.VERSION.RELEASE,
            userAgent = generateUserAgent(),
            networkType = detectNetworkType()
        )
    }
    
    private fun getDeviceType(): String {
        return "Android"
    }
    
    private fun generateUserAgent(): String {
        return "Android/${Build.VERSION.RELEASE} (${Build.MODEL}; ${Build.MANUFACTURER})"
    }
    
    private fun detectNetworkType(): NetworkType {
        val network = connectivityManager?.activeNetwork ?: return NetworkType.OFFLINE
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return NetworkType.UNKNOWN
        
        return when {
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> NetworkType.OFFLINE
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                // Detect cellular generation
                // Note: NET_CAPABILITY_5G and NET_CAPABILITY_4G are not available in all API levels
                // We'll use link bandwidth as a proxy for network generation
                val linkDownstreamBandwidthKbps = capabilities.linkDownstreamBandwidthKbps
                when {
                    linkDownstreamBandwidthKbps >= 20000 -> NetworkType.CELLULAR_5G  // 20+ Mbps suggests 5G
                    linkDownstreamBandwidthKbps >= 10000 -> NetworkType.CELLULAR_4G   // 10+ Mbps suggests 4G
                    linkDownstreamBandwidthKbps >= 2000 -> NetworkType.CELLULAR_3G    // 2+ Mbps suggests 3G
                    else -> NetworkType.CELLULAR_2G  // Fallback to 2G
                }
            }
            else -> NetworkType.UNKNOWN
        }
    }
}

/**
 * Device information model
 */
/**
 * Device information model (v2.0: removed deviceManufacturer, deviceCarrier, deviceIFA)
 */
data class DeviceInfo(
    val deviceModel: String,
    val deviceType: String,
    val osVersion: String,
    val userAgent: String,
    val networkType: NetworkType
)

