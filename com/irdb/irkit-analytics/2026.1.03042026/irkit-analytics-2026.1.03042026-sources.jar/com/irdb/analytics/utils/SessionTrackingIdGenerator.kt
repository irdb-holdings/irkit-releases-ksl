package com.irdb.analytics.utils

import java.security.SecureRandom
import java.util.UUID

/**
 * Utility for generating UUID v7 for session tracking.
 * 
 * UUID v7 is time-ordered and includes a timestamp component, making it ideal for
 * session tracking where chronological ordering is important.
 * 
 * This is used as a safety net when third-party apps don't provide sessionTrackingID.
 */
internal object SessionTrackingIdGenerator {
    private val secureRandom = SecureRandom()

    /**
     * Generates a UUID v7 (time-ordered) in standard RFC 4122 format with hyphens.
     *
     * UUID v7 format:
     * - 48 bits: Unix timestamp in milliseconds
     * - 12 bits: Random data
     * - 4 bits: Version (7)
     * - 2 bits: Variant
     * - 62 bits: Random data
     *
     * @return Standard UUID string (e.g., "019c955b-dbad-7bf6-a2a0-dbf4fd634c91")
     */
    fun generate(): String {
        val uuid = generateUUIDv7()
        return uuid.toString()
    }

    /**
     * Generates a UUID v7 using the current timestamp and random data.
     *
     * @return UUID v7 instance
     */
    private fun generateUUIDv7(): UUID {
        val timestamp = System.currentTimeMillis()

        // Create 16-byte array for UUID
        val bytes = ByteArray(16)

        // Set timestamp (48 bits = 6 bytes) in the first 6 bytes
        // Most significant byte first (big-endian)
        bytes[0] = (timestamp shr 40).toByte()
        bytes[1] = (timestamp shr 32).toByte()
        bytes[2] = (timestamp shr 24).toByte()
        bytes[3] = (timestamp shr 16).toByte()
        bytes[4] = (timestamp shr 8).toByte()
        bytes[5] = timestamp.toByte()

        // Fill remaining 10 bytes with random data
        val randomBytes = ByteArray(10)
        secureRandom.nextBytes(randomBytes)
        System.arraycopy(randomBytes, 0, bytes, 6, 10)

        // Set version (7) in the 4 most significant bits of the 7th byte
        bytes[6] = (bytes[6].toInt() and 0x0F or 0x70).toByte()

        // Set variant bits (10) in the 2 most significant bits of the 9th byte
        bytes[8] = (bytes[8].toInt() and 0x3F or 0x80).toByte()

        // Convert to UUID
        var mostSignificantBits = 0L
        var leastSignificantBits = 0L

        for (i in 0..7) {
            mostSignificantBits = (mostSignificantBits shl 8) or (bytes[i].toInt() and 0xFF).toLong()
        }

        for (i in 8..15) {
            leastSignificantBits = (leastSignificantBits shl 8) or (bytes[i].toInt() and 0xFF).toLong()
        }

        return UUID(mostSignificantBits, leastSignificantBits)
    }
}
