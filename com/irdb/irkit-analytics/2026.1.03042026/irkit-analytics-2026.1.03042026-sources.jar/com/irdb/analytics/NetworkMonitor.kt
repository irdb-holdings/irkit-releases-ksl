package com.irdb.analytics

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Monitors network connectivity and auto-syncs when connection restored.
 */
internal class NetworkMonitor(
    private val context: Context,
    private val onConnectivityRestored: suspend () -> Unit,
    private val logger: AnalyticsLogger
) {
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) 
        as ConnectivityManager
    
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wasDisconnected = false
    
    // Network callback for API 21+
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            logger.logDebug("📶 Network available")
            handleConnectivityChange(true)
        }
        
        override fun onLost(network: Network) {
            logger.logDebug("📵 Network lost")
            handleConnectivityChange(false)
        }
    }
    
    fun start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
        } else {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(request, networkCallback)
        }
        
        logger.logDebug("✅ Network monitoring started")
    }
    
    fun stop() {
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
            logger.logDebug("⏹️ Network monitoring stopped")
        } catch (e: Exception) {
            logger.logError("Error stopping network monitor", e)
        }
    }
    
    private fun handleConnectivityChange(isConnected: Boolean) {
        when {
            isConnected && wasDisconnected -> {
                // Connection restored - trigger sync
                logger.logDebug("✅ Connection restored - triggering sync")
                scope.launch {
                    delay(2000) // Give network a moment to stabilize
                    onConnectivityRestored()
                }
                wasDisconnected = false
            }
            !isConnected -> {
                wasDisconnected = true
            }
        }
    }
    
    fun isConnected(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

